"""Render the saved section scene without rebuilding or changing its geometry."""
import bpy,os
s=bpy.data.scenes['01_Section_Display_6F_B1'];bpy.context.window.scene=s;s.frame_set(1)
bpy.ops.render.render(write_still=True)
print('TEACHING_COURTYARD_RENDER_COMPLETE',flush=True)
