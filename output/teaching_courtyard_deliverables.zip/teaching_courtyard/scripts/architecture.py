"""Real six-storey classroom wings, open circulation and a separate basement."""
import bpy,math,random
from mathutils import Vector
from geometry import *
from layout import *

def build_architecture():
    regular=collection('10_Complete_Six_Aboveground_Storeys')
    basement=collection('11_One_Basement_Storey')
    stairs=collection('12_Open_Return_Stairs_and_Landings')
    tower=collection('13_Clock_Tower_and_Entrance_Frames')
    roofs=collection('14_Roof_Shading_and_Low_Metal_Roof')
    cut=collection('90_Section_Removable_Original_Building_Parts')
    white=material('Warm white painted concrete',(.75,.76,.70),.8)
    cream=material('Pale cream yellow facade accents',(.76,.60,.32),.8)
    pale=material('Ivory horizontal floor bands',(.64,.64,.54),.81)
    floor=material('Light grey corridor paving',(.56,.59,.56),.79)
    frame=material('Silver grey aluminium window frames',(.50,.55,.55),.38,.45,False)
    metal=material('Satin silver corridor rails',(.48,.54,.54),.32,.6,False)
    dark=material('Dark painted classroom doors',(.035,.065,.064),.62)
    glass=material('Quiet blue grey window glass',(.12,.22,.25),.23,.22,False)
    p=glass.node_tree.nodes.get('Principled BSDF');p.inputs['Coat Weight'].default_value=.35
    brown=material('Muted red brown low metal roof',(.35,.115,.095),.69)
    black=material('Dark ventilation slots and clock marks',(.055,.07,.07),.82)
    mats=[white,cream,pale,floor,frame,metal,dark,glass,brown,black]
    rng=random.Random(438623)
    outline=[]
    def finish(batch,name,coll,level=None,part=None):
        o=batch.finish(name,mats,coll)
        if level is not None:o['storey']=level
        if part:o['part']=part
        if coll==cut:o['section_removable']=True
        return o
    # Work in facade-local coordinates: horizontal u, outward normal n, vertical z.
    def fbox(batch,u,z,width,height,depth,origin,tangent,normal,mat):
        center=Vector(origin)+Vector(tangent)*u+Vector((0,0,z))
        batch.box(center,(width,depth,height),mat,[tangent,normal,(0,0,1)])
    def facade_window(batch,u,z,width,height,origin,tangent,normal,grille=False,yellow=True):
        org=Vector(origin);n=Vector(normal)
        # Recessed glazing and real projecting frames; no window decals.
        fbox(batch,u,z,width,height,.045,org,tangent,normal,7)
        for xx in [-width/2,width/2]:fbox(batch,u+xx,z,.075,height+.12,.105,org+n*.07,tangent,normal,4)
        for zz in [-height/2,height/2]:fbox(batch,u,z+zz,width+.12,.075,.105,org+n*.07,tangent,normal,4)
        for xx in [-width/6,width/6]:fbox(batch,u+xx,z,.045,height,.09,org+n*.07,tangent,normal,4)
        fbox(batch,u,z+height*.23,width,.045,.09,org+n*.07,tangent,normal,4)
        if yellow:
            for xx in [-width/2-.15,width/2+.15]:fbox(batch,u+xx,z,.23,height+.48,.18,org-n*.04,tangent,normal,1)
            for zz in [-height/2-.15,height/2+.15]:fbox(batch,u,z+zz,width+.50,.23,.18,org-n*.04,tangent,normal,1)
        fbox(batch,u,z-height/2-.11,width+.28,.10,.30,org+n*.08,tangent,normal,0)
        if grille:
            for i in range(int(width/.23)+1):
                x=-width*.47+i*width*.94/max(1,int(width/.23));fbox(batch,u+x,z,.025,height,.035,org+n*.22,tangent,normal,4)
            for zz in [-height*.25,height*.25]:fbox(batch,u,z+zz,width,.025,.04,org+n*.22,tangent,normal,4)
    def facade_door(batch,u,z,origin,tangent,normal):
        fbox(batch,u,z+1.08,.94,2.16,.065,origin,tangent,normal,6)
        for dx in [-.50,.50]:fbox(batch,u+dx,z+1.1,.065,2.25,.13,origin,tangent,normal,4)
        fbox(batch,u,z+2.21,1.05,.06,.13,origin,tangent,normal,4)
        fbox(batch,u+.30,z+1.02,.035,.22,.12,Vector(origin)+Vector(normal)*.07,tangent,normal,4)
        fbox(batch,u,z+1.68,.25,.31,.075,Vector(origin)+Vector(normal)*.01,tangent,normal,7)
    def ac_unit(batch,u,z,origin,tangent,normal):
        n=Vector(normal);org=Vector(origin)
        fbox(batch,u,z,.87,.58,.38,org+n*.27,tangent,normal,0)
        fbox(batch,u-.19,z,.43,.43,.02,org+n*.47,tangent,normal,9)
        for zz in [-.16,-.08,0,.08,.16]:fbox(batch,u+.22,z+zz,.23,.022,.025,org+n*.49,tangent,normal,4)
        for xx in [-.32,.32]:fbox(batch,u+xx,z-.36,.05,.08,.6,org+n*.27,tangent,normal,9)
        # A circular fan ring sits on the square housing.
        center=org+Vector(tangent)*(u-.19)+Vector((0,0,z))+n*.49
        pts=[center+Vector(tangent)*(.17*math.cos(k*math.tau/24))+Vector((0,0,.17*math.sin(k*math.tau/24))) for k in range(25)]
        batch.tube(pts,.016,4,6)
    def guardrail(batch,a,b,z,parapet=True):
        a=Vector((*a,z));b=Vector((*b,z));L=(b-a).length
        if parapet:batch.beam(a+Vector((0,0,.30)),b+Vector((0,0,.30)),.13,.60,0)
        for zz in ([.76,1.05] if parapet else [.28,.57,.82,1.05]):batch.tube([a+Vector((0,0,zz)),b+Vector((0,0,zz))],.028,5,8)
        for j in range(math.ceil(L/.85)+1):
            p=a.lerp(b,j/max(1,math.ceil(L/.85)));batch.tube([p+Vector((0,0,.58 if parapet else .02)),p+Vector((0,0,1.05))],.024,5,7)
    # Six exact above-ground floor levels. Each wing has genuine open corridors.
    for level,z in enumerate(LEVELS,1):
        for side in [-1,1]:
            for section,(yl,yh) in enumerate([(-18,6),(6,18)]):
                coll=cut if side==1 and level>=4 and section==0 else regular
                shell=Batch();detail=Batch();rails=Batch()
                cx=side*12.5;length=yh-yl
                shell.box((cx,(yl+yh)/2,z-.12),(9,length,.24),3)
                shell.box((side*8.02,(yl+yh)/2,z-.20),(.22,length,.38),0)
                shell.box((side*7.96,(yl+yh)/2,z-.24),(.04,length,.11),1)
                shell.box((side*16.97,(yl+yh)/2,z-.20),(.35,length,.42),0)
                shell.box((side*17.17,(yl+yh)/2,z-.15),(.06,length,.12),1)
                for y in [v for v in range(-18,19,4) if yl<=v<yh]+[yh]:
                    shell.box((side*16.88,y,z+1.46),(.42,.34,2.92),0)
                    shell.box((side*8.13,y,z+1.45),(.38,.35,2.90),0)
                for bay,y in enumerate(BAYS):
                    if not yl<y<yh:continue
                    # Exterior wall uses spandrels and piers, leaving real openings.
                    shell.box((side*16.94,y,z+.46),(.20,3.67,.91),0)
                    shell.box((side*16.94,y,z+2.88),(.20,3.67,.30),0)
                    facade_window(detail,0,z+1.83,2.89,1.72,(side*17.04,y,0),(0,1,0),(side,0,0),grille=level<=4,yellow=level<6)
                    if (bay+level)%4==0:ac_unit(detail,-1.02,z+.77,(side*17.17,y,0),(0,1,0),(side,0,0))
                    # Classroom partitions and corridor wall segments around door/window.
                    shell.box((side*13.75,y+1.93,z+1.45),(6.45,.13,2.9),0)
                    org=(side*10.55,y,0);t=(0,1,0);n=(-side,0,0)
                    facade_door(detail,-1.32,z,org,t,n)
                    facade_window(detail,.56,z+1.65,1.88,1.43,org,t,n,grille=level<=2,yellow=False)
                    for uy,w in [(-1.91,.18),(-.70,.30),(1.80,.30)]:fbox(shell,uy,z+1.45,w,2.9,.16,org,t,n,0)
                    fbox(shell,.56,z+.48,2.15,.95,.16,org,t,n,0)
                    fbox(shell,.56,z+2.70,2.15,.47,.16,org,t,n,0)
                    fbox(shell,-1.32,z+2.61,1.16,.58,.16,org,t,n,0)
                    # Thin surface conduit and understated corridor ceiling lights.
                    detail.box((side*10.38,y,z+2.68),(.045,3.9,.045),9)
                    detail.cylinder((side*9.25,y,z+2.89),.15,.035,0,16)
                if level>1:guardrail(rails,(side*7.97,yl),(side*7.97,yh),z)
                elif yh>2:guardrail(rails,(side*7.97,max(2,yl)),(side*7.97,yh),z,False)
                o=finish(shell,f'F{level} {"east" if side>0 else "west"} wing structure {section}',coll,level,'wing');outline.append(o)
                finish(detail,f'F{level} classroom windows doors services {side} {section}',coll,level)
                if rails.v:finish(rails,f'F{level} open corridor guardrails {side} {section}',coll,level,'open_corridor')
        # Near-end connecting wing is retained completely in the full building state.
        for seg,(xl,xh) in enumerate([(-17,-8),(-8,8),(8,17)]):
            coll=cut if (seg==1 and level>1) or (seg==2 and level>=4) else regular
            sh=Batch();de=Batch();ra=Batch();cx=(xl+xh)/2;span=xh-xl
            sh.box((cx,-21,z-.12),(span,6,.24),3)
            sh.box((cx,-24,z-.20),(span,.32,.40),0)
            sh.box((cx,-24.18,z-.17),(span,.045,.12),1)
            sh.box((cx,-18,z-.20),(span,.25,.40),0)
            sh.box((cx,-17.86,z-.24),(span,.04,.12),1)
            columns=max(1,round(span/4))
            for j in range(columns+1):
                x=xl+span*j/columns;sh.box((x,-23.85,z+1.45),(.37,.40,2.90),0)
                sh.box((x,-18.1,z+1.45),(.36,.35,2.90),0)
            # Entrance at ground level stays open; upper floors have classroom glazing.
            if seg!=1 or level>1:
                for j in range(columns):
                    x=xl+span*(j+.5)/columns;w=span/columns-.75
                    sh.box((x,-23.95,z+.43),(w+.3,.20,.85),0)
                    sh.box((x,-23.95,z+2.84),(w+.3,.20,.35),0)
                    facade_window(de,0,z+1.77,w,1.78,(x,-24.05,0),(1,0,0),(0,-1,0),level<4,level<6)
                if level>1:guardrail(ra,(xl,-17.94),(xh,-17.94),z)
            if seg==1 and level==1:
                sh.box((0,-23.9,2.75),(15.6,.42,.40),0)
                for x in [-5.5,5.5]:facade_door(de,x,z,(0,-21.6,0),(1,0,0),(0,-1,0))
            o=finish(sh,f'F{level} entrance end block segment {seg}',coll,level,'end_connection');outline.append(o)
            if de.v:finish(de,f'F{level} entrance end fenestration {seg}',coll,level)
            if ra.v:finish(ra,f'F{level} entrance courtyard rail {seg}',coll,level)
        # Rear connector has a genuine stairwell void rather than a solid slab.
        sh=Batch();de=Batch();ra=Batch()
        for x,y,sx,sy in [(-12.5,21,9,6),(12.5,21,9,6),(0,18.55,16,1.10),(4.1,21.5,7.8,4.8),(-7.35,21.5,1.30,4.8),(0,23.65,16,.7)]:sh.box((x,y,z-.12),(sx,sy,.24),3)
        for x in [-17,-8,-.2,8,17]:sh.box((x,23.8,z+1.45),(.38,.38,2.9),0)
        for x in [-8,0,8]:sh.box((x,18.12,z+1.45),(.38,.38,2.9),0)
        sh.box((0,18,z-.22),(34,.28,.42),0);sh.box((0,17.84,z-.22),(34,.045,.10),1)
        sh.box((0,24,z+.43),(34,.20,.86),0);sh.box((0,24,z+2.85),(34,.20,.35),0)
        for x in [-14.5,-10.4,-6.2,-2.1,2.1,6.2,10.4,14.5]:facade_window(de,0,z+1.78,3.1,1.8,(x,24.07,0),(1,0,0),(0,1,0),level<3,False)
        if level>1:guardrail(ra,(-8,17.94),(8,17.94),z)
        o=finish(sh,f'F{level} rear stairwell connector',regular,level,'end_connection');outline.append(o)
        finish(de,f'F{level} rear exterior windows',regular,level)
        if ra.v:finish(ra,f'F{level} rear connecting corridor rail',regular,level)
    # Basement: separate floor, retaining walls, exposed doors along the sunken court.
    b=Batch();d=Batch()
    b.box((0,0,BASEMENT-.14),(34,48,.28),3)
    for side in [-1,1]:
        b.box((side*16.95,0,BASEMENT+1.45),(.22,48,2.90),0)
        for y in BAYS:
            b.box((side*8.15,y+1.9,BASEMENT+1.45),(.38,.36,2.90),0)
            b.box((side*10.55,y+1.88,BASEMENT+1.45),(.18,.25,2.90),0)
            facade_window(d,.55,BASEMENT+1.66,1.85,1.40,(side*10.55,y,0),(0,1,0),(-side,0,0),True,False)
            facade_door(d,-1.30,BASEMENT,(side*10.55,y,0),(0,1,0),(-side,0,0))
            b.box((side*10.55,y+.55,BASEMENT+.47),(.18,2.15,.94),0)
            b.box((side*10.55,y+.55,BASEMENT+2.65),(.18,2.15,.55),0)
    b.box((0,23.9,BASEMENT+1.45),(34,.2,2.9),0)
    # Front basement wall can be hidden with the presentation section, without deleting it.
    front=Batch();front.box((0,-23.9,BASEMENT+1.45),(34,.2,2.9),0);finish(front,'B1 front basement retaining section',cut,-1,'basement')
    finish(b,'B1 basement floor retaining walls and columns',basement,-1,'basement');finish(d,'B1 basement corridor windows and doors',basement,-1)
    # Six floor-to-floor connections: B1→1F and 1F→6F; no invented seventh floor.
    for startlevel in range(-1,5):
        z=BASEMENT if startlevel==-1 else LEVELS[startlevel]
        st=Batch();ra=Batch();xa,xb=-6.7,-2.3;ya,yb=19.85,22.05;w=1.65;N=10;rise=FLOOR_HEIGHT/2
        for j in range(N):
            x=xa+(xb-xa)*(j+.5)/N;top=z+rise*(j+1)/N
            st.box((x,ya,top-.105),((xb-xa)/N+.006,w,.21),3)
            x=xb-(xb-xa)*(j+.5)/N;top=z+rise+rise*(j+1)/N
            st.box((x,yb,top-.105),((xb-xa)/N+.006,w,.21),3)
        st.beam((xa,ya,z-.11),(xb,ya,z+rise-.11),w,.16,0)
        st.beam((xb,yb,z+rise-.11),(xa,yb,z+FLOOR_HEIGHT-.11),w,.16,0)
        st.box((-1.45,21,z+rise-.12),(1.7,3.95,.24),3)
        for yy,start,end in [(ya-w/2,(xa,z),(xb,z+rise)),(ya+w/2,(xa,z),(xb,z+rise)),(yb-w/2,(xb,z+rise),(xa,z+FLOOR_HEIGHT)),(yb+w/2,(xb,z+rise),(xa,z+FLOOR_HEIGHT))]:
            p=Vector((start[0],yy,start[1]));q=Vector((end[0],yy,end[1]))
            for height in [.52,1.0]:ra.tube([p+Vector((0,0,height)),q+Vector((0,0,height))],.025,5,8)
            for j in range(11):
                v=p.lerp(q,j/10);ra.tube([v,v+Vector((0,0,1))],.023,5,7)
        finish(st,f'Return stair connection {startlevel+1} to {startlevel+2}',stairs,startlevel,'return_stair')
        finish(ra,f'Return stair handrails {startlevel+1}',stairs)
    # Roof slabs, parapets and the long, flat modern pergola fins in the photos.
    for side in [-1,1]:
        for section,(yl,yh) in enumerate([(-24,6),(6,24)]):
            coll=cut if side==1 and section==0 else roofs
            sh=Batch();sh.box((side*12.5,(yl+yh)/2,ROOF-.1),(9,yh-yl,.20),3)
            sh.box((side*8.1,(yl+yh)/2,ROOF+.30),(.18,yh-yl,.60),0)
            for x in [side*10.5,side*17.0]:sh.box((x,(yl+yh)/2,ROOF+.14),(.18,yh-yl,.30),0)
            # Low pitched red sheet roof sits only over the classroom part of west wing.
            if side<0:
                verts=[(-17,yl,ROOF+.24),(-13.8,yl,ROOF+.92),(-10.55,yl,ROOF+.24),(-17,yh,ROOF+.24),(-13.8,yh,ROOF+.92),(-10.55,yh,ROOF+.24)]
                sh.add(verts,[(0,3,4,1),(1,4,5,2)],8)
                for y in [yl+i*.45 for i in range(int((yh-yl)/.45)+1)]:
                    sh.tube([(-17,y,ROOF+.26),(-13.8,y,ROOF+.94),(-10.55,y,ROOF+.26)],.018,8,5)
            for y in [yl+i*1.0 for i in range(int(yh-yl)+1)]:sh.box((side*17.20,y,ROOF+.72),(2.05,.14,.16),0)
            sh.box((side*18.15,(yl+yh)/2,ROOF+.72),(.14,yh-yl,.20),0)
            o=finish(sh,f'Roof of {side} wing section {section}',coll,part='roof');outline.append(o)
    sh=Batch();sh.box((0,21,ROOF-.1),(34,6,.20),3)
    for y in [18.05,23.95]:sh.box((0,y,ROOF+.28),(34,.18,.55),0)
    finish(sh,'Rear roof over six levels',roofs,part='roof')
    sh=Batch();sh.box((0,-21,ROOF-.1),(16,6,.20),3);sh.box((0,-24,ROOF+.28),(16,.18,.55),0)
    finish(sh,'Front connector roof removable for section view',cut,part='roof')
    # Tall entrance frames and the attached white/yellow clock tower.
    entry=Batch()
    for x in [-7.9,-3.0,1.9,6.8]:entry.box((x,-26.1,9.85),(.55,1.25,19.7),0)
    entry.box((-.4,-26.1,19.55),(18.0,1.2,.42),0)
    for x in [-8.6+i*.95 for i in range(20)]:entry.box((x,-23.8,19.56),(.16,5.6,.20),0)
    entry.box((-.4,-21.15,19.56),(18,.18,.25),0)
    finish(entry,'Tall white rectangular entrance frames and open pergola',tower,part='entrance_frames')
    tw=Batch();tw.box((14.7,-22.9,11.9),(4.6,5.7,23.8),0)
    tw.box((17.06,-22.9,12.2),(.16,5.9,24.4),1)
    tw.box((12.34,-22.9,12.2),(.16,5.9,24.4),1)
    tw.box((11.45,-25.78,9.65),(1.35,.12,19.3),7)
    for z in [i*1.55 for i in range(13)]:tw.box((11.45,-25.88,z),(1.4,.08,.055),9)
    for x in [10.80,11.45,12.10]:tw.box((x,-25.89,9.65),(.055,.08,19.3),9)
    # Clock sits on the side face as in the close-up photograph.
    tw.box((17.20,-22.9,21.45),(.13,3.7,3.7),0)
    for k in range(12):
        a=k*math.tau/12;y=-22.9+1.42*math.sin(a);z=21.45+1.42*math.cos(a)
        tw.beam((17.30,y-.12*math.sin(a),z-.12*math.cos(a)),(17.30,y+.12*math.sin(a),z+.12*math.cos(a)),.065,.09,9)
    tw.tube([(17.32,-22.9,21.45),(17.32,-23.75,21.94)],.055,9,8)
    tw.tube([(17.32,-22.9,21.45),(17.32,-22.65,22.62)],.042,9,8)
    for z in [17.3+i*.4 for i in range(6)]:tw.box((17.25,-22.9,z),(.20,3.6,.13),0)
    for y in [-25.3+i*.66 for i in range(9)]:tw.box((14.7,y,24.8),(6.5,.22,.22),0)
    for x in [11.5,17.9]:tw.box((x,-22.66,24.8),(.20,5.8,.24),0)
    for x in [12.6,16.8]:tw.box((x,-22.9,24.18),(.22,4.2,1.1),0)
    finish(tw,'White cream clock tower dark glazing and open roof grille',tower,part='clock_tower')
    # Sparse external drainage pipes, retained as actual small geometry.
    pipes=Batch()
    for side in [-1,1]:
        for y in [-13.8,6.2,17.7]:pipes.tube([(side*17.24,y,.2),(side*17.24,y,18.8)],.048,4,8)
    finish(pipes,'Facade rainwater pipes',regular)
    return {'regular':regular,'basement':basement,'stairs':stairs,'tower':tower,'roofs':roofs,'cut':cut,'materials':mats,'outline':outline,'guardrail':guardrail}
