"""Six floors above ground and one basement; complete and reversible section views."""
import bpy,os,sys,math
from mathutils import Vector
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)));OUT=os.path.join(ROOT,'output');os.makedirs(OUT,exist_ok=True)
sys.path.insert(0,os.path.dirname(__file__))
from geometry import *
from architecture import build_architecture
from landscape import build_landscape
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):bpy.data.collections.remove(c)
arch=build_architecture();print('ARCHITECTURE_READY',flush=True)
land=build_landscape(arch);print('COURTYARDS_READY',flush=True)
stage=collection('30_Studio_Lighting_and_Cameras')
bg=material('Warm pale grey studio background',(.79,.82,.80),.96,cel=False)
cube('Studio ground outside model',(0,0,-4.54),(500,500,.15),bg,stage,0)
def light(name,typ,loc,energy,color,size=30):
    d=bpy.data.lights.new(name,typ);d.energy=energy;d.color=color
    if typ=='AREA':d.shape='DISK';d.size=size
    if typ=='SUN':d.angle=math.radians(9)
    o=bpy.data.objects.new(name,d);stage.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,0,4))-o.location).to_track_quat('-Z','Y').to_euler()
light('Soft warm afternoon sun','SUN',(-30,-45,65),2.4,(1,.94,.83))
light('Large blue sky fill','AREA',(10,0,55),7000,(.75,.86,1),45)
def camera(name,position,target,scale):
    d=bpy.data.cameras.new(name);o=bpy.data.objects.new(name,d);stage.objects.link(o);o.location=position;o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();d.type='ORTHO';d.ortho_scale=scale;return o
target=Vector((0,0,5));cam=camera('Complete rectangle 45 degree section view',target+Vector((46,-75,87.98)),target,88)
camera('Courtyard close view',(17,-34,27),(0,1,5),43)
s=bpy.context.scene;s.name='01_Section_Display_6F_B1';s.camera=cam;s.render.engine='BLENDER_EEVEE_NEXT'
s.render.resolution_x=2000;s.render.resolution_y=1700;s.render.resolution_percentage=100
s.render.image_settings.file_format='PNG';s.render.fps=24;s.frame_start=1;s.frame_end=120;s.frame_set(1)
s.world.use_nodes=True;w=s.world.node_tree.nodes.get('Background');w.inputs[0].default_value=(.70,.80,.92,1);w.inputs[1].default_value=.55
s.view_settings.view_transform='AgX';s.view_settings.look='AgX - Medium High Contrast';s.view_settings.exposure=.40
s.eevee.use_raytracing=True;s.eevee.taa_render_samples=48
s.render.use_freestyle=True;s.render.line_thickness=.55
ls=s.view_layers[0].freestyle_settings.linesets[0];ls.linestyle.color=(.15,.18,.17);ls.linestyle.thickness=.48;ls.select_crease=False;ls.select_silhouette=True;ls.select_external_contour=True;ls.select_border=False
out=collection('31_Subtle_Structural_Outline_Set')
for o in arch['outline']:out.objects.link(o)
ls.select_by_collection=True;ls.collection=out;ls.collection_negation='INCLUSIVE'
# Do not link removable meshes into the outline collection: that would expose them again.
for o in list(out.objects):
    if o.get('section_removable'):out.objects.unlink(o)
cut_layer=s.view_layers[0].layer_collection.children[arch['cut'].name];cut_layer.exclude=True
s['Project']='现代校园教学楼 · 六层地上与一层地下 · 三渲二微缩模型'
s['Aboveground_storeys']=6;s['Basement_storeys']=1;s['Floor_elevations']=[0,3.15,6.30,9.45,12.60,15.75];s['Basement_elevation']=-3.15
s['Reference']='Twelve user-provided building and courtyard photographs. Visible massing, open corridors, stair and sunken court relationships guide reconstruction; dimensions and unseen parts are estimated.'
s['Section_note']='Full geometry is preserved. The second scene restores the front connector, near-wing upper part and front terrain. No storeys are deleted.'
s['Animation_note']='Gentle leaf motion only; buildings remain static.'
full=s.copy();full.name='02_Full_Building_6F_B1';full.use_fake_user=True;full.view_layers[0].layer_collection.children[arch['cut'].name].exclude=False
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL'
s.render.filepath='//teaching_courtyard.png';full.render.filepath='//teaching_courtyard_full.png'
bpy.context.window.scene=s
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'teaching_courtyard.blend'));print('EDITABLE_BLEND_SAVED',flush=True)
cut_layer.exclude=False
for m in bpy.data.materials:
    if not m.use_nodes:continue
    p=m.node_tree.nodes.get('Principled BSDF')
    if p:
        for link in list(p.inputs['Base Color'].links):m.node_tree.links.remove(link)
        p.inputs['Base Color'].default_value=m.diffuse_color
bpy.ops.object.select_all(action='DESELECT')
for o in s.objects:
    if o.type=='MESH' and not o.name.startswith('Studio ground'):o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'teaching_courtyard.glb'),export_format='GLB',use_selection=True,export_apply=True,export_animations=True,export_materials='EXPORT',export_extras=True,export_lights=False)
print('FULL_GEOMETRY_GLB_SAVED',flush=True)
if os.environ.get('CAMPUS_RENDER')=='1':
    bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT,'teaching_courtyard.blend'));bpy.context.window.scene=bpy.data.scenes['01_Section_Display_6F_B1'];bpy.ops.render.render(write_still=True);print('RENDER_COMPLETE',flush=True)
