"""Photo-derived layout; storey count is explicit, dimensions are visual estimates."""
FLOOR_HEIGHT=3.15
LEVELS=[i*FLOOR_HEIGHT for i in range(6)]
BASEMENT=-FLOOR_HEIGHT
ROOF=6*FLOOR_HEIGHT
BASE_X=46
BASE_Y=64
WING_OUTER=17
COURT_HALF=8
ROOM_INNER=10.55
BAYS=[-16+4*i for i in range(9)]
LOWER_COURT_Y=2
TREE_ROOT=(-.65,10.0,BASEMENT+.04)
