#!/usr/bin/env python3
"""Package the current GLB with vendored Three.js into one offline HTML file."""
from pathlib import Path
import argparse
import base64
import json
import subprocess

ROOT = Path(__file__).resolve().parents[1]

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model', type=Path, default=ROOT / 'output/teaching_courtyard.glb')
    parser.add_argument('--output', type=Path, default=ROOT / 'output/viewer.html')
    args = parser.parse_args()
    executable = ROOT / '.viewer-tools/node_modules/@esbuild/linux-x64/bin/esbuild'
    if not executable.exists():
        executable = ROOT / '.viewer-tools/node_modules/esbuild/bin/esbuild'
    bundle = ROOT / '.viewer-tools/viewer.bundle.js'
    subprocess.run([str(executable), str(ROOT / 'scripts/viewer_entry.js'), '--bundle', '--minify', '--format=iife', '--target=es2020', '--legal-comments=inline', '--outfile=' + str(bundle)], check=True)
    data = args.model.read_bytes()
    if data[:4] != b'glTF':
        raise ValueError('Model is not a binary glTF file')
    js = bundle.read_text().replace('</script', '<\\/script')
    encoded = base64.b64encode(data).decode('ascii')
    license_text = (ROOT / '.viewer-tools/node_modules/three/LICENSE').read_text().replace('--', '—')
    html = '<!-- Three.js license:\n' + license_text + '\n-->\n' + '''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1"><title>现代教学楼 · 六层与下沉中庭</title><meta name="description" content="可离线打开的现代校园教学楼三渲二模型。拖动旋转，滚轮缩放，双击复位，C 切换完整/剖切，1/2/3 切换视角。"><style>html,body{margin:0;width:100%;height:100%;overflow:hidden;background:#e8eeec}canvas{display:block;width:100%;height:100%;touch-action:none;outline:0}#status{position:fixed;inset:0;display:grid;place-items:center;color:#43564b;font:14px/1.8 system-ui,sans-serif;letter-spacing:.15em}#status[hidden]{display:none}</style></head><body><canvas aria-label="教学楼三维微缩模型；拖动旋转，滚轮缩放，双击复位" tabindex="0"></canvas><div id="status">正在打开微缩景观…</div><script id="model-data" type="application/octet-stream">''' + encoded + '''</script><script>''' + js + '''</script></body></html>'''
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(html, encoding='utf-8')
    print(json.dumps({'file':str(args.output), 'bytes':args.output.stat().st_size, 'model_bytes':len(data), 'offline':True}, ensure_ascii=False))

if __name__ == '__main__':
    main()
