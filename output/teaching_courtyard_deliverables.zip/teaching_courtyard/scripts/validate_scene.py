"""Check six occupied floors, B1, reversible section geometry and spatial bounds."""
import bpy,os,sys,json,struct
from mathutils import Vector
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
bpy.ops.wm.open_mainfile(filepath=os.path.join(ROOT,'output/teaching_courtyard.blend'))
s=bpy.data.scenes['01_Section_Display_6F_B1'];full=bpy.data.scenes['02_Full_Building_6F_B1']
cut='90_Section_Removable_Original_Building_Parts'
assert s.view_layers[0].layer_collection.children[cut].exclude
assert not full.view_layers[0].layer_collection.children[cut].exclude
assert s['Aboveground_storeys']==6 and s['Basement_storeys']==1
assert list(s['Floor_elevations'])==[0,3.15,6.30,9.45,12.60,15.75]
wing=[o for o in s.objects if o.get('part')=='wing']
assert {o['storey'] for o in wing}=={1,2,3,4,5,6}
assert all(len([o for o in wing if o['storey']==i])==4 for i in range(1,7))
assert len([o for o in s.objects if o.get('part')=='return_stair'])==6
assert len([o for o in s.objects if o.get('part')=='clock_tower'])==1
assert any(o.name.startswith('Eighteen real treads') for o in s.objects)
roots=[o for o in s.objects if 'plant_root' in o]
large=[o for o in roots if o.name.startswith('Central tall evergreen')];assert len(large)==1
assert abs(large[0]['plant_root'][2]+3.11)<.001
assert all(not o.animation_data for o in s.objects if 'storey' in o)
bpy.context.window.scene=full
maximum=[0,0]
for fr in [1,31,61,91,121]:
    full.frame_set(fr);deps=bpy.context.evaluated_depsgraph_get()
    for o in full.objects:
        if o.type!='MESH' or o.name.startswith('Studio ground'):continue
        ev=o.evaluated_get(deps)
        for v in ev.bound_box:
            p=ev.matrix_world@Vector(v);maximum=[max(maximum[0],abs(p.x)),max(maximum[1],abs(p.y))]
            assert abs(p.x)<=23.01 and abs(p.y)<=32.01,(fr,o.name,tuple(p))
assert not any(i.filepath and not i.packed_file for i in bpy.data.images if i.source=='FILE')
assert s.render.filepath=='//teaching_courtyard.png'
with open(os.path.join(ROOT,'output/teaching_courtyard.glb'),'rb') as f:b=f.read()
j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]])
removable=[n for n in j['nodes'] if n.get('extras',{}).get('section_removable')]
assert len(removable)>5
assert not any('uri' in v for v in j.get('buffers',[]))
report={'result':'passed','aboveground_floors':6,'basement_floors':1,'floor_elevations':[0,3.15,6.30,9.45,12.60,15.75],'basement_elevation':-3.15,'real_return_stair_connections':6,'courtyard_descending_treads':18,'full_geometry_preserved':True,'removable_section_objects':len(removable),'animated_architecture':False,'animated_foliage_clips':len(j.get('animations',[])),'base_dimensions':[46,64],'maximum_xy':maximum,'all_materials_embedded':True}
with open(os.path.join(ROOT,'output/validation.json'),'w') as f:json.dump(report,f,indent=2)
print(json.dumps(report))
