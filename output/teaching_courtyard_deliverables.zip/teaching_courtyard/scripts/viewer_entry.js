import * as THREE from '../.viewer-tools/node_modules/three/build/three.module.js';
import { OrbitControls } from '../.viewer-tools/node_modules/three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from '../.viewer-tools/node_modules/three/examples/jsm/loaders/GLTFLoader.js';

const canvas=document.querySelector('canvas'),status=document.querySelector('#status');
const renderer=new THREE.WebGLRenderer({canvas,antialias:true,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(devicePixelRatio||1,1.5));renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.08;
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
const scene=new THREE.Scene();scene.background=new THREE.Color('#e8eeec');
const camera=new THREE.OrthographicCamera(-44,44,38,-38,.1,400);
const initialTarget=new THREE.Vector3(0,5,0),initialPosition=initialTarget.clone().add(new THREE.Vector3(46,87.98,75));
camera.position.copy(initialPosition);
const controls=new OrbitControls(camera,canvas);controls.target.copy(initialTarget);controls.enableDamping=true;controls.dampingFactor=.075;
controls.minZoom=.5;controls.maxZoom=7;controls.minPolarAngle=.10;controls.maxPolarAngle=Math.PI*.487;controls.autoRotateSpeed=.25;controls.update();
scene.add(new THREE.HemisphereLight(0xd7eaff,0x70735d,1.65));
const sun=new THREE.DirectionalLight(0xffedd5,2.5);sun.position.set(-30,65,45);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);
Object.assign(sun.shadow.camera,{left:-45,right:45,top:45,bottom:-45,near:.5,far:150});sun.shadow.normalBias=.07;sun.shadow.bias=-.00010;scene.add(sun);
const fill=new THREE.DirectionalLight(0xdcecff,.45);fill.position.set(30,30,-20);scene.add(fill);
const studio=new THREE.Mesh(new THREE.PlaneGeometry(500,500),new THREE.MeshStandardMaterial({color:0xe1e8e4,roughness:1}));studio.rotation.x=-Math.PI/2;studio.position.y=-4.465;studio.receiveShadow=true;scene.add(studio);
const gradient=new THREE.DataTexture(new Uint8Array([140,216,255]),3,1,THREE.RedFormat);gradient.minFilter=gradient.magFilter=THREE.NearestFilter;gradient.needsUpdate=true;
const cache=new Map();
function toon(original){
  if(original.metalness>.15||/glass|glazing/i.test(original.name))return original;
  if(cache.has(original.uuid))return cache.get(original.uuid);
  const m=new THREE.MeshToonMaterial({color:original.color,gradientMap:gradient,side:original.side});m.name=original.name;cache.set(original.uuid,m);return m;
}
let model,mixer,section=true,removable=[],transition=null;
function setSection(value){section=value;removable.forEach(o=>o.visible=!section);if(window.__campus)window.__campus.section=section;}
function resize(){const aspect=innerWidth/innerHeight;renderer.setSize(innerWidth,innerHeight);const half=Math.max(37.4,44/aspect);Object.assign(camera,{left:-half*aspect,right:half*aspect,top:half,bottom:-half});camera.updateProjectionMatrix();}
addEventListener('resize',resize);resize();
function reset(){transition=null;setSection(true);camera.position.copy(initialPosition);controls.target.copy(initialTarget);camera.zoom=1;camera.updateProjectionMatrix();controls.update();}
function preset(number){
  if(number===1){setSection(true);transition={position:initialPosition.clone(),target:initialTarget.clone(),zoom:1};}
  if(number===2){setSection(false);transition={position:initialPosition.clone(),target:initialTarget.clone(),zoom:1};}
  if(number===3){setSection(true);transition={position:new THREE.Vector3(1,19,20),target:new THREE.Vector3(0,4,-2),zoom:2.00};}
}
canvas.addEventListener('dblclick',reset);controls.addEventListener('start',()=>transition=null);
addEventListener('keydown',e=>{const k=e.key.toLowerCase();if(k==='r'||e.key==='Home')reset();if(k==='c')setSection(!section);if(['1','2','3'].includes(k))preset(Number(k));if(e.code==='Space'){e.preventDefault();controls.autoRotate=!controls.autoRotate;}});
const raw=atob(document.querySelector('#model-data').textContent.trim()),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);
new GLTFLoader().parse(bytes.buffer,'',gltf=>{
  model=gltf.scene;
  model.traverse(o=>{if(o.userData.section_removable)removable.push(o);if(o.isMesh){o.castShadow=o.receiveShadow=true;o.material=Array.isArray(o.material)?o.material.map(toon):toon(o.material);}});
  scene.add(model);setSection(true);
  if(gltf.animations.length){mixer=new THREE.AnimationMixer(model);gltf.animations.forEach(a=>mixer.clipAction(a).play());}
  window.__campus={scene,camera,controls,renderer,model,animations:gltf.animations.length,removable,section,setSection,preset,reset};
  status.hidden=true;document.documentElement.dataset.ready='true';
},error=>{console.error(error);status.textContent='请使用支持 WebGL 2 的 Chrome 或 Edge 打开模型。';document.documentElement.dataset.ready='error';});
const clock=new THREE.Clock();
renderer.setAnimationLoop(()=>{
  const elapsed=clock.getDelta(),dt=Math.min(elapsed,.05);if(mixer)mixer.update(dt);
  if(transition){const t=1-Math.exp(-Math.min(elapsed,.5)*6);camera.position.lerp(transition.position,t);controls.target.lerp(transition.target,t);camera.zoom=THREE.MathUtils.lerp(camera.zoom,transition.zoom,t);camera.updateProjectionMatrix();if(camera.position.distanceTo(transition.position)<.025&&Math.abs(camera.zoom-transition.zoom)<.002)transition=null;}
  controls.update();renderer.render(scene,camera);
});
