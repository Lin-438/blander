"""Bundle the real model, offline viewer, matching render and reproducible sources."""
from pathlib import Path
from hashlib import sha256
import json,struct,zipfile
root=Path(__file__).resolve().parents[1]
files=[root/'README.md']+sorted((root/'scripts').glob('*.py'))+sorted((root/'scripts').glob('*.js'))
files += [root/'.viewer-tools'/name for name in ('package.json','package-lock.json')]
files += [root/'output'/name for name in ('teaching_courtyard.blend','teaching_courtyard.glb','teaching_courtyard.png','viewer.html','validation.json')]
for f in files:assert f.is_file() and f.stat().st_size>0,f
assert json.loads((root/'output/validation.json').read_text())['result']=='passed'
png=(root/'output/teaching_courtyard.png').read_bytes();assert png[:8]==b'\x89PNG\r\n\x1a\n' and struct.unpack_from('>II',png,16)==(2000,1700)
glb=(root/'output/teaching_courtyard.glb').read_bytes();assert glb[:4]==b'glTF' and struct.unpack_from('<I',glb,8)[0]==len(glb)
j=json.loads(glb[20:20+struct.unpack_from('<I',glb,12)[0]]);assert not any('uri' in b for b in j.get('buffers',[]))
checksums=root/'SHA256SUMS.txt';checksums.write_text(''.join(f'{sha256(f.read_bytes()).hexdigest()}  {f.relative_to(root).as_posix()}\n' for f in files));files.append(checksums)
archive=root/'output/teaching_courtyard_deliverables.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for f in files:z.write(f,'teaching_courtyard/'+f.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'archive':str(archive),'files':len(files),'bytes':archive.stat().st_size,'sha256':sha256(archive.read_bytes()).hexdigest(),'render':[2000,1700]}))
