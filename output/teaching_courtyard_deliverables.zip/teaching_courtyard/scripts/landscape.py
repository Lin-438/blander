"""Upper tiled courtyard, genuinely sunken B1 tree court, and modest campus roads."""
import bpy,math,random
from mathutils import Vector
from geometry import *
from layout import *

def build_landscape(arch):
    r=random.Random(438612)
    base=collection('00_Rectangular_Collectible_Base')
    court=collection('20_Upper_Tiled_Courtyard')
    sunken=collection('21_Sunken_Basement_Tree_Courtyard')
    glasscol=collection('22_Local_Triangular_Glass_Skylight')
    green=collection('23_Courtyard_Trees_and_Planting')
    outside=collection('24_External_Campus_Paving_and_Bicycles')
    white,cream,pale,floor,frame,metal,dark,glass,brown,black=arch['materials']
    stone=material('Light grey miniature plinth',(.44,.48,.46),.84)
    soil=material('Rich dark planter soil',(.09,.105,.05),.96)
    turf=material('Low campus planting ground cover',(.13,.24,.072),.9)
    asphalt=material('Muted campus road asphalt',(.16,.19,.19),.91)
    tiles=[material('Small pale courtyard tile '+str(i),c,.83) for i,c in enumerate([(.64,.65,.60),(.70,.69,.63),(.59,.62,.59),(.67,.68,.64)])]
    joint=material('Fine grey paving grout',(.34,.39,.37),.9)
    bark=material('Evergreen bark warm grey brown',(.14,.115,.07),.92)
    greens=[material('Evergreen leaf cluster '+str(i),c,.88) for i,c in enumerate([(.034,.105,.045),(.055,.16,.053),(.085,.23,.064),(.14,.29,.085),(.21,.36,.115)])]
    cube('Complete rectangular presentation base',(0,0,-3.95),(BASE_X,BASE_Y,.90),stone,base,.15)
    cube('Recessed lower base reveal',(0,0,-4.34),(45.86,63.86,.11),dark,base,.03)
    # The ground is assembled around the building and the excavated basement.
    for name,x,y,sx,sy in [('west',-20,0,6,64),('east',20,0,6,64),('rear',0,28,34,8)]:
        cube('Solid external ground '+name,(x,y,-1.73),(sx,sy,3.46),stone,base,.015)
    # Front terrain is also retained, but hidden in the architectural section view.
    front=cube('Front ground removable to expose basement section',(0,-28,-1.73),(34,8,3.46),stone,arch['cut'],.015);front['section_removable']=True
    fore=cube('Front paving removable with architectural section',(0,-28,.035),(34,8,.07),floor,arch['cut'],.005);fore['section_removable']=True
    # Side pedestrian lanes and a restrained narrow road; no lake or invented facilities.
    for side in [-1,1]:
        cube('Exterior pedestrian paving',(side*18.4,0,.04),(2.6,49,.08),floor,outside,.008)
        cube('Campus side road',(side*21.45,0,.04),(2.8,61,.07),asphalt,outside,.005)
        line=Batch()
        for y in range(-28,30,5):line.box((side*22.55,y,.082),(.07,2.3,.006))
        line.finish('Small road edge markings',[pale],outside)
    cube('Rear campus pedestrian paving',(0,27,.035),(33.6,5.6,.07),floor,outside,.01)
    # Upper court is an actual ground-level deck; the lower court is B1 below it.
    cube('Upper courtyard structural deck',(0,-8,-.19),(16,20,.38),white,court,.01)
    cube('Upper courtyard fine grout bed',(0,-8,.014),(16,20,.028),joint,court,.002)
    cube('Sunken courtyard fine grout bed',(0,10,BASEMENT+.015),(16,16,.03),joint,sunken,.002)
    beds=[(-5.55,-13,2.7,2.7),(-5.55,-6.5,2.2,5.0),(-5.55,-.1,2.8,2.8),(5.55,-13,2.7,2.7),(5.55,-6.5,2.2,5.0),(5.55,-.1,2.8,2.8),(0,-14.3,2.6,2.6)]
    oval=(0,-6.0,2.95,2.05)
    def in_upper_bed(x,y):
        if ((x-oval[0])/oval[2])**2+((y-oval[1])/oval[3])**2<1:return True
        return any(abs(x-cx)<sx/2 and abs(y-cy)<sy/2 for cx,cy,sx,sy in beds)
    def in_lower_bed(x,y):
        return (x-TREE_ROOT[0])**2+(y-TREE_ROOT[1])**2<1.9**2 or (abs(x)>5.35 and y>6.5)
    paving=Batch()
    for lower in [False,True]:
        z=BASEMENT+.037 if lower else .037;ymin,ymax=(2,18) if lower else (-18,2)
        for i in range(53):
            for j in range(round((ymax-ymin)/.30)):
                x=-7.95+(i+.5)*.30;y=ymin+(j+.5)*.30
                if in_lower_bed(x,y) if lower else in_upper_bed(x,y):continue
                paving.box((x,y,z),(.287,.287,.025),r.randrange(4))
    paving.finish('Individually jointed small square courtyard tiles',tiles,court)
    # Visible retaining face, ground-level guardrail and real descending stair.
    retaining=Batch();retaining.box((-2,1.91,-1.60),(12,.18,3.10),0)
    retaining.box((7.48,1.91,-1.60),(1.04,.18,3.10),0)
    retaining.finish('Vertical wall between 1F court and B1 garden',[white],sunken)
    rails=Batch();arch['guardrail'](rails,(-8,1.82),(4.0,1.82),0,False);arch['guardrail'](rails,(6.9,1.82),(8,1.82),0,False)
    rails.finish('Upper courtyard silver safety rail at level drop',arch['materials'],sunken)
    steps=Batch();rail=Batch();N=18;run=4.95
    for j in range(N):
        top=-FLOOR_HEIGHT*(j+1)/N;y=2+(j+.5)*run/N
        steps.box((5.45,y,top-.10),(2.5,run/N+.005,.20),0)
    steps.beam((5.45,2,-.15),(5.45,6.95,BASEMENT-.12),2.5,.18,0)
    for x in [4.2,6.7]:
        for h in [.50,1.02]:rail.tube([(x,2,h),(x,6.95,BASEMENT+h)],.029,0,9)
        for j in range(10):
            t=j/9;z=-FLOOR_HEIGHT*t;rail.tube([(x,2+4.95*t,z),(x,2+4.95*t,z+1.02)],.025,0,8)
    steps.finish('Eighteen real treads connecting first floor to basement courtyard',[floor],sunken)
    rail.finish('Handrails following the actual descending courtyard stair',[metal],sunken)
    # Planter rims are separately jointed, like the small pale bricks in the photos.
    roots=[]
    def rect_planter(x,y,sx,sy,z):
        b=Batch();b.box((x,y,z+.11),(sx,sy,.22),0)
        b.box((x,y,z+.24),(sx-.22,sy-.22,.08),1)
        for sign in [-1,1]:
            for j in range(max(1,round(sx/.26))):
                xx=x-sx/2+(j+.5)*sx/max(1,round(sx/.26));b.box((xx,y+sign*(sy/2-.07),z+.29),(sx/max(1,round(sx/.26))-.008,.14,.40),2)
            for j in range(max(1,round(sy/.26))):
                yy=y-sy/2+(j+.5)*sy/max(1,round(sy/.26));b.box((x+sign*(sx/2-.07),yy,z+.29),(.14,sy/max(1,round(sy/.26))-.008,.40),2)
        b.finish('Rectangular pale brick planting bed',[white,soil,tiles[0]],court)
    for x,y,sx,sy in beds:rect_planter(x,y,sx,sy,0)
    for side in [-1,1]:rect_planter(side*6.5,12.2,2.6,10.7,BASEMENT)
    def oval_planter(cx,cy,rx,ry,z,label):
        b=Batch();n=96
        for j in range(n):
            a=j*math.tau/n;bangle=(j+.94)*math.tau/n
            vs=[(cx+xx*math.cos(t),cy+yy*math.sin(t),zz) for zz in [z,z+.44] for xx,yy,t in [(rx,ry,a),(rx,ry,bangle),(rx-.17,ry-.17,bangle),(rx-.17,ry-.17,a)]]
            b.add(vs,[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],0)
        b.finish(label+' jointed pale brick perimeter',[tiles[0]],court)
        polygon=[(cx+(rx-.17)*math.cos(j*math.tau/n),cy+(ry-.17)*math.sin(j*math.tau/n)) for j in range(n)]
        poly_slab(label+' actual soil',polygon,z+.1,.10,soil,court)
    oval_planter(*oval,0,'Upper oval garden bed')
    oval_planter(TREE_ROOT[0],TREE_ROOT[1],1.90,1.90,BASEMENT,'Tall tree circular root planter')

    def tree(name,x,y,z,height,spread,large=False):
        trunk=Batch();leaves=Batch()
        lean=Vector((.18,-.12,0));basep=Vector((x,y,z))
        trunk.tube([basep,basep+Vector((0,0,height*.42)),basep+lean+Vector((0,0,height*.86))],[.46 if large else .16,.27 if large else .10,.055],0,14)
        clusters=[];count=20 if large else 9
        for j in range(count):
            a=j*2.4;level=(.38+j*.023) if large else (.53+j*.038);reach=spread*r.uniform(.37,.72)
            start=basep+Vector((0,0,height*level-1 if large else height*level-.3));end=basep+Vector((math.cos(a)*reach,math.sin(a)*reach,height*level+.5))
            trunk.tube([start,start.lerp(end,.5)+Vector((0,0,.25)),end],[.12 if large else .046,.055 if large else .022,.014],0,9)
            clusters.append((end,spread*.62,spread*.59,1.65 if large else .65))
        clusters.append((basep+Vector((0,0,height-.65 if large else height-.20)),spread*.62,spread*.60,1.1 if large else .55))
        for center,rx,ry,rz in clusters:
            for k in range(240 if large else 115):
                a=r.random()*math.tau;zz=r.uniform(-1,1);rr=math.sqrt(1-zz*zz)*r.uniform(.32,1)
                p=center+Vector((rx*rr*math.cos(a),ry*rr*math.sin(a),rz*zz));L=r.uniform(.32,.56) if large else r.uniform(.22,.38)
                if abs(p.x)+L*.5>22.8 or abs(p.y)+L*.5>31.8:continue
                if name.startswith('Exterior') and abs(x)>17 and p.x*(1 if x>0 else -1)-L*.5<17.45:continue
                leaves.leaf(p,L,L*r.uniform(.45,.65),r.random()*math.tau,r.uniform(-.55,.55),r.randrange(5))
        tr=trunk.finish(name+' trunk and branches',[bark],green,True);tr['plant_root']=[x,y,z]
        foliage=leaves.finish(name+' layered evergreen foliage',greens,green,origin=basep);wave_animation(foliage,'rotation_euler',1,.0016 if large else .003)
        return foliage
    tree('Central tall evergreen in sunken courtyard',*TREE_ROOT,18.0,3.45,True)
    for idx,(x,y) in enumerate([(-5.55,-13),(5.55,-13),(-5.55,-.1),(5.55,-.1),(0,-14.3)]):tree('Pruned upper courtyard tree '+str(idx+1),x,y,.23,3.5 if idx<4 else 4.2,1.03)
    shrubs=Batch();rosettes=Batch()
    for x,y,sx,sy in beds+[(0,-6,4.8,3.0)]:
        for k in range(int(sx*sy*24)):
            px=x+r.uniform(-sx*.43,sx*.43);py=y+r.uniform(-sy*.43,sy*.43)
            if not in_upper_bed(px,py):continue
            z=.50+r.uniform(0,.46);L=r.uniform(.17,.31);shrubs.leaf((px,py,z),L,L*.6,r.random()*math.tau,r.uniform(-.4,.4),r.randrange(4))
    for side in [-1,1]:
        for k in range(1000):
            x=side*r.uniform(5.42,7.52);y=r.uniform(7.05,17.30);z=BASEMENT+.46+r.uniform(0,.32)
            shrubs.leaf((x,y,z),r.uniform(.16,.32),.12,r.random()*math.tau,.2,r.randrange(4))
        for cy in [7.6,11.8,15.7]:
            for k in range(35):
                a=k*2.4;L=r.uniform(.52,.95);x=side*6.4+math.cos(a)*L*.25;y=cy+math.sin(a)*L*.25
                rosettes.leaf((x,y,BASEMENT+.4+L*.45),L,L*.11,a,r.uniform(.5,1.2),r.randrange(4))
    shrubs.finish('Dense orderly ground cover entirely within brick planting beds',greens,green)
    rosettes.finish('Radiating ornamental leaves in lower courtyard beds',greens,green)

    # A local triangular-unit skylight near the entrance covers only a narrow strip.
    # The central courtyard remains open to the sky.
    gmat=material('Low saturation translucent cyan skylight glass',(.17,.32,.34),.19,.12,False)
    p=gmat.node_tree.nodes.get('Principled BSDF');p.inputs['Transmission Weight'].default_value=.32;p.inputs['Alpha'].default_value=.64;gmat.diffuse_color=(.17,.32,.34,.64)
    gmat.surface_render_method='DITHERED'
    panes=Batch();ribs=Batch()
    for j in range(8):
        x0=-7.8+j*1.95;x1=x0+1.95
        v=[(x0,-17.85,3.24),(x1,-17.85,3.24),(x1,-15.95,3.24),(x0,-15.95,3.24),((x0+x1)/2,-16.9,4.12)]
        for a,b in [(0,1),(1,2),(2,3),(3,0)]:
            panes.add([v[a],v[b],v[4]],[(0,1,2)])
            ribs.tube([v[a],v[b]],.055,0,8);ribs.tube([v[a],v[4]],.043,0,8)
    panes.finish('Eight local glass pyramid skylight modules',[gmat],glasscol)
    ribs.finish('Dark metal triangular skylight framing',[dark],glasscol)
    # Exterior greenery stays small so that it does not hide the six-storey facades.
    for idx,(x,y) in enumerate([(-19.0,-16),(-19.0,0),(-19,15),(19.0,-4),(19.0,14),(-10,28.4),(9,28.4)]):
        tree('Exterior campus evergreen '+str(idx+1),x,y,.14,5.5,1.75)
        cube('Exterior tree soil square',(x,y,.10),(1.5,1.5,.18),soil,outside,.01)
    # A few small bicycles at the perimeter, no people or moving cars.
    bikes=Batch()
    for j in range(5):
        x=19.25;y=-23+j*1.1;z=.45
        for yy in [y-.52,y+.52]:
            pts=[(x,yy+.37*math.cos(k*math.tau/24),z+.37*math.sin(k*math.tau/24)) for k in range(25)]
            bikes.tube(pts,.035,0,7)
            for k in range(8):bikes.tube([(x,yy,z),pts[k*3]],.009,1,5)
        a=(x,y-.52,z);b=(x,y+.52,z);c=(x,y-.05,.90);d=(x,y+.35,1.02);pedal=(x,y-.05,.44)
        for p,q in [(a,c),(c,pedal),(pedal,a),(pedal,b),(c,d),(d,b)]:bikes.tube([p,q],.026,2,7)
        bikes.box((x,y-.07,.97),(.20,.26,.06),0);bikes.tube([(x,y+.37,1.03),(x,y+.4,1.16)],.025,1,7);bikes.tube([(x-.22,y+.4,1.16),(x+.22,y+.4,1.16)],.023,1,7)
    bikes.finish('Five modest parked campus bicycles',[dark,metal,cream],outside)
    return {'base':base,'court':court,'sunken':sunken,'glass':glasscol,'green':green,'outside':outside}
