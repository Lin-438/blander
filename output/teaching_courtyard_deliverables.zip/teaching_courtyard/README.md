# 现代校园教学楼 · 六层与下沉中庭

根据十二张实景照片制作的可编辑三渲二建筑模型。主体包含地上六层、地下一层，两条平行教学楼翼、端部连接空间、开放式走廊、折返楼梯、入口白色矩形框架、钟楼及两种高度的露天庭院。

## 直接查看

解压压缩包，进入 `output` 文件夹，用 Chrome 或 Edge 打开 `viewer.html`。模型和全部运行脚本已嵌入网页，无需联网或启动服务器。

- 左键拖动旋转，滚轮缩放，右键拖动平移；触屏支持单指旋转、双指缩放与平移。
- **C**：切换剖切展示与完整建筑。
- **1**：整体剖切视角；**2**：整体完整建筑；**3**：中庭近景。
- 双击或按 **R / Home** 复位；空格切换自动旋转。

默认采用局部剖切：暂时隐藏入口中央连接体的上部、靠近镜头的部分高层及前侧土体，使中庭、走廊和地下空间同时可见。所有构件保留在模型中，按 C 即可恢复；没有把原建筑改成三层或删掉楼层。网页加载完成后不显示按钮、标题或水印。

## 文件

- `output/teaching_courtyard.blend`：可编辑 Blender 模型，包含三渲二材质、灯光、相机和叶片轻微动画。
- `output/teaching_courtyard.glb`：完整建筑的通用三维交换文件，含所有剖切时隐藏的原始构件。
- `output/viewer.html`：离线交互网页版，自动应用三渲二材质。
- `output/teaching_courtyard.png`：从 Blender 模型直接渲染的 2000 × 1700 高清剖切效果图。
- `scripts/`：可复现建模、导出与打包脚本。
- `output/validation.json`：楼层、地下层、连接楼梯、展示切换和模型边界检查结果。

Blender 4.3 或更新版本打开模型后，可在顶部场景选择器切换 `01_Section_Display_6F_B1` 与 `02_Full_Building_6F_B1`。数字键盘 0 返回相机，F12 渲染当前场景。集合按建筑、地下层、楼梯、钟楼、上层庭院、下沉庭院、采光顶和植物组织。`90_Section_Removable_Original_Building_Parts` 保存剖切展示隐藏的完整几何。

GLB 使用兼容性较好的 PBR 材质，导入不同软件后默认显示可能不同。Blender 文件与所附网页保留本项目三渲二表现。网页里的 C 键显示控制由 GLB 的 `section_removable` 对象属性驱动。

## 空间依据与范围

地上层楼面标高为 0、3.15、6.30、9.45、12.60、15.75，地下层为 -3.15，主屋顶为 18.90。钟楼上部为装饰及钟面构件，不另计为教学楼楼层。楼梯连续连接地下层至第六层。上层铺装庭院与下沉树庭之间有真实高差、挡墙、栏杆和十八级下降踏步。

大乔木根部位于下沉庭院的圆形砖砌种植池。入口附近只设置一条局部三角形玻璃单元采光顶；中央庭院保持露天。外部只设置少量树木、道路和五辆静止自行车。建筑没有人物、泳池、喷泉或与照片无关的园林设施；未添加无法准确还原的标识文字。

实景照片可确定可见形制和楼层关系，但不能提供完整测绘尺寸及所有背面细节。本模型尺寸、局部未见平面和隐蔽构造为依据照片作出的视觉估计，不是测绘或施工模型。原始照片未随本包分发。

## 复现

在本目录运行：

```bash
blender --background --threads 5 --python-exit-code 1 --python scripts/build_scene.py
blender --background --threads 5 output/teaching_courtyard.blend --python scripts/render_scene.py
blender --background --python-exit-code 1 --python scripts/validate_scene.py
npm ci --prefix .viewer-tools
python scripts/package_viewer.py
python scripts/package_deliverables.py
```

建模不依赖外部贴图。设置 `CAMPUS_RENDER=1` 可在建模导出后接着渲染。Three.js 0.170.0 与 esbuild 0.24.2 版本已锁定；Three.js MIT 许可嵌入 HTML。`SHA256SUMS.txt` 可核验包内文件。
