"""Create the self-contained scene delivery, excluding caches and dependencies."""
from pathlib import Path
from hashlib import sha256
import json
import struct
import zipfile

root = Path(__file__).resolve().parents[1]
files = [root / 'README.md']
files += sorted((root / 'scripts').glob('*.py'))
files += sorted((root / 'scripts').glob('*.js'))
files += [root / '.viewer-tools' / name for name in ('package.json', 'package-lock.json')]
files += [root / 'output' / name for name in (
    'campus_waterside.blend', 'campus_waterside.glb',
    'campus_waterside.png', 'viewer.html',
)]
for file in files:
    assert file.is_file() and file.stat().st_size > 0, file
png = (root / 'output/campus_waterside.png').read_bytes()
assert png[:8] == b'\x89PNG\r\n\x1a\n'
assert struct.unpack_from('>II', png, 16) == (1800, 1800)
glb = (root / 'output/campus_waterside.glb').read_bytes()
assert glb[:4] == b'glTF' and struct.unpack_from('<I', glb, 8)[0] == len(glb)
header_length = struct.unpack_from('<I', glb, 12)[0]
gltf = json.loads(glb[20:20 + header_length])
assert not any('uri' in buffer for buffer in gltf.get('buffers', []))
assert len(gltf['animations']) == 16
checksums = root / 'SHA256SUMS.txt'
checksums.write_text(''.join(
    f'{sha256(file.read_bytes()).hexdigest()}  {file.relative_to(root).as_posix()}\n'
    for file in files
), encoding='utf-8')
files.append(checksums)
archive = root / 'output/campus_waterside_v2_deliverables.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as package:
    for file in files:
        package.write(file, 'campus_waterside/' + file.relative_to(root).as_posix())
with zipfile.ZipFile(archive) as package:
    assert package.testzip() is None
print(json.dumps({
    'archive': str(archive), 'files': len(files), 'bytes': archive.stat().st_size,
    'sha256': sha256(archive.read_bytes()).hexdigest(),
    'render': [1800, 1800], 'glb_animations': len(gltf['animations']),
}, ensure_ascii=False))
