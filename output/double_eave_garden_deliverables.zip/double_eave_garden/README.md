# 双层中式古亭 · 三渲二微缩园林模型

依据四张双层古亭实景照片制作的可编辑三维模型，延续此前校园水榭项目的柔和三渲二材质和离线网页交互方式。

## 打开模型

- **网页版**：解压整个压缩包，进入 `output` 文件夹，双击 `viewer.html`，使用 Chrome 或 Edge 打开。所有模型数据与脚本已嵌入，无需联网、安装插件或启动服务器。
- **Blender**：用 Blender 4.3 或更新版本打开 `output/double_eave_garden.blend`。材质预览/渲染预览可查看三渲二材质；按数字键盘 `0` 回到预设镜头，按 `F12` 渲染。
- **其他三维软件**：导入 `output/double_eave_garden.glb`。它包含真实网格、通用 PBR 材质及轻微植物/水面动画；不同软件的默认着色会有差异。Blender 文件和离线网页保留本项目的三渲二表现。
- **效果图**：`output/double_eave_garden.png`，1800 × 1800，直接由所附 Blender 模型渲染。

网页操作：鼠标左键拖动旋转，滚轮缩放，右键拖动平移；双击或按 `R`/`Home` 复位；空格切换自动旋转。触屏可单指旋转、双指缩放/平移。加载完成后无可见 UI。

## 模型内容

主体为六根深红棕色圆柱支撑的开敞六角亭，两层独立飞檐、棕红与灰褐色筒瓦、深棕色葫芦宝顶。上下屋顶之间为真正镂空的装饰围板。亭内保留五段弧形靠背石长椅，前侧留出入口；浅灰六角平台中央为淡红几何铺装，正面连接三道石阶。

园林包含前方红褐步道、朴素石长凳、入口两侧带真实孔洞的太湖石、紫花灌木、剑形叶植物、背景常绿树和后侧竹林，以及亭后与侧面的池塘。场景置于完整正方形石质底座上，无人物、现代楼房、文字牌匾或装饰灯。

建筑保持静止。第 1–120 帧、24 fps 的循环包含轻微水波、浮叶和枝叶摆动。竹子根部位于后侧土壤种植区，植物位置及动画范围经过检查。

模型以照片中的形制、配色和空间关系为依据；缺少实测尺寸和被遮挡部分的照片，因此尺寸及不可见细节是视觉估计，不是测绘级复原。原始参考照片未随本包分发。

## 编辑与复现

Blender 中按底座、池塘、平台与石阶、柱梁与花格、座椅、下层瓦顶、上层瓦顶、宝顶、园路、景观石、植被及灯光分集合。屋顶瓦片、镂空纹样和太湖石孔洞均为真实几何。

在本目录执行：

```bash
blender --background --threads 5 --python-exit-code 1 --python scripts/build_scene.py
blender --background --python-exit-code 1 --python scripts/validate_scene.py
npm ci --prefix .viewer-tools
python scripts/package_viewer.py
python scripts/package_deliverables.py
```

`GARDEN_SKIP_RENDER=1` 只生成模型；`GARDEN_RENDER_PERCENT=55` 可快速生成较小预览，正式交付使用默认 100%。所有程序化几何与材质无需外部贴图。网页重打包使用固定版本 Three.js 0.170.0 和 esbuild 0.24.2；Three.js MIT 许可已嵌入 HTML。

`output/validation.json` 记录结构、植物落点和动画边界检查；`SHA256SUMS.txt` 可核验包内文件。
