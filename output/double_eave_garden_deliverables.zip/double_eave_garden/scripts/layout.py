"""Photo-based proportions shared by the editable pavilion and its garden."""
import math
from mathutils import Vector

BASE_HALF=7.25
GROUND=.28
WATER=.12
CENTER=Vector((0,.80,0))
ANGLES=[i*math.tau/6 for i in range(6)]
PLATFORM=[(3.0*math.cos(a),.8+3.0*math.sin(a)) for a in ANGLES]
POND=[(-6.4,.2),(-5.5,-.1),(-4.5,.2),(-3.7,1.1),(-3.1,2.1),(-2.2,3.4),
      (-.7,3.75),(1.5,3.7),(2.8,3.25),(3.4,2.2),(4.15,1.5),(5.9,1.6),
      (6.45,2.7),(6.4,4.65),(5.25,5.55),(2.9,5.9),(-1.7,5.95),(-4.6,5.55),(-6.2,4.35)]
PATHS=[([(-6.8,-2.7),(-5.5,-2.65),(-4.1,-3.15),(-2.0,-3.22),(0,-3.15),(2.8,-3.7),(5.2,-4.4),(6.8,-3.9)],1.08),
       ([(-4.0,-3.05),(-4.6,-1.8),(-5.7,-1.2),(-6.8,-.9)],.78),
       ([(-2.0,-3.22),(-2.6,-4.2),(-2.7,-5.2)],1.05)]
BENCH_COURT=(-2.7,-5.25,1.25)

def smooth_path(points,steps=12,closed=False):
    vectors=[Vector(p) for p in points]
    if closed: padded=[vectors[-1]]+vectors+[vectors[0],vectors[1]]; count=len(vectors)
    else: padded=[vectors[0]]+vectors+[vectors[-1]]; count=len(vectors)-1
    result=[]
    for i in range(count):
        p0,p1,p2,p3=padded[i:i+4]
        for j in range(steps):
            t=j/steps
            result.append((2*p1+(-p0+p2)*t+(2*p0-5*p1+4*p2-p3)*t*t+(-p0+3*p1-3*p2+p3)*t*t*t)*.5)
    if not closed: result.append(vectors[-1])
    return result

POND_OUTLINE=[tuple(p) for p in smooth_path(POND,4,True)]
PATH_LINES=[(smooth_path(points),width) for points,width in PATHS]

def distance_to_segment(point,a,b):
    p=Vector(point); direction=b-a
    t=max(0,min(1,(p-a).dot(direction)/max(direction.length_squared,1e-9)))
    return (p-a-direction*t).length

def on_path(x,y,margin=0):
    for line,width in PATH_LINES:
        if any(distance_to_segment((x,y),a,b)<width/2+margin for a,b in zip(line,line[1:])): return True
    cx,cy,rad=BENCH_COURT
    return math.hypot(x-cx,y-cy)<rad+margin

def on_stairs(x,y,margin=0):
    return -1.2-margin<x<1.2+margin and -2.78-margin<y<-1.5+margin
