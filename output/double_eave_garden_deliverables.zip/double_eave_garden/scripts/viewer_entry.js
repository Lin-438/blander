import * as THREE from '../.viewer-tools/node_modules/three/build/three.module.js';
import { OrbitControls } from '../.viewer-tools/node_modules/three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from '../.viewer-tools/node_modules/three/examples/jsm/loaders/GLTFLoader.js';
import { Reflector } from '../.viewer-tools/node_modules/three/examples/jsm/objects/Reflector.js';

const canvas = document.querySelector('canvas');
const status = document.querySelector('#status');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(devicePixelRatio || 1, 1.5));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.08;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene();
scene.background = new THREE.Color('#e8eeec');
const camera = new THREE.OrthographicCamera(-20, 20, 20, -20, .1, 180);
const initialTarget = new THREE.Vector3(0, 2.55, 0);
const initialPosition = initialTarget.clone().add(new THREE.Vector3(11, 22.825, 20));
camera.position.copy(initialPosition);
const controls = new OrbitControls(camera, canvas);
controls.target.copy(initialTarget);
controls.enableDamping = true;
controls.dampingFactor = .075;
controls.minZoom = .55;
controls.maxZoom = 6;
controls.minPolarAngle = .12;
controls.maxPolarAngle = Math.PI * .485;
controls.autoRotateSpeed = .35;
controls.update();

scene.add(new THREE.HemisphereLight(0xd5e9ff, 0x656b53, 1.65));
const sunlight = new THREE.DirectionalLight(0xffe7c8, 2.65);
sunlight.position.set(-9, 22, 12);
sunlight.castShadow = true;
sunlight.shadow.mapSize.set(2048, 2048);
Object.assign(sunlight.shadow.camera, { left: -13, right: 13, top: 13, bottom: -13, near: .5, far: 65 });
sunlight.shadow.normalBias = .045;
sunlight.shadow.bias = -.00015;
scene.add(sunlight);
const fill = new THREE.DirectionalLight(0xd7ebff, .40);
fill.position.set(10, 12, -8);
scene.add(fill);
const studio = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), new THREE.MeshStandardMaterial({ color: 0xe1e8e4, roughness: 1 }));
studio.rotation.x = -Math.PI / 2;
studio.position.y = -.43;
studio.receiveShadow = true;
scene.add(studio);

const gradient = new THREE.DataTexture(new Uint8Array([135, 211, 255]), 3, 1, THREE.RedFormat);
gradient.minFilter = gradient.magFilter = THREE.NearestFilter;
gradient.needsUpdate = true;
const toonCache = new Map();
function toonMaterial(original) {
  if (original.metalness > .15 || /glass|water/i.test(original.name)) return original;
  if (toonCache.has(original.uuid)) return toonCache.get(original.uuid);
  const material = new THREE.MeshToonMaterial({ color: original.color, gradientMap: gradient, side: original.side });
  material.name = original.name;
  toonCache.set(original.uuid, material);
  return material;
}

let model, mixer, pond, elapsed = 0;
function resize() {
  const width = innerWidth, height = innerHeight, aspect = width / height;
  renderer.setSize(width, height);
  const half = 23.5 / (2 * Math.min(aspect, 1));
  Object.assign(camera, { left: -half * aspect, right: half * aspect, top: half, bottom: -half });
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize);
resize();
function resetView() {
  camera.position.copy(initialPosition);
  camera.zoom = 1;
  camera.updateProjectionMatrix();
  controls.target.copy(initialTarget);
  controls.update();
}
canvas.addEventListener('dblclick', resetView);
addEventListener('keydown', event => {
  if (event.key.toLowerCase() === 'r' || event.key === 'Home') resetView();
  if (event.code === 'Space') { event.preventDefault(); controls.autoRotate = !controls.autoRotate; }
});
const raw = atob(document.querySelector('#model-data').textContent.trim());
const bytes = new Uint8Array(raw.length);
for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);

new GLTFLoader().parse(bytes.buffer, '', gltf => {
  model = gltf.scene;
  model.traverse(object => {
    if (!object.isMesh) return;
    object.castShadow = object.receiveShadow = true;
    object.material = Array.isArray(object.material) ? object.material.map(toonMaterial) : toonMaterial(object.material);
    if (/Quiet.?pond.?water.?surface/i.test(object.name)) object.visible = false;
  });
  scene.add(model);

  // Actual mirrored geometry and a very slight ripple; the editable GLB retains
  // the original animated pond mesh for applications without this viewer.
  const shader = {
    uniforms: { ...THREE.UniformsUtils.clone(Reflector.ReflectorShader.uniforms), time: { value: 0 } },
    vertexShader: Reflector.ReflectorShader.vertexShader,
    fragmentShader: Reflector.ReflectorShader.fragmentShader
      .replace('uniform vec3 color;', 'uniform vec3 color; uniform float time;')
      .replace('vec4 base = texture2DProj( tDiffuse, vUv );', 'vec4 uv = vUv; uv.xy += uv.w * vec2(sin(uv.y / uv.w * 43.0 + time * .3), cos(uv.x / uv.w * 38.0 + time * .22)) * .0007; vec4 base = texture2DProj(tDiffuse, uv);')
      .replace('blendOverlay( base.rgb, color )', 'mix(vec3(.035, .105, .065), base.rgb * vec3(.58, .72, .58), .34)')
  };
  pond = new Reflector(new THREE.PlaneGeometry(14.15, 14.15), { textureWidth: 768, textureHeight: 768, clipBias: .002, shader });
  pond.rotation.x = -Math.PI / 2;
  pond.position.y = .125;
  // Three.js r170's stock Reflector uses perspective-specific oblique clipping.
  // An orthographic mirrored camera plus a world-space clip plane preserves
  // true isometric projection and removes geometry below the water correctly.
  const reflectedCamera = camera.clone();
  const waterPlane = new THREE.Plane(new THREE.Vector3(0, 1, 0), -.127);
  const direction = new THREE.Vector3();
  const lookTarget = new THREE.Vector3();
  pond.onBeforeRender = (renderer, scene, viewingCamera) => {
    reflectedCamera.copy(viewingCamera);
    viewingCamera.getWorldDirection(direction);
    lookTarget.copy(viewingCamera.position).add(direction);
    reflectedCamera.position.y = 2 * pond.position.y - viewingCamera.position.y;
    lookTarget.y = 2 * pond.position.y - lookTarget.y;
    reflectedCamera.up.copy(viewingCamera.up).multiply(new THREE.Vector3(1, -1, 1));
    reflectedCamera.lookAt(lookTarget);
    reflectedCamera.updateMatrixWorld();
    pond.material.uniforms.textureMatrix.value.set(
      .5, 0, 0, .5, 0, .5, 0, .5, 0, 0, .5, .5, 0, 0, 0, 1
    ).multiply(reflectedCamera.projectionMatrix)
      .multiply(reflectedCamera.matrixWorldInverse).multiply(pond.matrixWorld);
    const renderTarget = renderer.getRenderTarget();
    const clipping = renderer.clippingPlanes;
    const shadows = renderer.shadowMap.autoUpdate;
    pond.visible = false;
    renderer.clippingPlanes = [waterPlane];
    renderer.shadowMap.autoUpdate = false;
    renderer.setRenderTarget(pond.getRenderTarget());
    renderer.render(scene, reflectedCamera);
    renderer.setRenderTarget(renderTarget);
    renderer.clippingPlanes = clipping;
    renderer.shadowMap.autoUpdate = shadows;
    pond.visible = true;
  };
  scene.add(pond);
  if (gltf.animations.length) {
    mixer = new THREE.AnimationMixer(model);
    gltf.animations.forEach(clip => mixer.clipAction(clip).play());
  }
  status.hidden = true;
  document.documentElement.dataset.ready = 'true';
  window.__pavilion = { scene, camera, controls, renderer, model, animations: gltf.animations.length, mixer };
}, error => {
  console.error(error);
  status.textContent = '请使用支持 WebGL 2 的浏览器打开模型。';
  document.documentElement.dataset.ready = 'error';
});

const clock = new THREE.Clock();
renderer.setAnimationLoop(() => {
  const dt = Math.min(clock.getDelta(), .05);
  elapsed += dt;
  if (mixer) mixer.update(dt);
  if (pond) pond.material.uniforms.time.value = elapsed;
  controls.update();
  renderer.render(scene, camera);
});
