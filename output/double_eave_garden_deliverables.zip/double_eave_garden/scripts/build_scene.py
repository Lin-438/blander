"""Build an editable double-eaved pavilion and garden from the four reference views.
Run: blender --background --threads 5 --python-exit-code 1 --python scripts/build_scene.py
GARDEN_SKIP_RENDER=1 skips PNG. GARDEN_RENDER_PERCENT=55 makes a quick preview.
"""
import os,sys,math
import bpy
from mathutils import Vector
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT=os.path.join(ROOT,'output');os.makedirs(OUT,exist_ok=True)
sys.path.insert(0,os.path.dirname(__file__))
from geometry import *
from garden import build_garden
from pavilion import build_pavilion
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):bpy.data.collections.remove(c)
garden=build_garden();print('GARDEN_GEOMETRY_READY',flush=True)
pavilion=build_pavilion();print('PAVILION_GEOMETRY_READY',flush=True)
stage=collection('11_Soft_Afternoon_Studio')
bgmat=material('Clean warm grey photographic backdrop',(.78,.81,.80),.94,cel=False)
cube('Studio floor outside the collectible base',(0,0,-.49),(200,200,.12),bgmat,stage,0)
def light(name,typ,loc,energy,color,size=5,target=(0,0,3)):
    d=bpy.data.lights.new(name,typ);d.energy=energy;d.color=color
    if typ=='AREA':d.shape='DISK';d.size=size
    if typ=='SUN':d.angle=math.radians(9)
    o=bpy.data.objects.new(name,d);stage.objects.link(o);o.location=loc
    o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
light('Warm afternoon sunlight from upper left','SUN',(-9,-12,22),2.25,(1,.91,.76))
light('Large soft sky fill','AREA',(5,-1,18),1400,(.71,.84,1),15)
camd=bpy.data.cameras.new('Garden_Isometric_Camera');cam=bpy.data.objects.new('Garden_Isometric_Camera',camd);stage.objects.link(cam)
target=Vector((0,0,2.55));cam.location=target+Vector((11,-20,22.825))
cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();camd.type='ORTHO';camd.ortho_scale=23.5
s=bpy.context.scene;s.camera=cam;s.render.engine='BLENDER_EEVEE_NEXT'
s.render.resolution_x=s.render.resolution_y=1800;s.render.resolution_percentage=int(os.environ.get('GARDEN_RENDER_PERCENT','100'))
s.render.image_settings.file_format='PNG';s.render.fps=24;s.frame_start=1;s.frame_end=120;s.frame_set(1)
s.world.use_nodes=True;bg=s.world.node_tree.nodes.get('Background');bg.inputs[0].default_value=(.65,.78,.92,1);bg.inputs[1].default_value=.45
s.view_settings.view_transform='AgX';s.view_settings.look='AgX - Medium High Contrast';s.view_settings.exposure=.32
s.eevee.use_raytracing=True;s.eevee.taa_render_samples=64
s.render.use_freestyle=True;s.render.line_thickness=.65
ls=bpy.context.view_layer.freestyle_settings.linesets[0];ls.linestyle.color=(.12,.13,.115);ls.linestyle.thickness=.52
ls.select_crease=False;ls.select_silhouette=True;ls.select_external_contour=True;ls.select_border=False
outline=collection('12_Restrained_Architectural_Outlines')
for c in pavilion.values():
    for o in c.objects:outline.objects.link(o)
ls.select_by_collection=True;ls.collection=outline;ls.collection_negation='INCLUSIVE'
s['Project']='双层中式古亭 · 三渲二微缩园林'
s['Reference']='Four user-provided photographs of the red-column double-eaved six-sided pavilion.'
s['Structure']='Six red columns; two separate hexagonal roof tiers; small openwork upper drum, no enclosed storey; weathered brown ceramic; dark gourd finial; five curved stone bench bays; three front steps.'
s['Layout_note']='Visible architectural form and garden relationships reconstructed from photographs. Dimensions and unseen details are visual estimates, not measured survey data.'
s['Animation_note']='Gentle water ripples, floating leaves, tree and bamboo foliage, purple blossoms. All architecture remains static. Frames 1–120 at 24 fps.'
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL'
s.render.filepath='//double_eave_garden.png'
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'double_eave_garden.blend'))
print('EDITABLE_BLEND_SAVED',len(s.objects),flush=True)
# Save cel palettes in .blend; use compatible PBR colors in interchange GLB.
# Offline viewer re-applies a three-band cel material to the GLB geometry.
for m in bpy.data.materials:
    if not m.use_nodes:continue
    p=m.node_tree.nodes.get('Principled BSDF')
    if p:
        for link in list(p.inputs['Base Color'].links):m.node_tree.links.remove(link)
        p.inputs['Base Color'].default_value=m.diffuse_color
bpy.ops.object.select_all(action='DESELECT')
for o in s.objects:
    if o.type=='MESH' and o.name!='Studio floor outside the collectible base':o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'double_eave_garden.glb'),export_format='GLB',use_selection=True,export_apply=True,export_animations=True,export_materials='EXPORT',export_lights=False)
print('INTERCHANGE_GLB_SAVED',flush=True)
if os.environ.get('GARDEN_SKIP_RENDER')!='1':
    bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT,'double_eave_garden.blend'))
    bpy.ops.render.render(write_still=True);print('RENDER_COMPLETE',flush=True)
