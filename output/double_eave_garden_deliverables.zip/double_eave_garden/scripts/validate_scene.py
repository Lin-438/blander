"""Validate the architectural structure, planted ground, bounds, and portability."""
import bpy,sys,os,json
from mathutils import Vector
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0,os.path.dirname(__file__))
from layout import *
from geometry import inside
from garden import plantable
bpy.ops.wm.open_mainfile(filepath=os.path.join(ROOT,'output/double_eave_garden.blend'))
s=bpy.context.scene
def named(prefix):return [o for o in s.objects if o.name.startswith(prefix)]
assert len(named('Main dark red circular column'))==6
assert len(named('Lower roof ivory curved soffit'))==6
assert len(named('Upper roof ivory curved soffit'))==6
assert len(named('Curved stone bench with shaped backrest bay'))==5
assert len(named('Front stone stair tread'))==3
assert len(named('Dark brown double bulb gourd roof finial'))==1
assert len(named('Right entry Taihu stone'))==1 and len(named('Left entry Taihu stone'))==1
assert not any(any(word in o.name.lower() for word in ['library','lamp','lantern','person','vehicle']) for o in s.objects)
plant_roots=[]
for o in s.objects:
    if 'plant_root' in o:plant_roots.append((o.name,tuple(o['plant_root'])))
    if 'plant_roots_xy' in o:
        xy=o['plant_roots_xy'];plant_roots.extend((o.name,(xy[i],xy[i+1])) for i in range(0,len(xy),2))
for name,(x,y) in plant_roots:assert plantable(x,y,.07),(name,x,y)
for o in named('Curved stone bench with shaped backrest bay'):
    for v in o.data.vertices:
        p=o.matrix_world@v.co;assert inside(p.x,p.y,PLATFORM),(o.name,p[:])
architecture=set()
for c in bpy.data.collections:
    if c.name[:2] in {'02','03','04','05','06','07'}:architecture.update(c.objects)
assert all(o.animation_data is None for o in architecture)
bounds=[]
for fr in [1,31,61,91,121]:
    s.frame_set(fr);deps=bpy.context.evaluated_depsgraph_get()
    extents=[1e9,-1e9,1e9,-1e9]
    for o in s.objects:
        if o.type!='MESH' or o.name.startswith('Studio floor'):continue
        evaluated=o.evaluated_get(deps)
        for corner in evaluated.bound_box:
            p=evaluated.matrix_world@Vector(corner)
            extents=[min(extents[0],p.x),max(extents[1],p.x),min(extents[2],p.y),max(extents[3],p.y)]
            assert max(abs(p.x),abs(p.y))<=BASE_HALF+.006,(fr,o.name,tuple(p))
    bounds.append({'frame':fr,'xy_bounds':extents})
assert not any(image.filepath and not image.packed_file for image in bpy.data.images if image.source=='FILE')
assert s.render.filepath=='//double_eave_garden.png'
assert s.camera.data.type=='ORTHO'
report={'result':'passed','main_columns':6,'roof_tiers':2,'roof_sides_each':6,'curved_bench_bays':5,'front_stair_treads':3,'plant_roots_checked':len(plant_roots),'architecture_static':True,'bounds_over_animation':bounds,'portable_materials':True,'mesh_objects':len([o for o in s.objects if o.type=='MESH'])}
with open(os.path.join(ROOT,'output/validation.json'),'w') as f:json.dump(report,f,indent=2)
print(json.dumps(report))
