"""Six-column pavilion with two separate hexagonal roofs and pierced friezes."""
import math,random
import bpy
from mathutils import Vector
from geometry import *
from layout import *

def ring(radius,angle,z):
    return CENTER+Vector((radius*math.cos(angle),radius*math.sin(angle),z))

def arc_slab(batch,r0,r1,a0,a1,z,thickness,mat=0,segments=24):
    for j in range(segments):
        a=a0+(a1-a0)*j/segments; b=a0+(a1-a0)*(j+1)/segments
        vs=[ring(r,t,h) for h in (z,z+thickness) for r,t in ((r0,a),(r1,a),(r1,b),(r0,b))]
        batch.add(vs,[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],mat)

def build_pavilion():
    rng=random.Random(2310438)
    base=collection('02_Hexagonal_Platform_and_Three_Steps')
    structure=collection('03_Six_Red_Columns_and_Openwork')
    seats=collection('04_Curved_Stone_Backrest_Benches')
    lower=collection('05_Lower_Hexagonal_Annular_Roof')
    upper=collection('06_Upper_Hexagonal_Pointed_Roof')
    finial=collection('07_Dark_Gourd_Finial')
    ivory=material('Pale ivory soffits and beams',(.78,.78,.69),.76)
    red=material('Deep red brown painted round columns',(.29,.048,.032),.55)
    dark=material('Dark pierced traditional fretwork',(.105,.055,.035),.76)
    stone=material('Pale grey stone platform and curved benches',(.61,.64,.61),.78)
    seam=material('Restrained granite paving joints',(.38,.40,.38),.85)
    rose=material('Muted rose geometric floor inset',(.43,.245,.22),.79)
    mortar=material('Dark aged roof tile bedding',(.16,.105,.07),.87)
    fascia=material('Weathered burgundy eave edge',(.24,.045,.036),.72)
    tile_colors=[(.34,.16,.095),(.40,.20,.12),(.29,.20,.15),(.43,.235,.15),(.32,.25,.19),(.39,.18,.10),(.27,.22,.18)]
    tiles=[material('Weathered brown red ceramic %d'%i,c,.72) for i,c in enumerate(tile_colors)]
    cap=material('Dark brown gourd ceramic',(.12,.062,.031),.57)

    poly_slab('Modest raised hexagonal stone platform',PLATFORM,.28,.59,stone,base)
    poly_slab('Pale hexagonal paving surface',[(x*.985,.8+(y-.8)*.985) for x,y in PLATFORM],.87,.025,stone,base)
    inset=[(1.42*math.cos(a),.8+1.42*math.sin(a)) for a in ANGLES]
    poly_slab('Central muted red hexagonal paving inset',inset,.897,.012,rose,base)
    joints=Batch()
    for side in range(6):
        joints.beam(ring(1.44,ANGLES[side],.901),ring(2.66,ANGLES[side],.901),.006,.004)
    joints.finish('Six fine radial stone paving joints',[seam],base)
    for i in range(3):
        y=-2.58+i*.40; top=.43+i*.15
        cube('Front stone stair tread %d'%(i+1),(0,y,(.28+top)/2),(2.36,.42,top-.28),stone,base,.018)
    for i,a in enumerate(ANGLES):
        p=ring(2.04,a,0)
        column=Batch();column.cylinder((p.x,p.y,3.435),.155,5.09,0,36)
        column.finish('Main dark red circular column %d'%(i+1),[red],structure,True)

    # Actual pierced rosettes and open square fretwork, never opaque wall panels.
    def ornamental_ring(radius,z,height,label,upper_ring=False):
        beams=Batch(); fret=Batch()
        for side in range(6):
            a=ring(radius,ANGLES[side],z); b=ring(radius,ANGLES[(side+1)%6],z)
            tangent=(b-a).normalized(); span=(b-a).length
            for zz in (0,height): beams.beam(a+Vector((0,0,zz)),b+Vector((0,0,zz)),.12,.10)
            count=3 if upper_ring else 4
            for j in range(count):
                c=a.lerp(b,(j+.5)/count)+Vector((0,0,height*.5)); size=min(height*.74,span/count*.79)
                pts=[c+tangent*x+Vector((0,0,h)) for x,h in [(-size/2,-size/2),(size/2,-size/2),(size/2,size/2),(-size/2,size/2),(-size/2,-size/2)]]
                fret.tube(pts,.023,0,6)
                octagon=[c+tangent*(size*.34*math.cos(k*math.tau/8))+Vector((0,0,size*.34*math.sin(k*math.tau/8))) for k in range(9)]
                fret.tube(octagon,.026,0,6)
                for k in range(4):
                    angle=k*math.pi/2
                    start=c+tangent*(size*.16*math.cos(angle))+Vector((0,0,size*.16*math.sin(angle)))
                    end=c+tangent*(size*.29*math.cos(angle))+Vector((0,0,size*.29*math.sin(angle)))
                    fret.beam(start,end,.034,.035)
            if not upper_ring:
                for t in (.12,.88):
                    sign=1 if t<.5 else -1; p=a.lerp(b,t)
                    pts=[p+Vector((0,0,-.10)),p+Vector((0,0,-.37)),p+tangent*.20*sign+Vector((0,0,-.37)),p+tangent*.20*sign+Vector((0,0,-.21))]
                    fret.tube(pts,.038,0,6)
        beams.finish(label+' pale frame beams',[ivory],structure)
        fret.finish(label+' genuinely pierced geometric lattice',[dark],structure)
    ornamental_ring(2.04,5.21,.43,'Lower eave frieze')
    beam=Batch()
    for i,a in enumerate(ANGLES):
        beam.beam(ring(2.04,a,5.07),ring(2.04,ANGLES[(i+1)%6],5.07),.20,.21)
    beam.finish('Pale structural beam hexagon',[ivory],structure)
    ornamental_ring(1.51,7.25,.67,'Upper decorative drum',True)
    uprights=Batch()
    for a in ANGLES: uprights.cylinder(ring(1.51,a,7.60),.067,.92,0,16)
    uprights.finish('Six short upper decorative drum uprights',[red],structure,True)

    # Five curved bench bays, with an open sixth side at the staircase.
    for i in (0,1,2,3,5):
        a0=ANGLES[i]+.075; a1=ANGLES[i]+math.pi/3-.075
        seat=Batch(); arc_slab(seat,2.04,2.44,a0,a1,1.30,.11)
        arc_slab(seat,2.43,2.56,a0,a1,1.91,.10)
        for j in range(7):
            a=a0+(a1-a0)*(j+.5)/7
            points=[ring(2.33,a,1.40),ring(2.38,a,1.58),ring(2.51,a,1.80),ring(2.50,a,1.94)]
            for p,q in zip(points,points[1:]): seat.beam(p,q,.065,.075)
        for t in (.12,.5,.88):
            a=a0+(a1-a0)*t; p=ring(2.25,a,1.105)
            seat.box(p,(.12,.14,.43))
        seat.finish('Curved stone bench with shaped backrest bay %d'%(i+1),[stone],seats)

    def make_roof(label,coll,inner,outer,eave,rise,upturn,columns,rows):
        def point(side,u,s):
            a=Vector((math.cos(ANGLES[side]),math.sin(ANGLES[side]),0))
            b=Vector((math.cos(ANGLES[(side+1)%6]),math.sin(ANGLES[(side+1)%6]),0))
            q=a.lerp(b,u)*(inner+(outer-inner)*s)
            return CENTER+q+Vector((0,0,eave+rise*(1-s)**2.25+upturn*abs(2*u-1)**3.5*s**4))
        for side in range(6):
            verts=[]; faces=[]; nu,nv=32,28
            for j in range(nv+1):
                for k in range(nu+1): verts.append(point(side,k/nu,j/nv)-Vector((0,0,.065)))
            for j in range(nv):
                for k in range(nu):
                    a=j*(nu+1)+k; faces.append((a,a+nu+1,a+nu+2,a+1))
            soffit=object_mesh(label+' ivory curved soffit %d'%(side+1),verts,faces,[ivory],coll,smooth=True)
            solid=soffit.modifiers.new('Real thin roof body','SOLIDIFY'); solid.thickness=.09;solid.offset=-1
            object_mesh(label+' aged tile bedding %d'%(side+1),[p+Vector((0,0,.064)) for p in verts],faces,[mortar],coll,smooth=True)
            barrels=Batch(); ends=Batch(); edging=Batch(); ridges=Batch()
            for c in range(columns):
                u=(c+.5)/columns
                for row in range(rows):
                    s0=row/rows;s1=min(1,(row+1.08)/rows);v=[];f=[];mi=rng.randrange(len(tiles))
                    for j in range(3):
                        s=s0+(s1-s0)*j/2; rad=(inner+(outer-inner)*s)/columns*.46
                        for k in range(9):
                            angle=k*math.pi/8;q=point(side,u+math.cos(angle)*.44/columns,s)
                            q.z+=.024+math.sin(angle)*rad+.008*(1-j/2);v.append(q)
                    for j in range(2):
                        for k in range(8):
                            a=j*9+k;f.append((a,a+1,a+10,a+9))
                    f.append(tuple(18+k for k in range(9)));barrels.add(v,f,mi)
                    if c<columns-1:
                        flat=[point(side,uu,ss)+Vector((0,0,.012)) for ss,uu in [(s0,u+.44/columns),(s0,u+.56/columns),(s1,u+.56/columns),(s1,u+.44/columns)]]
                        barrels.add(flat,[(3,2,1,0)],mi)
                p=point(side,u,1)+Vector((0,0,.028));direction=(p-point(side,u,.98)).normalized();rad=outer/columns*.46
                ends.tube([p-direction*.015,p+direction*.02],rad,4,16)
                ends.tube([p+direction*.022,p+direction*.028],rad*.56,2,14)
            edgepoints=[point(side,k/64,1) for k in range(65)]
            for p,q in zip(edgepoints,edgepoints[1:]): edging.beam(p-Vector((0,0,.095)),q-Vector((0,0,.095)),.055,.14)
            pts=[point(side,0,j/52)+Vector((0,0,.08)) for j in range(53)]
            ridges.tube(pts,.065,0,12)
            for j in range(2,24):
                s=j/25;p=point(side,0,s)+Vector((0,0,.102));d=(point(side,0,min(1,s+.01))-point(side,0,max(0,s-.01))).normalized()
                ridges.tube([p-d*.017,p+d*.017],.077,1,10)
            tip=point(side,0,1); radial=Vector((math.cos(ANGLES[side]),math.sin(ANGLES[side]),0))
            ridges.tube([tip+Vector((0,0,.08)),tip+radial*.13+Vector((0,0,.22)),tip+radial*.18+Vector((0,0,.46)),tip+radial*.13+Vector((0,0,.60))],[.074,.061,.043,.01],0,12)
            barrels.finish(label+' individually overlapping barrel tiles %d'%(side+1),tiles,coll,True)
            ends.finish(label+' patterned round tile ends %d'%(side+1),tiles,coll,True)
            edging.finish(label+' burgundy fascia %d'%(side+1),[fascia],coll)
            ridges.finish(label+' curved ridge and plain upturned tip %d'%(side+1),[tiles[2],tiles[4]],coll,True)
    make_roof('Lower roof',lower,1.53,3.85,5.84,1.40,.51,26,15)
    make_roof('Upper roof',upper,.055,2.96,8.00,2.04,.50,23,19)
    gourd=Batch()
    gourd.lathe((0,.8,9.99),[(0,.14),(.10,.16),(.18,.16),(.22,.12),(.28,.18),(.36,.24),(.46,.25),(.56,.19),(.60,.12),(.66,.18),(.73,.205),(.81,.17),(.86,.095),(.99,.060),(1.13,.012)],0,32)
    gourd.finish('Dark brown double bulb gourd roof finial',[cap],finial,True)
    return {'base':base,'structure':structure,'seats':seats,'lower':lower,'upper':upper,'finial':finial}
