"""A small planted shoreline garden. Plant roots never occupy a path or platform."""
import bpy,math,random
from mathutils import Vector,noise
from geometry import *
from layout import *

def plantable(x,y,margin=.12):
    if max(abs(x),abs(y))>7.04-margin: return False
    for dx,dy in [(0,0),(margin,0),(-margin,0),(0,margin),(0,-margin)]:
        if inside(x+dx,y+dy,POND_OUTLINE) or inside(x+dx,y+dy,PLATFORM): return False
    return not on_path(x,y,margin) and not on_stairs(x,y,margin)

def build_garden():
    r=random.Random(2310438)
    base=collection('00_Square_Collectible_Base')
    pond=collection('01_Quiet_Pond_and_Floating_Leaves')
    paths=collection('08_Red_Garden_Paths_and_Stone_Bench')
    rocks=collection('09_Porous_Taihu_Limestone')
    green=collection('10_Trees_Bamboo_and_Purple_Flowers')
    stone=material('Soft grey carved plinth stone',(.46,.49,.46),.86)
    earth=material('Garden soil cutaway',(.16,.13,.085),.96)
    grass=material('Fine muted green ground cover',(.16,.25,.08),.94)
    redpath=material('Weathered red brown fine aggregate path',(.34,.19,.15),.95)
    border=material('Light grey stone path edging',(.52,.54,.49),.85)
    limestone=material('Grey naturally weathered Taihu limestone',(.37,.40,.37),.9)
    grainm=[material('Path mineral grain '+str(i),c,.95) for i,c in enumerate([(.40,.27,.23),(.27,.16,.13),(.45,.33,.27)])]
    bark=material('Warm evergreen bark',(.16,.11,.065),.88)
    greens=[material('Layered foliage green '+str(i),c,.88) for i,c in enumerate([(.045,.13,.046),(.072,.20,.062),(.12,.28,.082),(.19,.35,.105),(.26,.41,.14)])]
    purples=[material('Purple flower petal '+str(i),c,.72) for i,c in enumerate([(.33,.055,.37),(.49,.10,.49),(.63,.22,.55)])]
    bamboo=material('Muted green bamboo culms',(.30,.37,.115),.77)
    nodes=material('Pale raised bamboo joints',(.42,.47,.21),.75)
    cube('Complete square stone collectible plinth',(0,0,-.19),(14.5,14.5,.46),stone,base,.085)
    cube('Fine recessed plinth shadow line',(0,0,-.365),(14.43,14.43,.07),earth,base,.022)
    land=cube('Continuous planted ground with real pond opening',(0,0,.13),(14.18,14.18,.30),grass,base,0)
    cutter=poly_slab('Temporary pond excavation',POND_OUTLINE,-.2,.9,earth,base)
    for mod in list(cutter.modifiers): cutter.modifiers.remove(mod)
    boolean=land.modifiers.new('Excavate real water basin','BOOLEAN');boolean.operation='DIFFERENCE';boolean.object=cutter
    bpy.context.view_layer.objects.active=land;bpy.ops.object.modifier_apply(modifier=boolean.name)
    bpy.data.objects.remove(cutter,do_unlink=True)
    land.data.materials.append(earth)
    for f in land.data.polygons:
        if f.normal.z<.5:f.material_index=1
    bevel(land,.018,2)
    water=material('Pond water soft natural jade green',(.035,.105,.065),.13,.18,False)
    p=water.node_tree.nodes.get('Principled BSDF');p.inputs['IOR'].default_value=1.333
    p.inputs['Transmission Weight'].default_value=.04
    n=water.node_tree.nodes.new('ShaderNodeTexNoise');n.inputs['Scale'].default_value=4.2;n.inputs['Detail'].default_value=2
    bump=water.node_tree.nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.055;bump.inputs['Distance'].default_value=.012
    water.node_tree.links.new(n.outputs['Fac'],bump.inputs['Height']);water.node_tree.links.new(bump.outputs['Normal'],p.inputs['Normal'])
    vs=[];fs=[];N=40
    for j in range(N+1):
        for i in range(N+1):vs.append((-7.075+14.15*i/N,-7.075+14.15*j/N,WATER+.004*math.sin(i*.8+j*.6)))
    for j in range(N):
        for i in range(N):
            a=j*(N+1)+i;fs.append((a,a+1,a+N+2,a+N+1))
    w=object_mesh('Quiet pond water surface',vs,fs,[water],pond,smooth=True)
    w.shape_key_add(name='Basis');k=w.shape_key_add(name='Slow gentle pond ripples')
    for v,orig in zip(k.data,vs):v.co.z=orig[2]+.009*math.sin(orig[0]*1.2-orig[1]*.7)
    for fr,value in [(1,0),(61,1),(121,0)]:k.value=value;k.keyframe_insert(data_path='value',frame=fr)
    for f in w.data.shape_keys.animation_data.action.fcurves:f.modifiers.new('CYCLES')
    probe=bpy.data.lightprobes.new('Planar pond reflections','PLANE');po=bpy.data.objects.new('Pond reflection probe',probe);pond.objects.link(po);po.location=(0,0,.135);po.scale=(7.05,7.05,1)
    # Inlaid winding paths, with narrow stone edging and real tiny aggregate chips.
    grain=Batch()
    for route,(line,width) in enumerate(PATH_LINES):
        path=Batch();edge=Batch()
        cross=[]
        for j,p in enumerate(line):
            t=(line[min(j+1,len(line)-1)]-line[max(j-1,0)]).normalized();normal=Vector((-t.y,t.x))
            cross.append((p,normal))
        for j in range(len(line)-1):
            a,na=cross[j];b,nb=cross[j+1]
            def ribbon(lo,hi,z,target):
                lo,hi=min(lo,hi),max(lo,hi)
                pts=[(q.x+n.x*s,q.y+n.y*s,z) for q,n,s in [(a,na,lo),(a,na,hi),(b,nb,hi),(b,nb,lo)]]
                target.add(pts,[(3,2,1,0)])
            ribbon(-width/2,width/2,.292,path)
            for sign in [-1,1]:
                mid=a.lerp(b,.5)+na*(sign*(width/2+.04))
                crossing=any(other!=route and any(distance_to_segment(mid,pa,pb)<ww/2+.015 for pa,pb in zip(ll,ll[1:])) for other,(ll,ww) in enumerate(PATH_LINES))
                ccx,ccy,ccr=BENCH_COURT
                if not crossing and math.hypot(mid.x-ccx,mid.y-ccy)>ccr:
                    ribbon(sign*(width/2+.015),sign*(width/2+.065),.31,edge)
            for k in range(9):
                q=a.lerp(b,r.random());shift=r.uniform(-width*.47,width*.47);q+=na*shift
                grain.leaf((q.x,q.y,.296),r.uniform(.012,.027),r.uniform(.008,.018),r.random()*math.tau,0,r.randrange(3))
        path.finish('Curving red aggregate garden path '+str(route+1),[redpath],paths)
        edge.finish('Pale stone path edging '+str(route+1),[border],paths)
    court=Batch();cx,cy,cr=BENCH_COURT;court.cylinder((cx,cy,.287),cr,.014,0,72)
    court.finish('Small rounded path widening for stone bench',[redpath],paths)
    grain.finish('Fine path aggregate grains',grainm,paths)
    cube('Simple freestanding grey stone bench seat',(-2.7,-5.25,.88),(1.75,.50,.14),border,paths,.04)
    for x in [-3.25,-2.15]:cube('Simple stone bench support', (x,-5.25,.56),(.19,.38,.56),stone,paths,.025)

    # The holes in these stones are real geometry, visible from the opposite side.
    def rock(name,x,y,sx,sy,h,holes=0):
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=3,radius=1,location=(x,y,.28+h*.47))
        o=bpy.context.object;o.name=name
        for c in list(o.users_collection):c.objects.unlink(o)
        rocks.objects.link(o)
        for v in o.data.vertices:
            q=v.co.copy();factor=1+.17*noise.noise_vector(q*3.1+Vector((x,y,2))).x+.10*math.sin(q.z*14+q.x*4)
            v.co=Vector((q.x*sx*factor,q.y*sy*factor,q.z*h*.53*factor))
        o.data.materials.append(limestone)
        for j in range(holes):
            bpy.ops.mesh.primitive_uv_sphere_add(segments=20,ring_count=12,radius=1,location=(x+(.08 if j%2 else -.10),y,.28+h*(.38+j*.22)))
            cut=bpy.context.object;cut.scale=(sx*.43,sy*2.5,h*.11)
            bpy.context.view_layer.objects.active=cut;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
            m=o.modifiers.new('Natural open erosion hole','BOOLEAN');m.operation='DIFFERENCE';m.object=cut
            bpy.context.view_layer.objects.active=o;bpy.ops.object.modifier_apply(modifier=m.name);bpy.data.objects.remove(cut,do_unlink=True)
        for f in o.data.polygons:f.use_smooth=True
        bevel(o,.018,2);return o
    rock('Right entry Taihu stone with two open holes',1.90,-2.02,.47,.37,1.80,2)
    rock('Left entry Taihu stone with an open hole',-1.90,-2.00,.38,.34,1.12,1)
    for x,y,sx,sy,h in [(2.55,-2.05,.43,.31,.55),(-2.45,-1.96,.28,.32,.48),(-4.5,-5.55,.42,.32,.35),(3.5,-5.55,.64,.35,.29),(-5.9,1.3,.28,.31,.46),(5.5,1.3,.40,.33,.38)]:
        if plantable(x,y,.05):rock('Low natural garden limestone',x,y,sx,sy,h)

    leafm=[material('Small water lily green '+str(i),c,.7) for i,c in enumerate([(.19,.34,.12),(.27,.40,.16),(.36,.46,.22)])]
    for zone,(cx,cy) in enumerate([(-4.7,2.1),(4.5,3.0),(.1,5.15)]):
        pads=Batch()
        for j in range(40):
            x=cx+r.uniform(-.85,.85);y=cy+r.uniform(-.65,.65);rad=r.uniform(.045,.13)
            if not all(inside(x+dx,y+dy,POND_OUTLINE) for dx,dy in [(rad,0),(-rad,0),(0,rad),(0,-rad)]):continue
            a=r.random()*math.tau
            verts=[(x,y,.137)]+[(x+rad*math.cos(a+k*(math.tau-.28)/12),y+rad*.8*math.sin(a+k*(math.tau-.28)/12),.135) for k in range(13)]
            pads.add(verts,[(0,k+1,k+2) for k in range(12)],r.randrange(3))
        o=pads.finish('Sparse floating leaf cluster '+str(zone+1),leafm,pond);wave_animation(o,amplitude=.003,phase=zone)

    # Broadleaf trees are layered small leaves, with roots on dry banks.
    for idx,(tx,ty,h,spread) in enumerate([(-5.45,5.85,5.7,1.35),(-3.25,6.38,4.85,1.10),(3.75,6.30,5.0,1.12),(-6.85,2.0,3.9,.85)]):
        assert plantable(tx,ty,.08),(tx,ty)
        trunk=Batch();foliage=Batch();trunk.tube([(tx,ty,.28),(tx+.06,ty,.28+h*.45),(tx-.10,ty+.03,.28+h*.88)],[.14,.095,.025],0,12)
        clusters=[]
        offset=Vector((.45 if idx==3 else 0,-.55 if idx<3 else 0,0))
        for j in range(13):
            a=j*2.4;level=.57+j*.024;reach=spread*r.uniform(.40,.82)
            start=Vector((tx,ty,.28+h*level-.42));end=Vector((tx+math.cos(a)*reach,ty+math.sin(a)*reach,.28+h*level+.15))+offset
            if max(abs(end.x),abs(end.y))>6.95:end.x=max(-6.95,min(6.95,end.x));end.y=max(-6.95,min(6.95,end.y))
            trunk.tube([start,start.lerp(end,.5)+Vector((0,0,.13)),end],[.041,.021,.006],0,8)
            clusters.append((end,spread*.63,spread*.57,.54))
        clusters.append((Vector((tx,ty,.28+h-.22))+offset,spread*.73,spread*.65,.56))
        for center,rx,ry,rz in clusters:
            for k in range(155):
                a=r.random()*math.tau;zz=r.uniform(-1,1);rr=math.sqrt(1-zz*zz)*r.uniform(.4,1)
                p=center+Vector((rx*rr*math.cos(a),ry*rr*math.sin(a),rz*zz))
                length=r.uniform(.18,.31)
                if max(abs(p.x),abs(p.y))+length*.5>7.08:continue
                foliage.leaf(p,length,length*r.uniform(.45,.65),r.random()*math.tau,r.uniform(-.55,.55),r.randrange(5))
        tr=trunk.finish('Evergreen trunk '+str(idx+1),[bark],green,True);tr['plant_root']=[tx,ty]
        crown=foliage.finish('Layered evergreen crown '+str(idx+1),greens,green,origin=(tx,ty,.28));wave_animation(crown,'rotation_euler',1,.002,idx*.6)

    # Bamboo stays in the rear-right soil bed, well clear of all paving.
    stems=Batch();leaves=Batch();roots=[]
    for j in range(20):
        x=r.uniform(5.55,6.55);y=r.uniform(5.60,6.55)
        if not plantable(x,y,.10):continue
        roots.extend([x,y]);h=r.uniform(3.3,4.7);a=r.random()*math.tau;basep=Vector((x,y,.28));lean=Vector((.13*math.cos(a),.13*math.sin(a),0))
        stems.tube([basep+Vector((0,0,h*t))+lean*t*t for t in [0,.25,.5,.75,1]],[.034,.031,.029,.025,.016],0,9)
        for k in range(1,int(h/.43)):
            t=k*.43/h;p=basep+Vector((0,0,k*.43))+lean*t*t;stems.cylinder(p,.039,.018,1,9)
            if t<.37:continue
            for side in [0,math.pi]:
                aa=a+k*1.1+side;reach=r.uniform(.29,.61);end=p+Vector((math.cos(aa)*reach,math.sin(aa)*reach,.15))
                end.x=max(-6.85,min(6.85,end.x));end.y=max(-6.85,min(6.85,end.y))
                stems.tube([p,end],[.009,.002],0,6)
                for l in range(6):
                    q=p.lerp(end,(l+1)/7)
                    for sign in [-1,1]:
                        phi=aa+sign*.75;qq=q+Vector((math.cos(phi)*.09,math.sin(phi)*.09,0));L=r.uniform(.22,.34)
                        if max(abs(qq.x),abs(qq.y))+L*.5<7.06:leaves.leaf(qq,L,.047,phi,r.uniform(-.25,.35),r.randrange(2,5))
    st=stems.finish('Bamboo culms rooted in rear right soil bed',[bamboo,nodes],green,True);st['plant_roots_xy']=roots
    leaf=leaves.finish('Fine bamboo leaf sprays',greens,green,origin=(6,6,.28));wave_animation(leaf,'rotation_euler',0,.0025)

    # Low layered bushes leave the entrance and pavement visible and usable.
    shrubs=[(-3.05,-1.2,.62,.8),(3.20,-1.1,.68,.9),(-3.45,.1,.55,.8),(3.8,.2,.55,.85),(-5.5,-1.25,.65,.7),(5.45,-1.6,.75,.85),(-5.4,-4.5,.60,.65),(1.9,-5.7,.66,.55),(5.4,-5.65,.65,.6),(-5.4,6.2,.62,.85),(-4,6.4,.6,.75),(-1.8,6.6,.6,.85),(.2,6.6,.62,.8),(2,6.5,.6,.75),(4.9,6.2,.5,.85),(-6.75,3.5,.35,.8),(6.75,2,.33,.85)]
    for idx,(x,y,spread,h) in enumerate(shrubs):
        if not plantable(x,y,.15):continue
        foliage=Batch();flowers=Batch()
        for k in range(280):
            a=r.random()*math.tau;z=r.uniform(-1,1);rr=math.sqrt(1-z*z)*r.uniform(.4,1);px=x+math.cos(a)*spread*rr;py=y+math.sin(a)*spread*rr
            if not plantable(px,py,.12):continue
            p=Vector((px,py,.28+h*.6+z*h*.55));L=r.uniform(.12,.22)
            foliage.leaf(p,L,L*.55,r.random()*math.tau,r.uniform(-.45,.45),r.randrange(4))
            if idx<4 and k%7==0 and z>-.2:
                for petal in range(5):
                    angle=petal*math.tau/5;center=p+Vector((.04*math.cos(angle),.04*math.sin(angle),.06))
                    flowers.leaf(center,.085,.063,angle,.2,r.randrange(3))
        f=foliage.finish('Low bank shrub '+str(idx+1),greens,green);f['plant_root']=[x,y]
        if flowers.v:
            fl=flowers.finish('Purple garden blossoms '+str(idx+1),purples,green,origin=(x,y,.28));wave_animation(fl,'rotation_euler',1,.004,idx*.8)
    blades=Batch()
    for x,y in [(2.55,-1.65),(-2.35,-2.3),(3.4,-2.35),(4.4,-5.8),(-5.8,-5.7),(-6.5,.1),(6.5,.5)]:
        if not plantable(x,y,.2):continue
        for j in range(18):
            a=j*2.4;L=r.uniform(.32,.65);p=(x+math.cos(a)*L*.23,y+math.sin(a)*L*.23,.28+L*.42)
            if plantable(p[0],p[1],.10):blades.leaf(p,L,L*.12,a,r.uniform(.6,1.7),r.randrange(3))
    blades.finish('Sword leaf plants beside entry rocks and banks',greens,green)
    # Small grass tufts on open soil add a crafted miniature finish.
    turf=Batch()
    for j in range(1300):
        x=r.uniform(-6.95,6.95);y=r.uniform(-6.9,6.95)
        if not plantable(x,y,.16):continue
        for k in range(3):
            a=r.random()*math.tau;turf.leaf((x,y,.33),r.uniform(.08,.17),.017,a,1.2,r.randrange(1,5))
    turf.finish('Fine ground cover tufts kept off paving',greens,green)
    return {'base':base,'pond':pond,'paths':paths,'rocks':rocks,'green':green}
