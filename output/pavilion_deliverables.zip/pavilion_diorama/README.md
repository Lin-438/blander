# 雨夜 · 中式重檐六角亭

以用户上传的同一座亭子的两张照片为建筑依据，参考《雨夜微缩便利店提示词》的微缩景观、三渲二材质、冷暖雨夜灯光与可收藏底座质感。主体仍为中式亭子。

## 交付文件

- `output/pavilion.blend`：可编辑 Blender 4.3 项目，按台基、木构、屋顶、脊饰、庭园、灯光与雨滴分组。两张原始参考图已内嵌。
- `output/pavilion_night.png`：模型的实际渲染图。
- `output/pavilion.glb`：可导入其他三维软件的标准 PBR 模型。Blender 的程序化三段色材质、轮廓线与合成辉光保留在 `.blend`，不会完整转换到 GLB。
- `output/viewer.html`：离线三维查看器，模型与脚本全部内嵌。用现代浏览器打开，拖动旋转、滚轮/双指缩放、双击复位、空格自动旋转。

## 保留的建筑特征

六角平面、六根朱红主柱、上下两层屋檐、下层环状坡屋顶、上层攒尖顶与宝顶、翘起的角脊及脊兽、橙赭色筒瓦与圆形瓦当、宽大的乳白檐底、直角几何花格、弯曲坐凳围栏、六角石台和正面台阶。

照片没有测量数据，模型采用视觉比例复原，并对不可见部分做对称推定；适合作为风格化景观模型，不是建筑测绘图。匾额保留暗红底板与边框，未猜写照片中无法可靠辨认的书法。

## 使用

在 Blender 打开 `output/pavilion.blend`，按数字键盘 `0` 查看主相机，`F12` 渲染。时间轴 1–96 帧、24 fps；细雨与庭园波纹有循环动画。静态 PNG 为第 1 帧。

重建模型与输出（在项目目录执行，Blender 4.3.2 已验证）：

```bash
MESA_SHADER_CACHE_DIR="$PWD/.render-cache" blender -b --factory-startup -t 5 --python-exit-code 1 --python scripts/build_pavilion.py
python3 scripts/package_viewer.py
```

建模脚本只依赖 Blender 自带 Python；已生成的 HTML 查看器不依赖 Node.js 或网络。重新打包查看器使用 `.viewer-tools` 中固定版本的 Three.js 0.170.0 与 esbuild 0.24.2。若在另一台电脑重建查看器，先运行 `npm ci --prefix .viewer-tools` 安装锁定版本。最终效果图使用 EEVEE、三段色材质、轮廓线及辉光合成；无需额外 Blender 插件。

`references/` 包含两张原照片和作为美术参考的原提示词；这些参考资料不会替代建模脚本中的场景逻辑。GLB 与网页保留标准 PBR 外观，`.blend` 是三渲二材质和雨滴动画的完整版本。

源脚本：`scripts/build_pavilion.py`（建筑、灯光与导出）、`scripts/garden.py`（微缩庭园）、`scripts/viewer_entry.js` / `scripts/package_viewer.py`（离线查看器）。
