"""Refine the saved first-pass scene, export portable geometry, and render the hero.
This script preserves any already-applied presentation revision on repeated runs.
"""
import os
import bpy
from mathutils import Vector

ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT=os.path.join(ROOT,'output')
path=os.path.join(OUT,'pavilion.blend')
bpy.ops.wm.open_mainfile(filepath=path)
s=bpy.context.scene
if s.get('Presentation_revision') != 2:
    for o in s.objects:
        if o.name.startswith(('Upper lattice','Upper rectangular meander')):
            o.location.z-=.22
s['Presentation_revision']=2
s.camera.location=(6,-20,9.5)
s.camera.rotation_euler=(Vector((0,0,3.2))-s.camera.location).to_track_quat('-Z','Y').to_euler()
s.camera.data.ortho_scale=14.9
s.render.engine='BLENDER_EEVEE_NEXT'
s.render.resolution_x=s.render.resolution_y=1500
s.render.resolution_percentage=100
s.render.filepath=os.path.join(OUT,'pavilion_night.png')
bpy.data.lights['Cool edge separation'].energy=1000
for name in ['reference_1_1.jpg','reference_2_1.jpg']:
    image_name='REFERENCE_'+name
    im=bpy.data.images.get(image_name)
    if im is None:
        im=bpy.data.images.load(os.path.join(ROOT,'references',name))
        im.name=image_name
    im.use_fake_user=True
    im.pack()
s.frame_set(1)
bpy.ops.wm.save_as_mainfile(filepath=path)

# Portable export: standard PBR colors, with the backdrop and moving rain excluded.
for m in bpy.data.materials:
    if not m.use_nodes: continue
    bs=m.node_tree.nodes.get('Principled BSDF')
    if bs:
        for link in list(bs.inputs['Base Color'].links): m.node_tree.links.remove(link)
        bs.inputs['Base Color'].default_value=m.diffuse_color
for o in bpy.data.collections['06_Presentation'].objects:
    if o.type!='CAMERA': o.hide_set(True)
for o in bpy.data.collections['05_Animated_Rain'].objects: o.hide_set(True)
bpy.ops.object.select_all(action='DESELECT')
for o in s.objects:
    if not o.hide_get() and o.type in {'MESH','CURVE','CAMERA'}: o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'pavilion.glb'),export_format='GLB',
    use_selection=True,export_cameras=True,export_lights=False,export_animations=False,
    export_apply=True,export_materials='EXPORT')

# Reload the original stylized materials for the actual render.
bpy.ops.wm.open_mainfile(filepath=path)
s=bpy.context.scene
refs=[i for i in bpy.data.images if i.name.startswith('REFERENCE_')]
assert len(refs)==2 and all(i.packed_file and i.use_fake_user for i in refs)
assert len([o for o in s.objects if o.name.startswith('Main vermilion column')])==6
assert len([o for o in s.objects if o.name.startswith('Upper drum column')])==6
roofs=[o for o in s.objects if 'ivory curved soffit' in o.name]
assert len(roofs)==12 and all(p.normal.z>0 for o in roofs for p in o.data.polygons)
rain=[o for o in s.objects if o.name.startswith('Fine rain streak')]
s.frame_set(1); a=rain[0].location.copy()
s.frame_set(24); assert (rain[0].location-a).length>0
s.frame_set(1)
print('FINAL_VALIDATION_PASSED: 6 main columns, 6 upper columns, 12 roof faces, 2 packed references, animated rain.',flush=True)
bpy.ops.render.render(write_still=True)
print('FINAL_PAVILION_RENDER_COMPLETE',s.render.filepath,flush=True)
