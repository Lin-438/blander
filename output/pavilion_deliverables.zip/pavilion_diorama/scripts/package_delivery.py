"""Create a portable delivery archive from the final, verified scene outputs."""
from pathlib import Path
import hashlib
import struct
import zipfile

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'output'
png=OUT/'pavilion_night.png'
with png.open('rb') as f:
    head=f.read(24)
assert head[:8]==b'\x89PNG\r\n\x1a\n'
assert struct.unpack('>II',head[16:24])==(1500,1500), 'Wait for the full-resolution final render.'
files=[ROOT/'README.md',ROOT/'.gitignore']
files += [ROOT/'scripts'/name for name in [
    'build_pavilion.py','garden.py','finalize_pavilion.py','viewer_entry.js',
    'package_viewer.py','package_delivery.py']]
files += [ROOT/'.viewer-tools'/name for name in ['package.json','package-lock.json']]
files += sorted((ROOT/'references').glob('*'))
files += [OUT/name for name in ['pavilion.blend','pavilion.glb','pavilion_night.png','viewer.html']]
dest=OUT/'pavilion_deliverables.zip'
tmp=dest.with_suffix('.tmp.zip')
checksums=[]
with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in files:
        relative=path.relative_to(ROOT).as_posix()
        digest=hashlib.sha256(path.read_bytes()).hexdigest()
        checksums.append(f'{digest}  {relative}')
        archive.write(path,'pavilion_diorama/'+relative)
    archive.writestr('pavilion_diorama/SHA256SUMS.txt','\n'.join(checksums)+'\n')
with zipfile.ZipFile(tmp) as archive:
    assert archive.testzip() is None
tmp.replace(dest)
print(f'DELIVERY_READY {dest} ({dest.stat().st_size:,} bytes, {len(files)} files plus checksums)')
