"""Rain-washed miniature garden surrounding the reference Chinese pavilion.

Blender 4.3+, no dependencies.  Call build_garden() after constructing the
pavilion.  The garden is deterministic and does not change cameras or render
settings.  Pavilion centre is (0, 0), ground z=.38, footprint radius 3.15.
"""

import bpy
import math
import random
from mathutils import Vector


def build_garden():
    rng = random.Random(438)
    base = bpy.data.collections.new('00_Base')
    garden = bpy.data.collections.new('03_Garden')
    details = bpy.data.collections.new('04_Rain_and_Ripples')
    for coll in (base, garden, details):
        bpy.context.scene.collection.children.link(coll)

    def mat(name, color, rough=.62, metal=0, emission=None):
        m = bpy.data.materials.new(name)
        m.diffuse_color = (*color, 1)
        m.use_nodes = True
        p = m.node_tree.nodes.get('Principled BSDF')
        p.inputs['Base Color'].default_value = (*color, 1)
        p.inputs['Roughness'].default_value = rough
        p.inputs['Metallic'].default_value = metal
        if emission:
            p.inputs['Emission Color'].default_value = (*color, 1)
            p.inputs['Emission Strength'].default_value = emission
        return m

    navy = mat('Garden · enamel midnight blue', (.026, .061, .086), .34, .22)
    trim = mat('Garden · aged brass edge', (.42, .28, .115), .34, .66)
    rim = mat('Garden · cut blue limestone', (.17, .25, .26), .4)
    earth = mat('Garden · rain-soaked moss earth', (.075, .14, .117), .82)
    moss = [mat('Garden · moss %02d' % i, c, .87) for i, c in enumerate([
        (.13, .25, .16), (.18, .30, .19), (.09, .20, .15), (.24, .33, .19)])]
    stones = [mat('Garden · wet river stone %02d' % i, c, .32) for i, c in enumerate([
        (.27, .34, .34), (.38, .43, .40), (.20, .29, .30), (.43, .46, .39)])]
    path_mats = [mat('Garden · wet slate %02d' % i, c, .29) for i, c in enumerate([
        (.32, .39, .39), (.40, .46, .43), (.25, .34, .35)])]
    bark = mat('Garden · bonsai cedar bark', (.15, .12, .095), .78)
    foliage = [mat('Garden · jade foliage %02d' % i, c, .85) for i, c in enumerate([
        (.07, .22, .17), (.11, .31, .23), (.20, .39, .27), (.30, .43, .29)])]
    bamboo = mat('Garden · bamboo culm', (.30, .37, .17), .55)
    bamboo_joint = mat('Garden · bamboo nodes', (.46, .48, .25), .62)
    water = mat('Garden · deep celadon water', (.023, .20, .21), .19, .38)
    water_dark = mat('Garden · pond depth', (.015, .085, .10), .5)
    ripple_mat = mat('Garden · moonlit water lines', (.21, .43, .40), .25, .3)
    lily_mat = mat('Garden · water lily leaves', (.24, .42, .24), .40)
    lily_line = mat('Garden · water lily veins', (.41, .54, .26), .48)
    petal_mat = mat('Garden · lotus porcelain', (.79, .66, .58), .54)
    pollen_mat = mat('Garden · lotus golden heart', (.73, .44, .12), .48)
    lamp_metal = mat('Garden · lantern bronze', (.12, .15, .14), .38, .6)
    lamp_glow = mat('Garden · amber lantern glass', (1.0, .48, .13), .36, emission=3.5)
    rain_mat = mat('Garden · faint rain threads', (.24, .43, .48), .42, .1)

    def place(ob, coll=garden):
        for c in list(ob.users_collection):
            c.objects.unlink(ob)
        coll.objects.link(ob)
        return ob

    def cube(name, xyz, scale, material, bevel=0, coll=garden):
        bpy.ops.mesh.primitive_cube_add(size=1, location=xyz)
        ob = bpy.context.object
        ob.name = name
        ob.dimensions = scale
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        ob.data.materials.append(material)
        if bevel:
            mod = ob.modifiers.new('soft crafted edges', 'BEVEL')
            mod.width = bevel
            mod.segments = 3
            mod = ob.modifiers.new('weighted corner normals', 'WEIGHTED_NORMAL')
        return place(ob, coll)

    def ico(name, loc, scl, material, sub=1, coll=garden):
        bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=sub, radius=1, location=loc)
        ob = bpy.context.object
        ob.name = name
        ob.scale = scl
        ob.rotation_euler = (rng.uniform(-.16,.16),rng.uniform(-.16,.16),rng.uniform(0,6.28))
        ob.data.materials.append(material)
        return place(ob, coll)

    def tube(name, pts, radius, material, coll=garden, cyclic=False):
        cu = bpy.data.curves.new(name, 'CURVE')
        cu.dimensions = '3D'
        cu.resolution_u = 8
        cu.bevel_depth = radius
        cu.bevel_resolution = 2
        sp = cu.splines.new('POLY')
        sp.points.add(len(pts)-1)
        for p, pt in zip(sp.points, pts):
            p.co = (*pt,1)
        sp.use_cyclic_u = cyclic
        ob=bpy.data.objects.new(name,cu)
        coll.objects.link(ob)
        ob.data.materials.append(material)
        return ob

    def tapered(name, pts, radii, material, coll=garden, segments=9):
        vs=[]
        fs=[]
        for i,p in enumerate(pts):
            tang = Vector(pts[min(i+1,len(pts)-1)])-Vector(pts[max(i-1,0)])
            tang.normalize()
            side = tang.cross(Vector((0,1,0))).normalized()
            if side.length < .1:
                side = tang.cross(Vector((1,0,0))).normalized()
            up=tang.cross(side).normalized()
            for j in range(segments):
                a=j*math.tau/segments
                q=Vector(p)+(math.cos(a)*side+math.sin(a)*up)*radii[i]
                vs.append(q)
        for i in range(len(pts)-1):
            for j in range(segments):
                k=i*segments+j
                fs.append((k,i*segments+(j+1)%segments,(i+1)*segments+(j+1)%segments,k+segments))
        fs.extend([tuple(range(segments-1,-1,-1)),tuple((len(pts)-1)*segments+j for j in range(segments))])
        me=bpy.data.meshes.new(name)
        me.from_pydata(vs,[],fs)
        me.materials.append(material)
        ob=bpy.data.objects.new(name,me)
        coll.objects.link(ob)
        return ob

    def polygon_slab(name, pts, bottom, top, material, bevel=.035, coll=garden):
        n=len(pts)
        vs=[(x,y,z) for z in (bottom,top) for x,y in pts]
        fs=[tuple(range(n-1,-1,-1)),tuple(range(n,n*2))]
        fs.extend((i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n))
        me=bpy.data.meshes.new(name)
        me.from_pydata(vs,[],fs)
        me.materials.append(material)
        ob=bpy.data.objects.new(name,me)
        coll.objects.link(ob)
        if bevel:
            b=ob.modifiers.new('hand-cut edges','BEVEL');b.width=bevel;b.segments=2
            ob.modifiers.new('stone normals','WEIGHTED_NORMAL')
        return ob

    def ellipse_points(cx,cy,rx,ry,n=32,irregular=0):
        return [(cx+rx*math.cos(a)*(1+irregular*math.sin(a*5)),cy+ry*math.sin(a)*(1+irregular*math.cos(a*3))) for a in [i*math.tau/n for i in range(n)]]

    # A deliberately finished collectible plinth, the gold reveals continuing
    # around every side.  The scene is a complete, freestanding square object.
    cube('Collector plinth · midnight enamel', (0,0,-.125), (10.8,10.8,.79), navy,.18,base)
    cube('Continuous brass reveal', (0,0,.095),(10.82,10.82,.035),trim,.11,base)
    cube('Top stone lip', (0,0,.24),(10.62,10.62,.13),rim,.10,base)
    cube('Moss garden surface', (0,0,.315),(10.32,10.32,.065),earth,.10,base)
    for x in (-4.65,4.65):
        for y in (-4.65,4.65):
            cube('Recessed display foot',(x,y,-.56),(.80,.80,.13),navy,.08,base)

    # Tiny stone blocks reinforce the intentional, model-like border.
    for side in range(4):
        for j in range(15):
            u=-4.82+j*.689
            if side==0: loc=(u,-5.12,.365); dims=(.64,.19,.11)
            elif side==1: loc=(u,5.12,.365); dims=(.64,.19,.11)
            elif side==2: loc=(-5.12,u,.365); dims=(.19,.64,.11)
            else: loc=(5.12,u,.365); dims=(.19,.64,.11)
            cube('Perimeter cut-stone border',loc,dims,stones[j%4],.025)

    # Left-side pool follows the boundary of the hexagonal pavilion foundation.
    pond_pts=[(-4.91,-3.52),(-4.66,-3.81),(-4.12,-3.63),(-3.66,-3.20),
        (-3.38,-2.58),(-3.32,-1.75),(-3.30,-.92),(-3.43,-.18),
        (-3.42,.65),(-3.52,1.39),(-3.84,1.96),(-4.43,2.10),
        (-4.86,1.69),(-4.95,.85),(-4.90,-.04),(-5.00,-1.22),(-4.95,-2.33)]
    polygon_slab('Inlaid pool basin',pond_pts,.34,.38,water_dark,.02)
    centre=Vector((-4.19,-.75))
    water_pts=[tuple(centre+(Vector(p)-centre)*.94) for p in pond_pts]
    polygon_slab('Still jade water',water_pts,.381,.39,water,0)
    for i,(x,y) in enumerate(pond_pts):
        for j in range(2):
            nx,ny=pond_pts[(i+1)%len(pond_pts)]
            t=j/2
            px=x*(1-t)+nx*t;py=y*(1-t)+ny*t
            ico('Rounded pool margin', (px,py,.42),(.16+rng.random()*.12,.14+rng.random()*.10,.09+rng.random()*.06),rng.choice(stones),sub=2)

    # Ripple lines are deliberately intermittent, engraved-looking ellipses.
    for i,(x,y,s) in enumerate([(-4.16,-2.65,.28),(-4.52,-1.21,.33),(-4.12,.55,.26),(-3.88,-.15,.18)]):
        for rr in (s,s*1.48):
            pts=[(x+rr*math.cos(a),y+rr*.73*math.sin(a),.398) for a in [j*math.tau/48 for j in range(49)]]
            tube('Rain circle on pond',pts,.007,ripple_mat,details)

    # Water-lily leaves have a real wedge-shaped notch and a central vein.
    for i,(x,y,r) in enumerate([(-4.52,.82,.26),(-4.25,1.08,.20),(-4.54,-2.05,.23)]):
        a0=.2+i*.9
        leaf_pts=[(x,y)]+[(x+r*math.cos(a0+.16+j*(math.tau-.32)/28),y+r*.84*math.sin(a0+.16+j*(math.tau-.32)/28)) for j in range(29)]
        polygon_slab('Notched water lily leaf',leaf_pts,.397,.41,lily_mat,.007)
        for k in range(5):
            a=a0+.6+k*1.08
            tube('Lily leaf fine vein',[(x,y,.418),(x+r*.8*math.cos(a),y+r*.68*math.sin(a),.418)],.004,lily_line)
    lotus_center=(-4.46,.84,.47)
    ico('Small lotus heart',lotus_center,(.07,.07,.055),pollen_mat,sub=2)
    for j in range(8):
        a=j*math.tau/8
        ob=ico('Porcelain lotus petal',(-4.46+math.cos(a)*.085,.84+math.sin(a)*.085,.465),(.12,.049,.034),petal_mat,sub=2)
        ob.rotation_euler=(0,-.2,a)

    # Three large, asymmetrical stones lead directly to the front pavilion step.
    for i,(cx,cy,w,d) in enumerate([(.10,-4.76,1.55,.55),(-.04,-4.12,1.65,.55),(.06,-3.54,1.78,.46)]):
        pts=[(cx-w/2+.10,cy-d/2),(cx+w/2-.16,cy-d/2-.03),(cx+w/2,cy-.02),
             (cx+w/2-.07,cy+d/2),(cx-w/2+.04,cy+d/2+.02),(cx-w/2,cy)]
        polygon_slab('Entry stepping slate %02d'%i,pts,.345,.43,path_mats[i%3],.025)
        # One narrow dark seam per stone, a believable cut in the wet surface.
        tube('Subtle slate seam',[(cx-.40,cy-.11,.433),(cx-.10,cy+.01,.433),(cx+.30,cy+.06,.433)],.0045,rim)

    # Sparse small gravel sits outside the architecture, not across its floor.
    gravel=[]
    for i in range(125):
        x=rng.uniform(-4.88,4.88);y=rng.uniform(-4.88,4.88)
        if x*x+y*y < 11.7 or (x<-3.15 and -3.8<y<2.2) or (abs(x)<1.1 and y<-3):
            continue
        ob=ico('Quiet rain gravel',(x,y,.365),(.045+rng.random()*.035,.035+rng.random()*.03,.02+rng.random()*.02),rng.choice(stones),sub=1)
        gravel.append(ob)

    # Moss and shrub cushions articulate the islands between path and border.
    shrub_positions=[(-2.1,-4.55,.47,.35),(-2.75,-4.15,.42,.30),(2.08,-4.44,.51,.39),
        (3.11,-3.80,.46,.32),(4.35,-2.6,.50,.34),(4.59,-1.8,.37,.30),
        (4.38,.25,.52,.34),(4.50,1.36,.55,.35),(1.7,4.54,.52,.37),
        (-1.8,4.55,.52,.34),(-3.75,3.86,.64,.36),(-4.6,3.03,.42,.28)]
    for i,(x,y,rx,ry) in enumerate(shrub_positions):
        for j in range(3):
            ico('Velvet moss cushion',(x+rng.uniform(-.18,.18),y+rng.uniform(-.14,.14),.38+rng.uniform(.01,.09)),(rx*.8,ry,.14+rng.random()*.10),moss[(i+j)%len(moss)],sub=2)
        if i%3==0:
            ico('Jade garden shrub',(x,y,.68),(rx*.80,ry*.85,.38),foliage[1],sub=2)
            ico('Shrub lit crown',(x-.10,y-.02,.91),(rx*.62,ry*.67,.20),foliage[2],sub=2)

    # Hand-carved scholar's rock group on the unobstructed right margin.
    for i,(loc,scl) in enumerate([((4.30,-.66,.69),(.46,.39,.43)),((4.05,-.37,1.02),(.26,.30,.66)),((4.60,-.46,.54),(.34,.26,.20)),((3.86,-1.05,.47),(.23,.22,.13))]):
        ico('Rain-polished scholar rock',loc,scl,stones[(i+2)%4],sub=1)
    for i in range(6):
        x=4.08+rng.uniform(-.35,.42);y=-.72+rng.uniform(-.30,.4)
        ico('Rock foot moss',(x,y,.43),(.15,.12,.08),moss[i%4],sub=1)

    # The bonsai follows an S-curve, with a deliberately asymmetrical crown.
    tree_x,tree_y=-3.97,3.04
    trunk=[(tree_x,tree_y,.38),(tree_x+.09,tree_y, .82),(tree_x+.30,tree_y+.03,1.40),
           (tree_x+.15,tree_y+.06,1.96),(tree_x+.34,tree_y+.10,2.48),(tree_x+.24,tree_y+.11,3.02)]
    tapered('Bonsai sculpted trunk',trunk,[.16,.14,.11,.09,.066,.025],bark,segments=10)
    for j in range(5):
        a=j*math.tau/5
        tapered('Visible bonsai root',[(tree_x+.05,tree_y,.45),(tree_x+.28*math.cos(a),tree_y+.28*math.sin(a),.38),(tree_x+.48*math.cos(a),tree_y+.42*math.sin(a),.365)],[.09,.05,.012],bark,segments=7)
    branches=[((-.40,-.12,1.47),(-.83,-.14,1.94),(.58,.37,.19)),
              ((.18,.10,1.93),(.92,.20,2.37),(.61,.43,.22)),
              ((.21,.08,2.45),(-.38,.14,2.80),(.58,.43,.22)),
              ((.26,.11,2.91),(.30,.12,3.19),(.66,.46,.24))]
    for i,(start,end,scl) in enumerate(branches):
        p0=(tree_x+.22,tree_y+.06,start[2]-.22)
        p1=(tree_x+start[0],tree_y+start[1],start[2])
        p2=(tree_x+end[0],tree_y+end[1],end[2])
        tapered('Bonsai spreading branch',[p0,p1,p2],[.075,.05,.018],bark,segments=8)
        for j in range(4):
            cx=p2[0]+rng.uniform(-.18,.18);cy=p2[1]+rng.uniform(-.21,.21)
            ico('Bonsai jade cloud',(cx,cy,p2[2]+rng.uniform(-.03,.10)),scl,foliage[(i+j)%3],sub=2)
        ico('Bonsai highlighted crown',(p2[0]-.06,p2[1]-.06,p2[2]+.17),(scl[0]*.73,scl[1]*.78,.12),foliage[3],sub=2)

    # A single combined mesh keeps many thin bamboo leaves economical.
    leaf_vertices=[];leaf_faces=[];leaf_indices=[]
    def lance_leaf(start,tip,width,mi):
        a=Vector(start);b=Vector(tip);mid=a.lerp(b,.48)
        direction=(b-a).normalized();side=Vector((-direction.y,direction.x,.05)).normalized()*width
        centre=mid+Vector((0,0,.035));k=len(leaf_vertices)
        leaf_vertices.extend([a,mid+side,b,mid-side,centre])
        leaf_faces.extend([(k,k+1,k+4),(k+1,k+2,k+4),(k+2,k+3,k+4),(k+3,k,k+4)])
        leaf_indices.extend([mi,(mi+1)%4,mi,(mi+1)%4])
    for i in range(7):
        x=3.60+rng.uniform(-.32,.45);y=3.72+rng.uniform(-.4,.42)
        h=2.45+rng.uniform(.1,1.25);lean=rng.uniform(-.22,.20)
        pts=[(x+lean*j/5,y+.055*j/5,.37+h*j/5) for j in range(6)]
        tapered('Bamboo slender culm',pts,[.039-.004*j for j in range(6)],bamboo,segments=8)
        for j in range(1,7):
            z=.37+h*j/7
            px=x+lean*j/7
            tube('Bamboo ivory node',[(px+.045*math.cos(a),y+.055*j/7+.045*math.sin(a),z) for a in [v*math.tau/16 for v in range(17)]],.009,bamboo_joint)
            if j<3:continue
            a=rng.uniform(0,math.tau)
            endpoint=Vector((px+.36*math.cos(a),y+.36*math.sin(a),z+.18))
            tube('Bamboo fine twig',[(px,y,z),endpoint],.009,bamboo)
            for k in range(5):
                start=Vector((px,y,z)).lerp(endpoint,.3+k*.16)
                angle=a+(-1 if k%2 else 1)*rng.uniform(.5,1.1)
                tip=start+Vector((math.cos(angle)*rng.uniform(.22,.40),math.sin(angle)*rng.uniform(.22,.40),rng.uniform(-.07,.18)))
                lance_leaf(start,tip,.043+rng.random()*.025,(i+k)%3)
    me=bpy.data.meshes.new('Bamboo lanceolate leaves')
    me.from_pydata(leaf_vertices,[],leaf_faces)
    for m in foliage:me.materials.append(m)
    for p,mi in zip(me.polygons,leaf_indices):p.material_index=mi
    ob=bpy.data.objects.new('Bamboo folded jade leaves',me);garden.objects.link(ob)

    # Reeds at either end of the pool are curved, tapered blades.
    for x,y in [(-4.67,1.68),(-4.65,-3.35),(-3.51,-2.3)]:
        for j in range(8):
            a=rng.uniform(0,math.tau);h=rng.uniform(.25,.66)
            p0=(x+rng.uniform(-.09,.09),y+rng.uniform(-.09,.09),.40)
            p1=(p0[0]+.08*math.cos(a),p0[1]+.08*math.sin(a),.40+h*.65)
            p2=(p0[0]+.20*math.cos(a),p0[1]+.20*math.sin(a),.40+h)
            tapered('Pond reed blade',[p0,p1,p2],[.022,.014,.001],foliage[j%3],segments=4)

    # Four small lanterns direct the eye through the garden; no extra signage.
    for i,(x,y) in enumerate([(-1.66,-4.40),(1.68,-4.40),(4.45,1.80),(-4.48,2.43)]):
        cube('Garden lantern foot',(x,y,.405),(.30,.30,.09),lamp_metal,.025)
        cube('Garden lantern amber core',(x,y,.56),(.16,.16,.25),lamp_glow,.015)
        for dx in (-.105,.105):
            for dy in (-.105,.105):
                cube('Garden lantern bronze frame',(x+dx,y+dy,.56),(.025,.025,.28),lamp_metal,.006)
        cube('Garden lantern rain cap',(x,y,.72),(.33,.33,.055),lamp_metal,.035)
        data=bpy.data.lights.new('Amber ground lantern %02d'%i,'POINT');data.energy=9;data.color=(1,.45,.13);data.shadow_soft_size=.32
        ob=bpy.data.objects.new(data.name,data);ob.location=(x,y,.66);garden.objects.link(ob)

    # Delicate short rain strokes mostly around the exterior so architectural
    # features remain fully legible.  One joined mesh has a simple 48-frame loop.
    rain_verts=[];rain_faces=[]
    for i in range(100):
        x=rng.uniform(-5.0,5.0);y=rng.uniform(-4.8,4.9);z=rng.uniform(.8,6.8)
        if x*x+y*y<12:continue
        length=rng.uniform(.12,.25)
        k=len(rain_verts)
        rain_verts.extend([(x-.003,y,z),(x+.003,y,z),(x+.038,y-.018,z-length),(x+.032,y-.018,z-length)])
        rain_faces.append((k,k+1,k+2,k+3))
    me=bpy.data.meshes.new('Sparse rain threads mesh');me.from_pydata(rain_verts,[],rain_faces);me.materials.append(rain_mat)
    rain_ob=bpy.data.objects.new('Fine rain · falling loop',me);details.objects.link(rain_ob)
    rain_ob.location=(0,0,0);rain_ob.keyframe_insert(data_path='location',frame=1)
    rain_ob.location=(.11,-.05,-.7);rain_ob.keyframe_insert(data_path='location',frame=49)
    if rain_ob.animation_data and rain_ob.animation_data.action:
        for fc in rain_ob.animation_data.action.fcurves:
            for kp in fc.keyframe_points:kp.interpolation='LINEAR'
            fc.modifiers.new('CYCLES')

    # Join repeated mesh details by descriptive object prefix. Materials remain
    # separate slots, while the Outliner stays useful for model editing.
    join_prefixes=('Perimeter cut-stone border','Rounded pool margin','Quiet rain gravel',
        'Velvet moss cushion','Bonsai jade cloud','Bonsai highlighted crown',
        'Garden lantern bronze frame','Pond reed blade')
    for prefix in join_prefixes:
        obs=[ob for ob in garden.objects if ob.type=='MESH' and ob.name.startswith(prefix)]
        if len(obs)<2:continue
        bpy.ops.object.select_all(action='DESELECT')
        for ob in obs:ob.select_set(True)
        bpy.context.view_layer.objects.active=obs[0]
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.join()
        bpy.context.object.name=prefix+' · grouped'
    bpy.ops.object.select_all(action='DESELECT')
    return {'base':base,'garden':garden,'details':details}

