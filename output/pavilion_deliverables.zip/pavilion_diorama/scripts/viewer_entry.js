import * as THREE from '../.viewer-tools/node_modules/three/build/three.module.js';
import { OrbitControls } from '../.viewer-tools/node_modules/three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from '../.viewer-tools/node_modules/three/examples/jsm/loaders/GLTFLoader.js';

const canvas = document.querySelector('canvas');
const status = document.querySelector('#status');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: 'high-performance' });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.02;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;

const scene = new THREE.Scene();
scene.background = new THREE.Color('#142633');
const camera = new THREE.OrthographicCamera(-8, 8, 8, -8, 0.05, 100);
camera.position.set(11, 12, 17);
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true;
controls.dampingFactor = 0.075;
controls.minZoom = 0.52;
controls.maxZoom = 5;
controls.minPolarAngle = 0.12;
controls.maxPolarAngle = Math.PI * 0.485;
controls.target.set(0, 3.2, 0);
controls.update();

scene.add(new THREE.HemisphereLight(0x91b9e7, 0x25343f, 0.82));
const key = new THREE.DirectionalLight(0xb9d4f1, 2.15);
key.position.set(-5, 12, 8);
key.castShadow = true;
key.shadow.mapSize.set(2048, 2048);
key.shadow.camera.left = -8;
key.shadow.camera.right = 8;
key.shadow.camera.top = 8;
key.shadow.camera.bottom = -8;
key.shadow.camera.near = 0.5;
key.shadow.camera.far = 32;
key.shadow.normalBias = 0.035;
key.shadow.bias = -0.0002;
scene.add(key);
const rim = new THREE.DirectionalLight(0x79c6d2, 1.1);
rim.position.set(6, 8, -5);
scene.add(rim);
const fill = new THREE.DirectionalLight(0xa4c9ed, 0.35);
fill.position.set(5, 3, 8);
scene.add(fill);
const pavilionLight = new THREE.PointLight(0xffb76b, 28, 7, 2);
pavilionLight.position.set(0, 3.47, 0);
scene.add(pavilionLight);
const upperLight = new THREE.PointLight(0xffbe78, 12, 4.5, 2);
upperLight.position.set(0, 5.82, 0);
scene.add(upperLight);

let resetPosition = camera.position.clone();
let resetTarget = controls.target.clone();
let model, mixer;
let viewHeight = 15.8;
function resize() {
  const w = window.innerWidth;
  const h = window.innerHeight;
  renderer.setSize(w, h);
  const aspect = w / h;
  const hh = viewHeight / (2 * Math.min(aspect, 1));
  camera.left = -hh * aspect;
  camera.right = hh * aspect;
  camera.top = hh;
  camera.bottom = -hh;
  camera.updateProjectionMatrix();
}
window.addEventListener('resize', resize);
resize();
function resetView() {
  camera.position.copy(resetPosition);
  camera.zoom = 1;
  camera.updateProjectionMatrix();
  controls.target.copy(resetTarget);
  controls.update();
}
canvas.addEventListener('dblclick', resetView);
window.addEventListener('keydown', e => {
  if (e.key.toLowerCase() === 'r' || e.key === 'Home') resetView();
  if (e.code === 'Space') { e.preventDefault(); controls.autoRotate = !controls.autoRotate; controls.autoRotateSpeed = 0.55; }
});

function bytesFromBase64(encoded) {
  const raw = atob(encoded.trim());
  const bytes = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
  return bytes.buffer;
}

const bytes = bytesFromBase64(document.querySelector('#model-data').textContent);
new GLTFLoader().parse(bytes, '', gltf => {
  model = gltf.scene;
  model.traverse(object => {
    if (object.isLight) {
      // Authored Blender lights remain in the downloadable model. This viewer
      // supplies its own calibrated lighting, except gentle pavilion lamps.
      object.visible = false;
    }
    if (object.isMesh) {
      object.castShadow = true;
      object.receiveShadow = true;
    }
  });
  scene.add(model);
  const bounds = new THREE.Box3().setFromObject(model);
  const center = bounds.getCenter(new THREE.Vector3());
  const size = bounds.getSize(new THREE.Vector3());
  controls.target.set(center.x, Math.max(3, size.y * 0.43 + bounds.min.y), center.z);
  camera.position.copy(controls.target).add(new THREE.Vector3(6, 6.3, 20));
  viewHeight = Math.max(size.x, size.z, size.y) * 1.45;
  resetPosition.copy(camera.position);
  resetTarget.copy(controls.target);
  controls.update();
  resize();
  if (gltf.animations.length) {
    mixer = new THREE.AnimationMixer(model);
    for (const clip of gltf.animations) mixer.clipAction(clip).play();
  }
  status.hidden = true;
  document.documentElement.dataset.ready = 'true';
  window.__pavilion = { scene, camera, controls, renderer, model, animations: gltf.animations.length };
}, error => {
  console.error(error);
  status.textContent = '模型加载失败，请使用支持 WebGL 2 的浏览器打开。';
  document.documentElement.dataset.ready = 'error';
});

const clock = new THREE.Clock();
renderer.setAnimationLoop(() => {
  const dt = Math.min(clock.getDelta(), 0.05);
  if (mixer) mixer.update(dt);
  controls.update();
  renderer.render(scene, camera);
});
