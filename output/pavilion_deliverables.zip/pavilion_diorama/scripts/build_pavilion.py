"""Photo-guided, editable miniature of a double-eave hexagonal Chinese pavilion.
Run: blender -b --factory-startup -t 5 --python scripts/build_pavilion.py
No measured dimensions were provided; units are proportional artistic dimensions.
"""
import bpy
import math
import os
import sys
import random
from mathutils import Vector

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, 'output')
sys.path.insert(0, os.path.dirname(__file__))
os.makedirs(OUT, exist_ok=True)
random.seed(438)
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
    if c.name != 'Collection': bpy.data.collections.remove(c)

def collection(name):
    c = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    if c.name not in bpy.context.scene.collection.children:
        bpy.context.scene.collection.children.link(c)
    return c

def put(o, c):
    for old in list(o.users_collection): old.objects.unlink(o)
    c.objects.link(o)
    return o

FOUNDATION = collection('01_Stone_Foundation')
WOOD = collection('02_Pavilion_Columns_and_Lattice')
ROOF = collection('02_Pavilion_Roofs_and_Tiles')
DETAIL = collection('02_Pavilion_Ridge_Ornaments')
LIGHTS = collection('04_Lighting')
WEATHER = collection('05_Animated_Rain')
STAGE = collection('06_Presentation')

def material(name, color, rough=.6, metal=0, cel=False):
    m = bpy.data.materials.new(name)
    m.diffuse_color = (*color, 1)
    m.use_nodes = True
    bs = m.node_tree.nodes.get('Principled BSDF')
    bs.inputs['Base Color'].default_value = (*color, 1)
    bs.inputs['Roughness'].default_value = rough
    bs.inputs['Metallic'].default_value = metal
    if cel:
        ns, lk = m.node_tree.nodes, m.node_tree.links
        geo = ns.new('ShaderNodeNewGeometry')
        dot = ns.new('ShaderNodeVectorMath'); dot.operation = 'DOT_PRODUCT'
        dot.inputs[1].default_value = (-.35, -.5, .79)
        lk.new(geo.outputs['Normal'], dot.inputs[0])
        ramp = ns.new('ShaderNodeValToRGB'); ramp.name = 'Three tone cel palette'
        ramp.color_ramp.interpolation = 'CONSTANT'
        ramp.color_ramp.elements.remove(ramp.color_ramp.elements[1])
        for i,(p,fac) in enumerate([(-.0,.53),(.13,.77),(.52,1.0)]):
            e = ramp.color_ramp.elements[0] if i==0 else ramp.color_ramp.elements.new(p)
            e.position=p; e.color=(*(min(v*fac,1) for v in color),1)
        lk.new(dot.outputs['Value'], ramp.inputs[0]); lk.new(ramp.outputs[0],bs.inputs['Base Color'])
    return m

CREAM=material('Ivory plaster | broad original eave soffits',(.76,.69,.51),.7,cel=True)
RED=material('Vermilion lacquer | original columns',(.43,.055,.045),.29,cel=True)
WOODMAT=material('Dark warm timber',(.105,.040,.026),.45,cel=True)
LATTICE=material('Red-brown geometric lattice',(.22,.063,.035),.4,cel=True)
BLACK=material('Charcoal carved column bases',(.055,.075,.085),.25,cel=True)
STONE=material('Blue grey granite',(.36,.43,.46),.34,cel=True)
STONETOP=material('Wet silver granite paving',(.47,.54,.54),.18,cel=True)
MORTAR=material('Shadow in roof tile courses',(.19,.064,.033),.7)
GOLD=material('Old glazed amber ridge ornaments',(.57,.25,.066),.32,.2,cel=True)
TILES=[material('Terracotta glaze %02d'%i,(.47+i*.026,.135+i*.012,.052+i*.007),.3,cel=True) for i in range(6)]
PLAQUE=material('Original dark red plaque',(.23,.025,.025),.4)

def mesh(name, vs, fs, mat, coll, smooth=False):
    me=bpy.data.meshes.new(name); me.from_pydata(vs,[],fs); me.update()
    ob=bpy.data.objects.new(name,me); coll.objects.link(ob)
    if mat: me.materials.append(mat)
    if smooth:
        for p in me.polygons: p.use_smooth=True
    return ob

def bevel(o, width=.025, segments=2):
    md=o.modifiers.new('Soft handcrafted edges','BEVEL'); md.width=width; md.segments=segments
    return o

def cube(name, loc, scale, mat, coll, bev=.02):
    x,y,z=(v/2 for v in scale)
    vs=[(-x,-y,-z),(x,-y,-z),(x,y,-z),(-x,y,-z),(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)]
    fs=[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
    o=mesh(name,vs,fs,mat,coll); o.location=loc
    if bev: bevel(o,bev)
    return o

def cylinder(name, loc, radius, depth, mat, coll, vertices=32):
    vs=[(radius*math.cos(2*math.pi*i/vertices),radius*math.sin(2*math.pi*i/vertices),z) for z in [-depth/2,depth/2] for i in range(vertices)]
    fs=[tuple(range(vertices-1,-1,-1)),tuple(range(vertices,vertices*2))]
    fs += [(i,(i+1)%vertices,(i+1)%vertices+vertices,i+vertices) for i in range(vertices)]
    o=mesh(name,vs,fs,mat,coll); o.location=loc
    for p in o.data.polygons: p.use_smooth=len(p.vertices)==4
    return o

def beam(name, a, b, width, depth, mat, coll=WOOD):
    a,b=Vector(a),Vector(b); mid=(a+b)/2
    o=cube(name,mid,(width,depth,(b-a).length),mat,coll,min(width*.23,.018))
    o.rotation_euler=(b-a).to_track_quat('Z','Y').to_euler()
    return o

def curve(name, points, radius, mat, coll, resolution=2):
    cu=bpy.data.curves.new(name,'CURVE'); cu.dimensions='3D'; cu.resolution_u=resolution
    cu.bevel_depth=radius; cu.bevel_resolution=2
    sp=cu.splines.new('POLY'); sp.points.add(len(points)-1)
    for p,co in zip(sp.points,points): p.co=(*co,1)
    ob=bpy.data.objects.new(name,cu); coll.objects.link(ob); cu.materials.append(mat)
    return ob

ANG=[math.radians(-120+i*60) for i in range(6)]
def xy(radius, i): return Vector((radius*math.cos(ANG[i%6]),radius*math.sin(ANG[i%6]),0))
def hex_solid(name,r,z,h,mat,coll):
    vs=[(r*math.cos(a),r*math.sin(a),zz) for zz in [z,z+h] for a in ANG]
    fs=[tuple(range(5,-1,-1)),tuple(range(6,12))]+[(i,(i+1)%6,(i+1)%6+6,i+6) for i in range(6)]
    return bevel(mesh(name,vs,fs,mat,coll),.025)

# Build operator-based garden primitives before the detailed architectural mesh.
from garden import build_garden
build_garden()

# Original hexagonal stepped stone platform and individual paving slabs.
hex_solid('Hexagonal granite platform',3.12,.32,.27,STONE,FOUNDATION)
hex_solid('Polished dark rim of hexagonal platform',3.13,.58,.07,BLACK,FOUNDATION)
hex_solid('Wet granite pavilion floor',3.02,.65,.08,STONETOP,FOUNDATION)
for i in range(-4,5):
    # Thin lines represent original rectangular paving joints, clipped to the hexagon.
    x=i*.56
    if abs(x)<3:
        ymax=min(2.60,(3.00-abs(x))*math.sqrt(3))
        curve('Paving joint along Y %d'%i,[(x,-ymax,.734),(x,ymax,.734)],.006,STONE,FOUNDATION)
    y=i*.56
    if abs(y)<2.60:
        xmax=3-abs(y)/math.sqrt(3)
        curve('Paving joint along X %d'%i,[(-xmax,y,.734),(xmax,y,.734)],.006,STONE,FOUNDATION)
cube('Entry step bottom',(0,-3.05,.40),(2.12,.88,.18),STONE,FOUNDATION,.035)
cube('Entry step top',(0,-2.81,.55),(1.97,.55,.18),STONETOP,FOUNDATION,.025)
for side in [-1,1]:
    cube('Step stone cheek',(side*1.10,-2.98,.48),(.18,.94,.34),STONE,FOUNDATION,.025)

# The six red main columns, their drum-shaped black bases, and bracket heads.
RPOST=2.46
for i in range(6):
    p=xy(RPOST,i)
    for name,r,h,z in [('Plinth foot',.255,.07,.77),('Drum base',.224,.16,.875),('Base collar',.193,.055,.98)]:
        bevel(cylinder('%s %d'%(name,i+1),(p.x,p.y,z),r,h,BLACK,WOOD),.018)
    cylinder('Main vermilion column %d'%(i+1),(p.x,p.y,2.67),.152,3.40,RED,WOOD)
    cylinder('Column top collar %d'%(i+1),(p.x,p.y,4.32),.177,.12,RED,WOOD)
    # Dark bracket consoles supporting both neighboring eave sides.
    for direction in [-1,1]:
        dest=xy(RPOST,(i+direction)%6)
        tangent=(dest-p).normalized()
        beam('Bracket horizontal arm',p+Vector((0,0,4.11)),p+tangent*.49+Vector((0,0,4.11)),.13,.16,WOODMAT)
        beam('Bracket rising diagonal',p+Vector((0,0,3.87)),p+tangent*.42+Vector((0,0,4.18)),.12,.12,WOODMAT)

def side_point(radius, side, t, z):
    a,b=xy(radius,side),xy(radius,side+1)
    p=a.lerp(b,t); p.z=z; return p

def lattice_side(radius, side, z, height, small=False):
    name='Upper' if small else 'Lower'
    width=.045 if small else .054
    for zz in [z,z+height]:
        beam(name+' lattice horizontal border',side_point(radius,side,.04,zz),side_point(radius,side,.96,zz),width,width,LATTICE)
    # Straight rectangular fretwork, matching the photos. Nested upright meanders.
    for j in range(5 if small else 6):
        count=5 if small else 6
        t0=.045+j*.91/count; t1=t0+.91/count
        pts=[(t0,z),(t0,z+height*.72),(t0+(t1-t0)*.62,z+height*.72),
             (t0+(t1-t0)*.62,z+height*.32),(t1,z+height*.32),(t1,z+height)]
        for (ta,za),(tb,zb) in zip(pts,pts[1:]):
            beam(name+' rectangular meander',side_point(radius,side,ta,za),side_point(radius,side,tb,zb),width,width,LATTICE)
    if not small:
        # A hanging stepped edge under the main ring, rather than diagonal lattice.
        for t in [.12,.88]:
            ss=-1 if t>.5 else 1
            pts=[(t,z),(t,z-.26),(t+ss*.10,z-.26),(t+ss*.10,z-.10)]
            for (ta,za),(tb,zb) in zip(pts,pts[1:]):
                beam('Pendant square fret',side_point(radius,side,ta,za),side_point(radius,side,tb,zb),width,width,LATTICE)

for i in range(6):
    beam('Main hexagonal crossbeam',side_point(RPOST,i,0,4.23),side_point(RPOST,i,1,4.23),.16,.19,RED)
    lattice_side(RPOST,i,3.65,.48)

# Five perimeter bench-and-railing sections; front edge remains the open entry.
for i in range(1,6):
    a,b=side_point(2.55,i,.04,1.16),side_point(2.55,i,.96,1.16)
    beam('Perimeter wooden bench seat',a,b,.39,.09,WOODMAT)
    beam('Curved railing top',side_point(2.68,i,.04,1.85),side_point(2.68,i,.96,1.85),.10,.095,WOODMAT)
    beam('Railing lower rail',side_point(2.55,i,.04,1.23),side_point(2.55,i,.96,1.23),.065,.065,LATTICE)
    for t in [.15,.50,.85]:
        beam('Bench leg',side_point(2.55,i,t,.74),side_point(2.55,i,t,1.15),.11,.11,WOODMAT)
    for j in range(12):
        t=.065+j*.87/11
        pts=[]
        for k in range(9):
            f=k/8; z=1.25+f*.57
            rad=2.54+.13*f-.15*math.sin(math.pi*f)
            pts.append(side_point(rad,i,t,z))
        # Flat boards with the characteristic S-curved silhouette.
        for pa,pb in zip(pts,pts[1:]): beam('Bent vertical railing board',pa,pb,.055,.07,WOODMAT)

# Upper open drum and upper lattice ring.
for i in range(6):
    p=xy(1.49,i)
    cylinder('Upper drum column %d'%(i+1),(p.x,p.y,5.65),.113,1.32,RED,WOOD)
    beam('Upper drum lintel',side_point(1.49,i,0,6.27),side_point(1.49,i,1,6.27),.105,.14,RED)
    lattice_side(1.49,i,5.45,.36,True)
hex_solid('Upper canopy ivory ceiling',1.49,6.29,.07,CREAM,WOOD)

# A rectangular plaque is retained; the photographed calligraphy is not guessed.
cube('Original front plaque backing',(0,-2.151,3.69),(.91,.062,.36),PLAQUE,WOOD,.014)
for z in [3.52,3.86]: cube('Plaque fine frame',(0,-2.187,z),(.91,.018,.018),GOLD,WOOD,.004)
for x in [-.447,.447]: cube('Plaque fine frame',(x,-2.187,3.69),(.018,.018,.34),GOLD,WOOD,.004)

# Roof surface coordinates keep the lower tier open at the middle.
def roofpoint(side,u,s,inner,outer,low,rise,lift):
    p=xy(1,side).lerp(xy(1,side+1),u)*(inner+(outer-inner)*s)
    z=low+rise*(1-s)**2.15+lift*(abs(2*u-1)**3.4)*s**4
    return Vector((p.x,p.y,z))

def make_roof(label,inner,outer,low,rise,lift,ncols,nrows):
    spec=(inner,outer,low,rise,lift)
    # Broad cream underside with real thickness and a terracotta shadow layer.
    for side in range(6):
        vs=[]; fs=[]; nu,nv=40,28
        for j in range(nv+1):
            for k in range(nu+1):
                p=roofpoint(side,k/nu,j/nv,*spec); p.z-=.08; vs.append(p)
        for j in range(nv):
            for k in range(nu):
                a=j*(nu+1)+k; fs.append((a,a+nu+1,a+nu+2,a+1))
        o=mesh(label+' ivory curved soffit %d'%side,vs,fs,CREAM,ROOF,True)
        sol=o.modifiers.new('Authentic thick eaves','SOLIDIFY'); sol.thickness=.105
        vs2=[Vector(p)+Vector((0,0,.084)) for p in vs]
        mesh(label+' tile bed %d'%side,vs2,fs,MORTAR,ROOF,True)
        # Rows of convex half-cylinder cover tiles with visible overlap seams.
        verts=[]; faces=[]; material_ids=[]
        for col in range(ncols):
            u=(col+.5)/ncols
            for row in range(nrows):
                s0=row/nrows; s1=min(1,(row+1.07)/nrows)
                start=len(verts); cross=8; along=3
                color=random.randrange(len(TILES))
                for j in range(along+1):
                    s=s0+(s1-s0)*j/along
                    face_width=(inner+(outer-inner)*s)
                    radius=face_width/ncols*.46
                    for k in range(cross+1):
                        th=math.pi*k/cross
                        uu=u+math.cos(th)*.44/ncols
                        p=roofpoint(side,uu,s,*spec)
                        p.z+=.032+math.sin(th)*radius+.012*(1-j/along)
                        verts.append(p)
                for j in range(along):
                    for k in range(cross):
                        a=start+j*(cross+1)+k
                        faces.append((a,a+1,a+cross+2,a+cross+1)); material_ids.append(color)
                # End edge cap, read as each individual overlapping tile.
                ids=tuple(start+along*(cross+1)+k for k in range(cross+1))
                faces.append(ids); material_ids.append(max(0,color-1))
                # Flat concave pan between each barrel; width leaves dark fine joints.
                if col<ncols-1:
                    off=len(verts)
                    for ss,uu in [(s0,u+.44/ncols),(s0,u+.56/ncols),(s1,u+.56/ncols),(s1,u+.44/ncols)]:
                        p=roofpoint(side,uu,ss,*spec); p.z+=.020; verts.append(p)
                    faces.append((off+3,off+2,off+1,off)); material_ids.append(color)
        ob=mesh(label+' individually lapped barrel tiles %d'%side,verts,faces,None,ROOF,True)
        for m in TILES: ob.data.materials.append(m)
        for poly,mi in zip(ob.data.polygons,material_ids): poly.material_index=mi
        # Circular decorated tile ends. They face out from the curved roof edge.
        for col in range(ncols):
            u=(col+.5)/ncols
            p=roofpoint(side,u,1,*spec)
            direction=(roofpoint(side,u,1,*spec)-roofpoint(side,u,.98,*spec)).normalized()
            rad=outer/ncols*.465
            disk=cylinder(label+' round eave tile end',p+Vector((0,0,.025)),rad,.035,TILES[(col+side)%6],ROOF,16)
            disk.rotation_euler=direction.to_track_quat('Z','Y').to_euler()
            q=p+direction*.022+Vector((0,0,.025))
            med=cylinder(label+' tile end flower center',q,rad*.34,.012,GOLD,ROOF,10)
            med.rotation_euler=disk.rotation_euler
        # Continuous concave silhouette edge under the row of round tile ends.
        pts=[roofpoint(side,j/60,1,*spec)-Vector((0,0,.07)) for j in range(61)]
        curve(label+' ivory eave lip',pts,.028,CREAM,ROOF)
    # Raised golden hip ridges and upturned sculptural beast ornaments.
    for i in range(6):
        pts=[roofpoint(i,0,j/48,*spec)+Vector((0,0,.105)) for j in range(49)]
        curve(label+' curved hip ridge',pts,.072,GOLD,DETAIL)
        for j in range(3,23):
            s=j/24; p=roofpoint(i,0,s,*spec)+Vector((0,0,.15))
            tangent=roofpoint(i,0,min(1,s+.01),*spec)-roofpoint(i,0,max(0,s-.01),*spec)
            tile=cylinder(label+' hip ridge joint',p,.084,.025,TILES[3],DETAIL,12)
            tile.rotation_euler=tangent.to_track_quat('Z','Y').to_euler()
        tip=roofpoint(i,0,1,*spec)
        radial=xy(1,i); sideways=Vector((-radial.y,radial.x,0))
        profile=[(-.12,.06),(-.03,.19),(.04,.32),(.02,.40),(-.05,.42),(-.09,.36),(-.12,.41),(-.08,.51),(.02,.55),(.11,.49),(.16,.36),(.13,.23),(.08,.12),(.06,.04)]
        vs=[]
        for sign in [-1,1]:
            for rr,zz in profile: vs.append(tip+radial*rr+sideways*sign*.043+Vector((0,0,zz)))
        n=len(profile); fs=[tuple(range(n-1,-1,-1)),tuple(range(n,n*2))]+[(k,(k+1)%n,(k+1)%n+n,k+n) for k in range(n)]
        bevel(mesh(label+' upturned ridge beast %d'%(i+1),vs,fs,GOLD,DETAIL),.018,2)
        crest=[tip+radial*rr+Vector((0,0,zz)) for rr,zz in [(.06,.50),(.06,.61),(.01,.56),(-.01,.64)]]
        curve(label+' ridge beast crown',crest,.022,GOLD,DETAIL)

make_roof('Lower ring roof',1.47,3.64,4.28,.89,.55,24,13)
make_roof('Upper pointed roof',.06,2.91,6.13,1.49,.50,22,16)

# Central stacked finial, an important identifying roof detail.
for j,(rad,h,z) in enumerate([(.16,.08,7.66),(.19,.07,7.73),(.13,.16,7.83),(.105,.14,7.97),(.075,.13,8.10)]):
    ob=cylinder('Stacked roof finial %d'%j,(0,0,z),rad,h,GOLD,DETAIL,24); bevel(ob,.035,3)
bpy.ops.mesh.primitive_uv_sphere_add(segments=16,ring_count=8,radius=.065,location=(0,0,8.20))
ob=bpy.context.object; ob.name='Finial pearl'; ob.data.materials.append(GOLD); put(ob,DETAIL)

# Warm light stays beneath the canopy, leaving the open structure visible.
def emission(name,color,strength):
    m=material(name,color,.3)
    bs=m.node_tree.nodes.get('Principled BSDF')
    bs.inputs['Emission Color'].default_value=(*color,1)
    bs.inputs['Emission Strength'].default_value=strength
    return m
GLOW=emission('Warm paper lantern glow',(1.0,.46,.14),3.0)
def light(name,kind,loc,power,color,size=1,target=None):
    data=bpy.data.lights.new(name,kind); data.energy=power; data.color=color
    if kind=='AREA': data.shape='DISK'; data.size=size
    elif kind=='POINT': data.shadow_soft_size=size
    o=bpy.data.objects.new(name,data); LIGHTS.objects.link(o); o.location=loc
    if target is not None: o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
    return o

# A discreet central pendant rather than a crowd of added decorations.
curve('Lantern suspension',[(0,0,4.9),(0,0,3.78)],.016,WOODMAT,LIGHTS)
lantern=cylinder('Warm central hexagonal lantern',(0,0,3.59),.205,.37,GLOW,LIGHTS,6)
for z in [3.39,3.78]: cylinder('Lantern dark rim',(0,0,z),.237,.055,WOODMAT,LIGHTS,6)
for i in range(6):
    p=xy(.207,i); beam('Lantern frame',(p.x,p.y,3.40),(p.x,p.y,3.78),.021,.021,WOODMAT,LIGHTS)
light('Warm light under pavilion','POINT',(0,0,3.47),170,(1,.53,.24),.75)
light('Warm upper drum light','POINT',(0,0,5.82),95,(1,.61,.32),.5)
light('Soft moonlit key','AREA',(-4,-6,11),1450,(.60,.76,1),7,(0,0,3.0))
light('Warm roof detail fill','AREA',(3,-4,9),850,(1,.72,.46),5,(0,0,4.8))
light('Cool edge separation','AREA',(0,6,8),1000,(.25,.62,.79),6,(0,0,3))

# Fine stylized rain at the outer edges of the diorama. The roof remains readable.
RAIN=emission('Quiet silver blue rain',(.22,.42,.55),.3)
for j in range(75):
    x=random.uniform(-5,5); y=random.uniform(-5,5)
    if x*x+y*y<15: continue
    z=random.uniform(.6,6.7); length=random.uniform(.10,.24)
    ob=curve('Fine rain streak %02d'%j,[(x,y,z),(x-.035,y+.012,z+length)],.004,RAIN,WEATHER)
    ob.location=(0,0,0); ob.keyframe_insert(data_path='location',frame=1)
    ob.location=(.38,-.13,-2.5); ob.keyframe_insert(data_path='location',frame=49)
    for fc in ob.animation_data.action.fcurves:
        for kp in fc.keyframe_points: kp.interpolation='LINEAR'
        fc.modifiers.new('CYCLES')

# Studio ground and camera are a presentation aid, outside the square model itself.
BACKDROP=material('Midnight blue studio backdrop',(.023,.047,.068),.82)
cube('Presentation ground',(0,0,-.27),(200,200,.12),BACKDROP,STAGE,.0)
camdata=bpy.data.cameras.new('Camera_Main')
cam=bpy.data.objects.new('Camera_Main',camdata); STAGE.objects.link(cam)
cam.location=(6,-20,9.5); target=Vector((0,0,3.2))
cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
camdata.type='ORTHO'; camdata.ortho_scale=14.9; camdata.lens=50
bpy.context.scene.camera=cam

scene=bpy.context.scene
scene.render.engine='BLENDER_EEVEE_NEXT'
scene.cycles.samples=96
scene.cycles.use_denoising=False
scene.cycles.max_bounces=6
scene.render.resolution_x=1500; scene.render.resolution_y=1500
scene.render.resolution_percentage=int(os.environ.get('PAVILION_RENDER_PERCENT','100'))
scene.render.image_settings.file_format='PNG'
scene.render.film_transparent=False
scene.world.use_nodes=True
scene.world.node_tree.nodes.get('Background').inputs[0].default_value=(.11,.18,.25,1)
scene.world.node_tree.nodes.get('Background').inputs[1].default_value=.32
scene.view_settings.view_transform='AgX'
scene.view_settings.look='AgX - Medium High Contrast'
scene.render.fps=24; scene.frame_start=1; scene.frame_end=96; scene.frame_set(1)

# Crisp silhouette contours, restricted to structural objects to keep fine tiles clean.
scene.render.use_freestyle=True
scene.render.line_thickness=.75
ls=bpy.context.view_layer.freestyle_settings.linesets[0]
ls.linestyle.color=(.025,.030,.035)
ls.linestyle.thickness=.7
ls.select_silhouette=True; ls.select_border=True; ls.select_crease=False
ls.select_external_contour=True

scene.use_nodes=True
nodes=scene.node_tree.nodes; nodes.clear()
rl=nodes.new('CompositorNodeRLayers')
gl=nodes.new('CompositorNodeGlare'); gl.glare_type='FOG_GLOW'; gl.quality='HIGH'; gl.threshold=1.5; gl.size=7
co=nodes.new('CompositorNodeComposite')
scene.node_tree.links.new(rl.outputs['Image'],gl.inputs['Image']); scene.node_tree.links.new(gl.outputs['Image'],co.inputs['Image'])

scene['Project']='雨夜 · 中式重檐六角亭'
scene['Reference']='Two user-provided photographs of the same pavilion; style adapted from the uploaded miniature rainy-night brief.'
scene['Preserved_structure']='Six columns, hexagonal base, two eave tiers, annular lower roof, pointed upper roof, round tile ends, ivory soffits, rectangular fretwork, curved benches and front steps.'
scene['Limitations']='Photo-based artistic proportions, not a measured survey. Obscured surfaces are inferred; plaque calligraphy is not invented.'
scene['Animation']='Frames 1–96 at 24 fps: rain and garden ripple accents. Live processes are not needed to view the saved model.'
scene['Presentation_revision']=2

# Pack the two photo references into the editable project without placing them in render.
for name in ['reference_1_1.jpg','reference_2_1.jpg']:
    p=os.path.join(ROOT,'references',name)
    if os.path.isfile(p):
        im=bpy.data.images.load(p); im.name='REFERENCE_'+name; im.use_fake_user=True; im.pack()

# Default viewport opens at the model's camera view.
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':
            area.spaces.active.region_3d.view_perspective='CAMERA'
            area.spaces.active.clip_end=300
            area.spaces.active.shading.type='MATERIAL'

scene.render.filepath=os.path.join(OUT,'pavilion_night.png')
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'pavilion.blend'))
bpy.ops.render.render(write_still=True)

# Export a portable, editable geometry variant with standard glTF PBR materials.
# Procedural cel palettes and compositing remain in the original .blend file.
for m in bpy.data.materials:
    if not m.use_nodes: continue
    bs=m.node_tree.nodes.get('Principled BSDF')
    if bs:
        for link in list(bs.inputs['Base Color'].links): m.node_tree.links.remove(link)
        bs.inputs['Base Color'].default_value=m.diffuse_color
for ob in STAGE.objects:
    if ob.type!='CAMERA': ob.hide_set(True)
for ob in WEATHER.objects: ob.hide_set(True)
bpy.ops.object.select_all(action='DESELECT')
for ob in scene.objects:
    if not ob.hide_get() and ob.type in {'MESH','CURVE','CAMERA'}: ob.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'pavilion.glb'),export_format='GLB',use_selection=True,
                         export_cameras=True,export_lights=False,export_animations=False,
                         export_apply=True,export_materials='EXPORT')
print('PAVILION_COMPLETE',len(scene.objects),'objects',os.path.join(OUT,'pavilion.blend'))
