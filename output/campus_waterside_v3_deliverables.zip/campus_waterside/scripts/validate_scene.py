"""Verify the delivered scene's structural requirements with Blender."""
import bpy
import json
from mathutils import Vector
from mathutils.bvhtree import BVHTree

scene = bpy.context.scene
meshes = [o for o in scene.objects if o.type == 'MESH' and not o.name.startswith('Studio floor')]
bamboo = [o for o in meshes if o.name.startswith(('Bamboo culms', 'Fine bamboo leaf sprays'))]
walk = bpy.data.objects['Continuous branching walkway structural slabs']
walk_end = max((walk.matrix_world @ v.co).y for v in walk.data.vertices)
minimum_clearance = float('inf')
# Bounds are conservative and inexpensive, so check every animation frame.
# Use the delivered walkway mesh rather than generation constants.
for frame in range(scene.frame_start, scene.frame_end + 1):
    scene.frame_set(frame)
    for obj in bamboo:
        nearest_y = min((obj.matrix_world @ Vector(corner)).y for corner in obj.bound_box)
        minimum_clearance = min(minimum_clearance, nearest_y - walk_end)
        assert nearest_y - walk_end >= .30, f'Bamboo reaches the tiled landing: {obj.name}, frame {frame}'

bank_vertices, bank_faces = [], []
for obj in meshes:
    if not obj.name.startswith('Green bank surface'): continue
    offset = len(bank_vertices)
    bank_vertices.extend(obj.matrix_world @ v.co for v in obj.data.vertices)
    bank_faces.extend(tuple(offset + i for i in face.vertices) for face in obj.data.polygons)
bank = BVHTree.FromPolygons(bank_vertices, bank_faces)
for obj in bamboo:
    if not obj.name.startswith('Bamboo culms'): continue
    for vertex in obj.data.vertices:
        point = obj.matrix_world @ vertex.co
        if point.z > 2.14: continue
        hit = bank.ray_cast(Vector((point.x, point.y, 3)), Vector((0, 0, -1)), 1.0)[0]
        assert hit is not None, f'Bamboo root is not supported by the planted bank: {obj.name}'
scene.frame_set(1)
columns = [o for o in meshes if o.name.startswith('Pale yellow pavilion column')]
roof_faces = [o for o in meshes if o.name.startswith('Single roof ivory soffit')]
assert len(columns) == 6, 'The pavilion must have exactly six columns.'
assert len(roof_faces) == 6, 'The single roof must have six faces.'
escaped = []
for frame in (1, 31, 61, 91, 120):
    scene.frame_set(frame)
    for obj in meshes:
        # Check actual vertices; an axis-aligned bounding-box corner can lie
        # outside the footprint even when a rotated polygon remains inside it.
        if any(max(abs(p.x), abs(p.y)) > 12.005
               for p in (obj.matrix_world @ vertex.co for vertex in obj.data.vertices)):
            escaped.append((frame, obj.name))
assert not escaped, f'Geometry outside the square base: {escaped}'
animated = [o.name for o in meshes if o.animation_data]
assert all('leaf' in name.lower() or 'crown' in name.lower() for name in animated), animated
assert bpy.data.objects['Quiet pond water surface'].data.shape_keys
assert scene.camera.data.type == 'ORTHO'
assert scene.render.resolution_x == scene.render.resolution_y == 1800
assert scene.render.resolution_percentage == 100
scene.frame_set(1)
print('CAMPUS_VALIDATION ' + json.dumps({
    'columns': len(columns), 'single_roof_faces': len(roof_faces),
    'mesh_objects': len(meshes), 'all_geometry_inside_24m_square': True,
    'animated_foliage_objects': len(animated), 'water_morph_animation': True,
    'architecture_static': True, 'render_resolution': [1800, 1800],
    'bamboo_clearance_from_walkway': round(minimum_clearance, 3),
    'bamboo_frames_checked': scene.frame_end - scene.frame_start + 1,
    'bamboo_roots_on_planted_bank': True,
}, ensure_ascii=False), flush=True)
