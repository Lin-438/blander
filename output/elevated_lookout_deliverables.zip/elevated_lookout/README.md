# 双层架空观景亭 · 三渲二微缩园林

依据提供的三张实景照片制作的可编辑三维模型。下层为通透休憩亭台，上层为真实可到达的观景平台及小型橙褐瓦顶亭屋；直跑楼梯和不同侧面的高架连廊分别连接二层。

## 文件

- `output/elevated_lookout.blend`：Blender 4.3 工程，包含真实几何、三渲二材质、灯光、相机与树叶轻微动画。
- `output/elevated_lookout.glb`：通用三维模型，内嵌材质，不依赖外部图片。交换文件使用通用 PBR 配色；网页查看器会应用三渲二材质。
- `output/viewer.html`：可离线打开的交互网页，模型和 Three.js 均已内嵌。
- `output/elevated_lookout.png`：1800×1800 的实际模型渲染。
- `output/validation.json`：结构、边界及绿植铺装检查结果。
- `scripts/`：可复现的建模、渲染、验证和打包源码。

## 网页打开方法

下载并解压 ZIP，进入 `elevated_lookout/output`，用桌面 Chrome 或 Edge 打开 `viewer.html`。无需安装 Blender，无需联网或运行服务器。加载完成后只显示三维景观。

- 鼠标左键拖动旋转，滚轮缩放，右键拖动平移。
- 触屏单指旋转，双指缩放或平移。
- 数字 `1`：45°整体视角；`2`：亭台、楼梯与连廊近景；`3`：下层空间和梁板细节。
- 双击画面、`R` 或 `Home`：恢复整体视角。
- 空格：开启或停止缓慢自动旋转。

## 模型与参考边界

保留上下两处可使用的开放空间、白色瓷砖方柱、下层放射梁板及弧形柱头、平台边缘低矮瓦饰、小型攒尖瓦屋顶和竖向顶饰。二层平台与连廊同高，楼梯具有连续的混凝土斜板、26级踏步、支撑柱及坡道扶手。下层保留环绕座椅、独立入口和低台阶。

红褐色弯曲步道与植物严格分区。树冠轻微摆动，建筑、楼梯、连廊保持静止。红色导览牌和说明牌仅保留无字图形版面，未复制人物、杂乱电线或远处楼房。

这是一份照片参照模型，并非实测测绘或施工模型。尺寸、照片遮挡部分与完整场地边界采用视觉估算。照片没有显示连廊的最终去向，因此模型只重建可见的侧向高架段，并在底座内部以独立支撑及端部栏杆安全收口，未推断另一栋建筑。

## 重建

需要 Blender 4.3 或兼容版本；建模不依赖外部 Python 库。

```sh
blender --background --threads 5 --python-exit-code 1 --python scripts/build_scene.py
blender --background output/elevated_lookout.blend --threads 5 --python-exit-code 1 --python scripts/render_scene.py
blender --background --python-exit-code 1 --python scripts/validate_scene.py
```

重建离线网页需先在 `.viewer-tools` 中执行 `npm ci`，随后运行：

```sh
python scripts/package_viewer.py
python scripts/package_deliverables.py
```

网页依赖 Three.js 0.170.0 / esbuild 0.24.2；HTML 内保留 Three.js 的 MIT 许可证。
