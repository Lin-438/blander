"""Photo-based proportions in metres; hidden extents are an explicit visual estimate."""
import math
from mathutils import Vector
BASE_HALF=12
GROUND=.16
LOWER_FLOOR=.46
DECK=4.25
CENTER=Vector((0,2,0))
ANGLES=[i*math.tau/6 for i in range(6)]
RADIUS=3.55
POLYGON=[(RADIUS*math.cos(a),2+RADIUS*math.sin(a)) for a in ANGLES]
STAIR_X=-.45
STAIR_WIDTH=1.68
STAIR_END=2-RADIUS*math.sqrt(3)/2
STAIR_START=-8.55
STAIR_COUNT=26
BRIDGE_START=Vector((RADIUS*.75,2+RADIUS*math.sqrt(3)/4))
BRIDGE_KNEE=BRIDGE_START+Vector((.8660254,.5))*4.4
BRIDGE_END=Vector((8.65,7.25))
BRIDGE_WIDTH=1.62
BRIDGE_POINTS=[BRIDGE_START,BRIDGE_KNEE,BRIDGE_END]

def smooth_path(points,steps=12):
    p=[Vector(v) for v in points];p=[p[0]]+p+[p[-1]];result=[]
    for i in range(len(p)-3):
        a,b,c,d=p[i:i+4]
        for j in range(steps):
            t=j/steps;result.append((2*b+(-a+c)*t+(2*a-5*b+4*c-d)*t*t+(-a+3*b-3*c+d)*t*t*t)*.5)
    result.append(p[-1]);return result
PATHS=[([(2.8,-11.45),(2.5,-8.7),(3.1,-5.7),(2.1,-3.3),(0,-2.2),(-3.5,-2.4),(-6.4,-1.7),(-10.9,.3)],1.42),
       ([(-.45,-8.55),(-.25,-9.1),(1.2,-9.2),(2.5,-9.0)],1.72),
       ([(1.95,-3.3),(4.9,-2.1),(7.4,.9),(8.4,3.3),(10.9,4.3)],1.35),
       ([(0,-2.25),(.75,-1.75),(.8,-1.25)],1.25)]
PATH_LINES=[(smooth_path(p),w) for p,w in PATHS]

def distance_to_segment(p,a,b):
    p=Vector(p);d=b-a;t=max(0,min(1,(p-a).dot(d)/max(d.length_squared,1e-9)))
    return (p-a-d*t).length

def on_path(x,y,margin=0):
    return any(distance_to_segment((x,y),a,b)<w/2+margin for line,w in PATH_LINES for a,b in zip(line,line[1:]))

def on_stair(x,y,margin=0):
    return abs(x-STAIR_X)<STAIR_WIDTH/2+margin and STAIR_START-margin<y<STAIR_END+margin

def on_bridge(x,y,margin=0):
    return any(distance_to_segment((x,y),a,b)<BRIDGE_WIDTH/2+margin for a,b in zip(BRIDGE_POINTS,BRIDGE_POINTS[1:]))
