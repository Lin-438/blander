"""Render the saved model; use LOOKOUT_RENDER_PERCENT=50 for a preview."""
import os
from pathlib import Path
import bpy
root=Path(__file__).resolve().parents[1]
if not bpy.data.filepath:bpy.ops.wm.open_mainfile(filepath=str(root/'output/elevated_lookout.blend'))
scene=bpy.context.scene
scene.render.resolution_percentage=int(os.environ.get('LOOKOUT_RENDER_PERCENT','100'))
scene.render.filepath=str(root/'output'/('preview.png' if scene.render.resolution_percentage!=100 else 'elevated_lookout.png'))
bpy.ops.render.render(write_still=True)
