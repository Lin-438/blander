"""Two occupied open levels, a genuine access stair and a separately oriented bridge."""
import math,random
from mathutils import Vector
from geometry import *
from layout import *

def build_architecture():
    rng=random.Random(43824)
    col={k:collection(n) for k,n in [('base','02_Lower_Raised_Platform'),('lower','03_White_Tiled_Columns_and_Radial_Beams'),('upper','04_Upper_Observation_Deck_and_Open_Pavilion'),('roof','05_Small_Orange_Brown_Roof'),('stair','06_Real_26_Tread_Outdoor_Stair'),('bridge','07_Elevated_Side_Walkway'),('seats','08_Lower_Resting_Benches'),('details','09_Reference_Garden_Furniture')]}
    white=material('Soft ivory ceramic tile',(.77,.78,.71),.58)
    concrete=material('Warm pale concrete soffit',(.66,.68,.62),.79)
    joint=material('Fine grey ceramic grout',(.38,.43,.40),.85)
    stone=material('Grey white paving',(.59,.63,.59),.83)
    redfloor=material('Muted red brown floor and stair ceramic',(.32,.19,.145),.77)
    metal=material('Brushed silver grey metal railings',(.65,.70,.69),.36,.35,False)
    dark=material('Restrained dark grey green trim',(.17,.23,.20),.72)
    red=material('Deep red reference information plaques',(.38,.035,.045),.7)
    pale=material('Unlettered cream graphic lines',(.72,.66,.51),.79)
    tiles=[material('Orange brown weathered ceramic '+str(i),v,.72) for i,v in enumerate([(.32,.125,.052),(.38,.16,.068),(.285,.12,.065),(.355,.19,.095),(.30,.16,.075)])]
    def point(r,a,z):return CENTER+Vector((r*math.cos(a),r*math.sin(a),z))
    def tiled_column(name,x,y,bottom,top,w,coll):
        o=cube(name,(x,y,(bottom+top)/2),(w,w,top-bottom),white,coll,.012);o['role']='structural_column'
        g=Batch()
        for i in range(1,int((top-bottom)/.17)):
            z=bottom+i*.17
            for s in [-1,1]:
                g.box((x+s*(w/2+.001),y,z),(.002,w,.005));g.box((x,y+s*(w/2+.001),z),(w,.002,.005))
        for q in [-w/6,w/6]:
            for s in [-1,1]:
                g.box((x+s*(w/2+.002),y+q,(bottom+top)/2),(.002,.004,top-bottom));g.box((x+q,y+s*(w/2+.002),(bottom+top)/2),(.004,.002,top-bottom))
        g.finish(name+' fine ceramic grid',[joint],coll)
        return o
    poly_slab('Raised hexagonal lower plinth',[(x*.94,2+(y-2)*.94) for x,y in POLYGON],GROUND,.30,redfloor,col['base'])
    poly_slab('Lower resting space pale perimeter paving',[(x*.935,2+(y-2)*.935) for x,y in POLYGON],LOWER_FLOOR,.022,stone,col['base'])
    poly_slab('Lower dark red hexagonal floor inset',[(2.05*math.cos(a),2+2.05*math.sin(a)) for a in ANGLES],LOWER_FLOOR+.024,.008,redfloor,col['base'])
    # Ground entrance is to the right of the upper staircase, with two low steps.
    for i in range(2):
        cube('Lower entry step '+str(i+1),(.85,-1.35+i*.27,GROUND+.075*(i+1)),(1.35,.30,.15*(i+1)),redfloor,col['base'],.018)
    floorj=Batch()
    for i in range(6):floorj.beam(point(2.08,ANGLES[i],.492),point(3.25,ANGLES[i],.492),.007,.004)
    floorj.finish('Lower floor restrained radial paving joints',[joint],col['base'])
    for i,a in enumerate(ANGLES):
        p=point(2.65,a,0)
        tiled_column('Lower square tiled pillar %02d'%(i+1),p.x,p.y,LOWER_FLOOR,DECK-.30,.40,col['lower'])
        # Flared concrete haunch: widening towards the platform, with a curved inner edge.
        radial=Vector((math.cos(a),math.sin(a),0));tangent=Vector((-math.sin(a),math.cos(a),0));v=[]
        profile=[(-.20,DECK-.30),(.95,DECK-.30),(.78,DECK-.43),(.56,DECK-.64),(.40,DECK-.90),(.25,DECK-1.18),(.20,DECK-1.34),(-.20,DECK-1.34)]
        for side in [-.24,.24]:v.extend(p+radial*u+tangent*side+Vector((0,0,z)) for u,z in profile)
        n=len(profile);f=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(j,(j+1)%n,(j+1)%n+n,j+n) for j in range(n)]
        bevel(object_mesh('Curved outward concrete haunch %d'%(i+1),v,f,[concrete],col['lower']),.035,3)
    deck=poly_slab('Wide load bearing upper deck',POLYGON,DECK-.30,.30,concrete,col['upper']);deck['floor_elevation']=DECK
    poly_slab('Upper walkable grey paving',[(x*.985,2+(y-2)*.985) for x,y in POLYGON],DECK,.025,stone,col['upper'])
    radial=Batch();radial.cylinder((0,2,DECK-.43),.36,.10,0,24)
    for a in ANGLES:radial.beam(point(0,a,DECK-.42),point(3.1,a,DECK-.34),.19,.19)
    for i in range(6):radial.beam(point(2.65,ANGLES[i],DECK-.34),point(2.65,ANGLES[(i+1)%6],DECK-.34),.31,.26)
    radial.finish('Six exposed radial soffit beams and perimeter ring',[concrete],col['lower'])
    # Linear benches wrap five bays; sixth front bay is the ground-level entrance.
    seats=Batch()
    for i in [0,1,2,3,5]:
        a=point(2.62,ANGLES[i],.98);b=point(2.62,ANGLES[(i+1)%6],.98);d=(b-a).normalized()
        seats.beam(a+d*.16,b-d*.16,.38,.10)
        seats.beam(a+Vector((0,0,.48)),b+Vector((0,0,.48)),.09,.10)
        for t in [.13,.36,.63,.87]:
            p=a.lerp(b,t);seats.box((p.x,p.y,.72),(.10,.14,.48));seats.beam(p+Vector((0,0,.08)),p+Vector((0,0,.43)),.055,.06)
    seats.finish('Five pale perimeter resting benches and low rails',[white],col['seats'])
    # A small roofed pavilion above the much wider accessible deck.
    for i,a in enumerate(ANGLES):
        p=point(1.78,a,0);tiled_column('Upper small pavilion tiled pillar %d'%(i+1),p.x,p.y,DECK+.025,6.79,.24,col['upper'])
    topbeam=Batch();bracket=Batch()
    for i,a in enumerate(ANGLES):
        p=point(1.78,a,6.68);q=point(1.78,ANGLES[(i+1)%6],6.68);d=(q-p).normalized()
        topbeam.beam(p,q,.22,.22)
        for end,sign in [(p,1),(q,-1)]:
            for j in range(3):bracket.beam(end+Vector((0,0,-.14-j*.075)),end+d*sign*(.35-j*.07)+Vector((0,0,-.14-j*.075)),.10,.07)
    topbeam.finish('Simple upper pale beam ring',[white],col['upper']);bracket.finish('Small restrained grey traditional corner brackets',[dark],col['upper'])
    def roof(label,inner,outer,z,rise,upturn,rows,columns,coll,skip_gates=False):
        def q(side,u,s):
            a=Vector((math.cos(ANGLES[side]),math.sin(ANGLES[side]),0));b=Vector((math.cos(ANGLES[(side+1)%6]),math.sin(ANGLES[(side+1)%6]),0))
            return CENTER+a.lerp(b,u)*(inner+(outer-inner)*s)+Vector((0,0,z+rise*(1-s)**1.65+upturn*abs(2*u-1)**4*s**4))
        for side in range(6):
            tile=Batch();body=Batch();rim=Batch()
            for c in range(columns):
                u=(c+.5)/columns
                # Two true gaps let the stair and bridge reach the deck without crossing tiled parapets.
                if skip_gates and ((side==4 and .05<u<.68) or (side==0 and .20<u<.80)):continue
                for j in range(rows):
                    s0=j/rows;s1=min(1,(j+1.08)/rows);verts=[];faces=[]
                    for k in range(3):
                        s=s0+(s1-s0)*k/2;rr=(inner+(outer-inner)*s)/columns*.45
                        for l in range(9):
                            ang=l*math.pi/8;p=q(side,u+math.cos(ang)*.44/columns,s);p.z+=.018+math.sin(ang)*rr;verts.append(p)
                    for k in range(2):
                        for l in range(8):n=k*9+l;faces.append((n,n+1,n+10,n+9))
                    faces.append(tuple(range(18,27)));tile.add(verts,faces,rng.randrange(len(tiles)))
                    body.add([q(side,uu,ss)-Vector((0,0,.015)) for ss,uu in [(s0,c/columns),(s0,(c+1)/columns),(s1,(c+1)/columns),(s1,c/columns)]],[(0,3,2,1)])
                p=q(side,u,1);out=(p-q(side,u,.99)).normalized();r=outer/columns*.45
                tile.tube([p,p+out*.024],r,rng.randrange(len(tiles)),14)
                rim.beam(q(side,c/columns,1)-Vector((0,0,.07)),q(side,(c+1)/columns,1)-Vector((0,0,.07)),.08,.13)
            tile.finish(label+' individual ceramic barrel tiles side '+str(side),tiles,coll,True)
            o=body.finish(label+' pale curved soffit side '+str(side),[white],coll,True);solid=o.modifiers.new('Roof slab thickness','SOLIDIFY');solid.thickness=.10;solid.offset=-1
            rim.finish(label+' tiled fascia edge '+str(side),[white],coll)
            if not skip_gates:
                ridge=Batch();ridge.tube([q(side,0,j/30)+Vector((0,0,.06)) for j in range(31)],.052,0,10)
                p=q(side,0,1);ridge.box(p+Vector((0,0,.11)),(.13,.15,.28));ridge.finish('Plain pale raised roof hip '+str(side),[white],coll,True)
    roof('Low tiled deck cornice',2.99,3.62,4.30,.21,.08,3,24,col['upper'],True)
    roof('Small upper pointed roof',.055,2.66,6.97,1.16,.17,15,24,col['roof'])
    fin=Batch()
    for x,h in [(-.15,.49),(0,.69),(.15,.49)]:
        fin.box((x,2,8.11+h/2),(.11,.17,h));fin.add([(x-.055,1.915,8.11+h),(x+.055,1.915,8.11+h),(x,1.915,8.23+h),(x-.055,2.085,8.11+h),(x+.055,2.085,8.11+h),(x,2.085,8.23+h)],[(0,1,2),(5,4,3),(0,3,4,1),(1,4,5,2),(2,5,3,0)])
    fin.finish('Photo style upright pale ceramic roof ornament',[white],col['roof'])
    # Continuous metal railing utility; all post bases follow the actual walking level.
    def railing(name,pts,coll):
        b=Batch();pts=[Vector(p) for p in pts]
        b.tube([p+Vector((0,0,1.01)) for p in pts],.031,0,10)
        b.tube([p+Vector((0,0,.16)) for p in pts],.018,0,8)
        for a,c in zip(pts,pts[1:]):
            count=max(1,math.ceil((c-a).length/.17))
            for i in range(count+1):
                p=a.lerp(c,i/count);b.tube([p+Vector((0,0,.04)),p+Vector((0,0,1.01))],.012 if i%5 else .022,0,8)
        return b.finish(name,[metal],coll,True)
    for i in range(6):
        a=point(3.04,ANGLES[i],DECK+.025);b=point(3.04,ANGLES[(i+1)%6],DECK+.025)
        parts=[(0,1)]
        if i==4:parts=[(0,.05),(.72,1)]
        if i==0:parts=[(0,.16),(.84,1)]
        for k,(u,v) in enumerate(parts):railing('Upper deck perimeter rail %d %d'%(i,k),[a.lerp(b,u),a.lerp(b,v)],col['upper'])
    run=STAIR_END-STAIR_START;rise=DECK-GROUND;dy=run/STAIR_COUNT;dz=rise/STAIR_COUNT
    stairslab=Batch();xs=[STAIR_X-STAIR_WIDTH/2,STAIR_X+STAIR_WIDTH/2]
    vs=[(x,y,z) for x in xs for y,z in [(STAIR_START,GROUND-.01),(STAIR_END,DECK-.05),(STAIR_END,DECK-.30),(STAIR_START,GROUND-.26)]]
    stairslab.add(vs,[(0,1,2,3),(7,6,5,4),(0,4,5,1),(1,5,6,2),(2,6,7,3),(3,7,4,0)])
    stairslab.finish('Inclined structural concrete stair slab',[concrete],col['stair'])
    for i in range(STAIR_COUNT):
        z=GROUND+(i+1)*dz;y=STAIR_START+(i+.5)*dy
        o=cube('Upper access stair tread %02d'%(i+1),(STAIR_X,y,z-dz/2-.025),(STAIR_WIDTH,dy+.009,dz+.05),redfloor,col['stair'],.006)
        o['role']='upper_access_tread';o['top_elevation']=z;o['tread_index']=i+1
    for x in xs:railing('Continuous sloping stainless staircase handrail',[(x,STAIR_START,GROUND+dz),(x,STAIR_END,DECK)],col['stair'])
    for y in [-5.8,-2.5]:
        height=GROUND+(y-STAIR_START)/run*rise-.26
        tiled_column('Stair independent square support',STAIR_X,y,GROUND,height,.28,col['stair'])
    # Level bridge: mitred turning deck, supported under its first span, elbow and end.
    bridge_poly=[];left=[];right=[]
    for i,p in enumerate(BRIDGE_POINTS):
        t=(BRIDGE_POINTS[min(i+1,2)]-BRIDGE_POINTS[max(i-1,0)]).normalized();n=Vector((-t.y,t.x))
        off=BRIDGE_WIDTH/2
        if i==1:
            t0=(p-BRIDGE_POINTS[0]).normalized();n0=Vector((-t0.y,t0.x));off/=n.dot(n0)
        left.append(p+n*off);right.append(p-n*off)
    bridge_poly=[tuple(p) for p in left+list(reversed(right))]
    br=poly_slab('Mitred level elevated side walkway',bridge_poly,DECK-.27,.27,concrete,col['bridge']);br['floor_elevation']=DECK
    poly_slab('Grey upper bridge walking surface',bridge_poly,DECK,.025,stone,col['bridge'])
    for side in [left,right]:railing('Bridge continuous side safety railing',[(p.x,p.y,DECK+.025) for p in side],col['bridge'])
    # The unseen continuation is bounded at the miniature's finite end, not left as an open drop.
    railing('Safe terminal railing at reconstructed bridge extent',[(p.x,p.y,DECK+.025) for p in [left[-1],right[-1]]],col['bridge'])
    for i,p in enumerate([BRIDGE_START.lerp(BRIDGE_KNEE,.50),BRIDGE_KNEE,BRIDGE_END]):
        tiled_column('Bridge independent tiled pier %d'%(i+1),p.x,p.y,GROUND,DECK-.27,.31,col['bridge'])
        cap=Batch();cap.box((p.x,p.y,DECK-.36),(.62,.62,.18));cap.finish('Bridge bearing cap %d'%i,[concrete],col['bridge'])
    # Short flat transitions cross the roof-edge gates onto the walkable deck.
    cube('Stair to upper platform level threshold',(STAIR_X,STAIR_END+.30,DECK-.055),(STAIR_WIDTH,.64,.11),stone,col['upper'],.006)
    for x in xs:railing('Stair landing short return rail',[(x,STAIR_END,DECK),(x,STAIR_END+.49,DECK)],col['upper'])
    # Reference plaques use deliberate unlettered graphic marks, no invented lettering.
    for i in [0,2,3,5]:
        p=point(2.65,ANGLES[i],2.47);b=cube('Red column information panel '+str(i),p+Vector((0,-.215,0)),(.40,.045,.63),red,col['details'],.025)
        marks=Batch()
        for j in range(5):marks.box((p.x,p.y-.242,p.z+.17-j*.075),(.27 if j else .20,.004,.012))
        marks.finish('Simple graphic rules without text '+str(i),[pale],col['details'])
    cube('Red vertical garden wayfinding sign',(-2.01,-4.40,1.27),(.34,.16,2.22),red,col['details'],.018)
    marks=Batch()
    for z in [.62,.96,1.30,1.64,1.98]:marks.box((-2.01,-4.487,z),(.16,.008,.06))
    marks.finish('Unlettered wayfinding graphic blocks',[pale],col['details'])
    black=material('Quiet black litter bin',(.025,.035,.031),.55,.12)
    cube('Black garden litter bin body',(1.17,-7.05,.67),(.53,.48,1.02),black,col['details'],.035)
    cube('Black garden litter bin sloping hood',(1.17,-7.05,1.27),(.62,.57,.13),black,col['details'],.035)
    cube('Bin shaded opening',(1.17,-7.30,1.13),(.40,.025,.14),dark,col['details'],.006)
    return col
