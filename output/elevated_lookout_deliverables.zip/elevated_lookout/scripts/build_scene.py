"""Build real editable geometry and export GLB. LOOKOUT_RENDER=1 also renders PNG."""
import os,sys,math
from pathlib import Path
import bpy
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
sys.path.insert(0,str(ROOT/'scripts'))
from geometry import *
from architecture import build_architecture
from garden import build_garden
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):bpy.data.collections.remove(c)
architecture=build_architecture();print('ARCHITECTURE_READY',flush=True)
garden=build_garden();print('WOODLAND_READY',flush=True)
stage=collection('12_Soft_Afternoon_Studio')
back=material('Clean soft warm grey studio',(.78,.81,.79),.96,cel=False)
cube('Studio floor outside model',(0,0,-.64),(200,200,.10),back,stage,0)
def light(name,typ,loc,power,color,size=8):
    d=bpy.data.lights.new(name,typ);d.energy=power;d.color=color
    if typ=='SUN':d.angle=math.radians(12)
    else:d.shape='DISK';d.size=size
    o=bpy.data.objects.new(name,d);stage.objects.link(o);o.location=loc;o.rotation_euler=(Vector((0,1,2))-o.location).to_track_quat('-Z','Y').to_euler()
light('Soft warm woodland afternoon','SUN',(-12,-17,25),2.3,(1,.91,.78))
light('Large sky fill','AREA',(8,-1,18),1800,(.74,.86,1),18)
camd=bpy.data.cameras.new('Lookout 45 degree orthographic camera');cam=bpy.data.objects.new(camd.name,camd);stage.objects.link(cam)
target=Vector((0,.3,2.3));cam.location=target+Vector((12,-22,25.06));cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler();camd.type='ORTHO';camd.ortho_scale=34.8
s=bpy.context.scene;s.name='Elevated_Lookout_Complete_Model';s.camera=cam;s.render.engine='BLENDER_EEVEE_NEXT'
s.render.resolution_x=s.render.resolution_y=1800;s.render.resolution_percentage=int(os.environ.get('LOOKOUT_RENDER_PERCENT','100'))
s.render.image_settings.file_format='PNG';s.render.filepath='//elevated_lookout.png';s.render.fps=24;s.frame_start=1;s.frame_end=120;s.frame_set(1)
s.world.use_nodes=True;bg=s.world.node_tree.nodes.get('Background');bg.inputs[0].default_value=(.66,.78,.92,1);bg.inputs[1].default_value=.5
s.view_settings.view_transform='AgX';s.view_settings.look='AgX - Medium High Contrast';s.view_settings.exposure=.10
s.eevee.use_raytracing=True;s.eevee.taa_render_samples=48
s.render.use_freestyle=True;s.render.line_thickness=.6
ls=bpy.context.view_layer.freestyle_settings.linesets[0];ls.linestyle.color=(.17,.18,.15);ls.linestyle.thickness=.50
ls.select_crease=False;ls.select_silhouette=True;ls.select_external_contour=True;ls.select_border=False
outline=collection('13_Restrained_Architecture_Outlines')
for c in architecture.values():
    for o in c.objects:
        if not any(word in o.name for word in ['grid','individual ceramic','graphic','grain']):outline.objects.link(o)
ls.select_by_collection=True;ls.collection=outline;ls.collection_negation='INCLUSIVE'
s['Project']='双层架空观景亭 · 三渲二微缩林间园景'
s['Structure']='Two accessible open levels; white square tiled piers; radial flared concrete beams; one small upper tiled roof; long straight staircase and separately oriented level side bridge.'
s['Photo_based_estimate']='Reconstructed from three photos, not survey drawings. Dimensions and unseen edges are estimates. The unseen bridge continuation ends safely at a supported railing inside the miniature base.'
s['Elevations']='Ground 0.16; lower resting floor 0.46; upper observation deck and bridge 4.25; 26 outdoor stair treads.'
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D':area.spaces.active.region_3d.view_perspective='CAMERA';area.spaces.active.shading.type='MATERIAL'
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'elevated_lookout.blend'));print('BLEND_SAVED',len(s.objects),flush=True)
for m in bpy.data.materials:
    if m.use_nodes:
        p=m.node_tree.nodes.get('Principled BSDF')
        if p:
            for link in list(p.inputs['Base Color'].links):m.node_tree.links.remove(link)
            p.inputs['Base Color'].default_value=m.diffuse_color
bpy.ops.object.select_all(action='DESELECT')
for o in s.objects:
    if o.type=='MESH' and o.name!='Studio floor outside model':o.select_set(True)
bpy.ops.export_scene.gltf(filepath=str(OUT/'elevated_lookout.glb'),export_format='GLB',use_selection=True,export_apply=True,export_animations=True,export_materials='EXPORT',export_extras=True,export_lights=False)
print('GLB_SAVED',flush=True)
if os.environ.get('LOOKOUT_RENDER')=='1':
    bpy.ops.wm.open_mainfile(filepath=str(OUT/'elevated_lookout.blend'));bpy.ops.render.render(write_still=True)
