"""Layered woodland around curving walks; all roots and low foliage avoid hardscape."""
import math,random
from mathutils import Vector
from geometry import *
from layout import *

def plantable(x,y,margin=.15):
    if max(abs(x),abs(y))>11.70-margin:return False
    if on_path(x,y,margin) or on_stair(x,y,margin) or on_bridge(x,y,margin):return False
    if -.0-margin<x<1.60+margin and -1.55-margin<y<-.8+margin:return False
    if math.hypot(x-1.17,y+7.05)<.50+margin:return False
    if math.hypot(x+2.01,y+4.40)<.28+margin:return False
    return not any(inside(x+dx,y+dy,POLYGON) for dx,dy in [(0,0),(margin,0),(-margin,0),(0,margin),(0,-margin)])

def build_garden():
    rng=random.Random(43824)
    base=collection('00_Complete_Square_Collectible_Platform')
    paths=collection('01_Curving_Garden_Walks')
    trees=collection('10_Tall_Woodland_Trees')
    ground=collection('11_Shrubs_Ferns_and_Groundcover')
    stone=material('Pale stone plinth edge',(.45,.48,.44),.85)
    soil=material('Dark earth cut section',(.14,.115,.072),.95)
    turf=material('Natural muted forest lawn',(.115,.175,.060),.95)
    edge=material('Pale path edging stone',(.57,.59,.52),.86)
    red=material('Reddish brown fine grain garden path',(.31,.18,.135),.94)
    grainm=[material('Fine path aggregate '+str(i),c,.92) for i,c in enumerate([(.42,.28,.21),(.23,.14,.11),(.35,.23,.18)])]
    bark=material('Naturally branched grey brown bark',(.22,.205,.16),.9)
    greens=[material('Leaf cluster shade '+str(i),c,.84) for i,c in enumerate([(.045,.11,.045),(.065,.17,.055),(.10,.23,.073),(.17,.30,.095),(.25,.37,.125),(.29,.42,.18)])]
    cube('Complete 24 metre square stone base',(0,0,-.29),(24,24,.56),stone,base,.08)
    cube('Recessed earth shadow band',(0,0,-.08),(23.84,23.84,.14),soil,base,.025)
    cube('Continuous woodland soil and turf',(0,0,.08),(23.60,23.60,.16),turf,base,.035)
    grain=Batch()
    for idx,(line,width) in enumerate(PATH_LINES):
        path=Batch();edging=Batch();cross=[]
        for j,p in enumerate(line):
            d=(line[min(j+1,len(line)-1)]-line[max(0,j-1)]).normalized();cross.append((p,Vector((-d.y,d.x))))
        for j in range(len(line)-1):
            a,na=cross[j];b,nb=cross[j+1]
            def ribbon(lo,hi,z,batch):
                lo,hi=min(lo,hi),max(lo,hi)
                batch.add([(p.x+n.x*s,p.y+n.y*s,z) for p,n,s in [(a,na,lo),(a,na,hi),(b,nb,hi),(b,nb,lo)]],[(3,2,1,0)])
            ribbon(-width/2,width/2,GROUND+.012,path)
            for sign in [-1,1]:
                p=(a+b)/2+na*sign*(width/2+.04)
                crosspath=any(k!=idx and any(distance_to_segment(p,c,d)<w/2+.03 for c,d in zip(ll,ll[1:])) for k,(ll,w) in enumerate(PATH_LINES))
                if not crosspath and not on_stair(p.x,p.y,.03):ribbon(sign*(width/2+.01),sign*(width/2+.075),GROUND+.035,edging)
            for k in range(17):
                p=a.lerp(b,rng.random())+na*rng.uniform(-width*.48,width*.48)
                grain.leaf((p.x,p.y,GROUND+.015),rng.uniform(.016,.037),.012,rng.random()*math.tau,0,rng.randrange(3))
        path.finish('Curved red woodland walking path '+str(idx+1),[red],paths)
        edging.finish('Stone edging around path '+str(idx+1),[edge],paths)
    grain.finish('Small mineral grains in path surface',grainm,paths)
    tree_positions=[(-8.6,6.8,9.4,2.05),(-4.8,9.0,10.1,2.1),(.6,9.5,10.4,1.9),(5.2,9.3,9.7,1.7),(-9.2,1.5,8.6,1.75),(9.8,-.7,9.0,1.55)]
    for idx,(x,y,h,spread) in enumerate(tree_positions):
        assert plantable(x,y,.28),(x,y)
        trunk=Batch();leaves=Batch();centers=[]
        lean=Vector((rng.uniform(-.35,.35),rng.uniform(-.3,.3),0))
        root=Vector((x,y,GROUND))
        trunk.tube([root,root+lean*.25+Vector((0,0,h*.42)),root+lean+Vector((0,0,h*.88))],[.19,.13,.035],0,14)
        for j in range(16):
            a=j*2.399+.3*idx;level=.51+j*.025;reach=spread*rng.uniform(.5,.98)
            start=root+lean*.5+Vector((0,0,h*(level-.1)))
            end=root+lean+Vector((math.cos(a)*reach,math.sin(a)*reach,h*level+.5))
            trunk.tube([start,start.lerp(end,.55)+Vector((0,0,.12)),end],[.055,.027,.007],0,9)
            centers.append((end,spread*.57,spread*.50,.65))
        centers.append((root+lean+Vector((0,0,h-.15)),spread*.64,spread*.51,.62))
        for center,rx,ry,rz in centers:
            for k in range(155):
                phi=rng.random()*math.tau;zz=rng.uniform(-1,1);rr=math.sqrt(1-zz*zz)*rng.uniform(.30,1)
                p=center+Vector((rx*rr*math.cos(phi),ry*rr*math.sin(phi),rz*zz));L=rng.uniform(.22,.39)
                if max(abs(p.x),abs(p.y))+L/2>11.65:continue
                if -4.05<p.x<4.05 and -1.8<p.y<5.9 and p.z<9.3:continue
                if on_bridge(p.x,p.y,.40) and p.z<6.6:continue
                leaves.leaf(p,L,L*rng.uniform(.32,.53),rng.random()*math.tau,rng.uniform(-.8,.8),rng.randrange(6))
        tr=trunk.finish('Natural branching tree trunk %d'%(idx+1),[bark],trees,True);tr['plant_root']=[x,y]
        crown=leaves.finish('Layered broadleaf canopy %d'%(idx+1),greens,trees,origin=(x,y,GROUND));wave_animation(crown,'rotation_euler',1,.0018,idx*.55)
    # Uneven low shrubs instead of repeated spherical topiary.
    shrub_positions=[(-6.6,-8.2,.8,.62),(-4.6,-6.1,.9,.65),(-5.4,-4.4,.9,.75),(-7.8,-3.9,1.0,.85),(-9.7,3,.9,.7),(-5.0,4.3,.75,.75),(-4.6,6.2,1,.8),(-2.6,7.5,.9,.65),(1.8,7.6,.9,.72),(5.5,6.7,.8,.7),(9.9,8.3,.7,.65),(7.1,-5.3,1.0,.55),(5.1,-7.8,.9,.57),(8.8,-8.1,1,.75),(9.5,-4.2,.8,.60),(-8.7,-9.5,.9,.5),(0,-5.1,.5,.4),(4.3,.4,.6,.6)]
    for idx,(x,y,spread,h) in enumerate(shrub_positions):
        if not plantable(x,y,.25):continue
        b=Batch()
        for k in range(350):
            angle=rng.random()*math.tau;rad=math.sqrt(rng.random())*spread
            px=x+math.cos(angle)*rad;py=y+math.sin(angle)*rad
            if not plantable(px,py,.22):continue
            z=GROUND+.12+h*(1-(rad/spread)**2)*rng.uniform(.35,1.05)
            L=rng.uniform(.16,.28);b.leaf((px,py,z),L,L*.50,angle+rng.uniform(-1,1),rng.uniform(-.3,.7),rng.randrange(5))
        o=b.finish('Irregular woodland shrub %02d'%idx,greens,ground);o['plant_root']=[x,y];o['low_plant_mesh']=True
    ferns=Batch()
    for x,y in [(-2.7,-6.0),(5.4,-4.3),(6.0,1.6),(-4.5,1.4),(-6.4,3.2),(9.8,5.5),(1.6,6.7),(-8.4,-5.9),(4.8,-10.1)]:
        if not plantable(x,y,.5):continue
        for j in range(11):
            a=j*2.399;reach=rng.uniform(.27,.60);end=Vector((x+math.cos(a)*reach,y+math.sin(a)*reach,GROUND+.24))
            start=Vector((x,y,GROUND+.03));mid=start.lerp(end,.5)+Vector((0,0,.24))
            for k in range(1,8):
                t=k/8;p=(1-t)**2*start+2*t*(1-t)*mid+t*t*end
                for side in [-1,1]:
                    aa=a+side*.85;L=.23*(1-t)+.04;q=p+Vector((math.cos(aa)*L*.32,math.sin(aa)*L*.32,0))
                    if plantable(q.x,q.y,.18):ferns.leaf(q,L,.052,aa,.2,rng.randrange(2,6))
    fo=ferns.finish('Distinct fern fronds on woodland soil',greens,ground);fo['low_plant_mesh']=True
    grass=Batch()
    for j in range(3500):
        x=rng.uniform(-11.5,11.5);y=rng.uniform(-11.5,11.5)
        if not plantable(x,y,.18):continue
        for k in range(3):grass.leaf((x,y,GROUND+.07),rng.uniform(.10,.22),.018,rng.random()*math.tau,1.4,rng.randrange(1,6))
    gr=grass.finish('Fine irregular grass tufts away from paving',greens,ground);gr['low_plant_mesh']=True
    understory=Batch()
    for j in range(700):
        x=rng.uniform(-11.4,11.4);y=rng.uniform(-11.4,11.4)
        # Denser woodland margins and scattered open patches keep the paths legible.
        if abs(x)<4.0 and y<5.8 and rng.random()<.8:continue
        if not plantable(x,y,.40):continue
        for k in range(13):
            a=rng.random()*math.tau;reach=rng.uniform(.02,.25)
            px=x+math.cos(a)*reach;py=y+math.sin(a)*reach
            if plantable(px,py,.19):
                understory.leaf((px,py,GROUND+rng.uniform(.07,.25)),rng.uniform(.14,.28),rng.uniform(.055,.10),a,rng.uniform(.2,1.2),rng.randrange(1,5))
    u=understory.finish('Layered broadleaf woodland understory patches',greens,ground);u['low_plant_mesh']=True
    fallen=Batch()
    for j in range(70):
        x=rng.uniform(-10.5,10.5);y=rng.uniform(-10.5,10.5)
        if plantable(x,y,.12):fallen.leaf((x,y,GROUND+.006),.10,.045,rng.random()*math.tau,.02,rng.randrange(3))
    fallen.finish('Sparse natural fallen leaves',grainm,ground)
    return {'base':base,'paths':paths,'trees':trees,'ground':ground}
