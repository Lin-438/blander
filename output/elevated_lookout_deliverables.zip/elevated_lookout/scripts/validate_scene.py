"""Validate real access, bridge levels, static architecture and planted/paved boundaries."""
import bpy,sys,json,struct,math
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'scripts'))
from layout import *
from geometry import inside
from garden import plantable
bpy.ops.wm.open_mainfile(filepath=str(root/'output/elevated_lookout.blend'))
s=bpy.context.scene
treads=sorted([o for o in s.objects if o.get('role')=='upper_access_tread'],key=lambda o:o['tread_index'])
assert len(treads)==26
assert abs(treads[-1]['top_elevation']-DECK)<1e-6
assert all(abs(treads[i+1]['top_elevation']-treads[i]['top_elevation']-(DECK-GROUND)/26)<1e-6 for i in range(25))
assert len([o for o in s.objects if o.name.startswith('Lower square tiled pillar') and 'grid' not in o.name])==6
assert len([o for o in s.objects if o.name.startswith('Upper small pavilion tiled pillar') and 'grid' not in o.name])==6
assert len([o for o in s.objects if o.name.startswith('Bridge independent tiled pier') and 'grid' not in o.name])==3
assert s.objects['Wide load bearing upper deck']['floor_elevation']==s.objects['Mitred level elevated side walkway']['floor_elevation']
assert (BRIDGE_START-Vector(POLYGON[0]).lerp(Vector(POLYGON[1]),.5)).length<1e-6
stair_direction=Vector((0,1));bridge_direction=(BRIDGE_POINTS[1]-BRIDGE_POINTS[0]).normalized()
assert abs(stair_direction.dot(bridge_direction))<.85
assert abs(STAIR_END-(2-RADIUS*math.sqrt(3)/2))<1e-6
def bounds(o,axis):
    values=[(o.matrix_world@Vector(v))[axis] for v in o.bound_box]
    return min(values),max(values)
for o in treads:assert abs(bounds(o,2)[1]-o['top_elevation'])<1e-5
for a,b in zip(treads,treads[1:]):
    assert bounds(b,1)[0]<=bounds(a,1)[1]+.001,'Treads must meet continuously'
assert abs(bounds(treads[-1],1)[1]-STAIR_END)<.01
for o in s.objects:
    if any(c.name.startswith(('02_','03_','04_','05_','06_','07_','08_','09_')) for c in o.users_collection):assert not o.animation_data,o.name
roots=[o for o in s.objects if 'plant_root' in o]
assert all(plantable(*o['plant_root'],.05) for o in roots)
# Test the actual low-leaf vertices against paved ribbons, not only root points.
segments=[]
for line,w in PATH_LINES:
    for a,b in zip(line,line[1:]):
        dx=b.x-a.x;dy=b.y-a.y;segments.append((a.x,a.y,dx,dy,dx*dx+dy*dy,(w/2)**2))
count=0
for o in s.objects:
    if not o.get('low_plant_mesh'):continue
    for v in o.data.vertices:
        p=o.matrix_world@v.co;x,y=p.x,p.y;count+=1
        assert not inside(x,y,POLYGON),(o.name,'platform')
        assert not on_stair(x,y,0),(o.name,'stair')
        for ax,ay,dx,dy,dd,r2 in segments:
            if abs(x-ax)>3 or abs(y-ay)>3:continue
            t=max(0,min(1,((x-ax)*dx+(y-ay)*dy)/max(dd,1e-9)))
            assert (x-ax-t*dx)**2+(y-ay-t*dy)**2>=r2,(o.name,'paving',x,y)
maximum=[0,0]
for fr in [1,31,61,91,121]:
    s.frame_set(fr);deps=bpy.context.evaluated_depsgraph_get()
    for o in s.objects:
        if o.type!='MESH' or o.name=='Studio floor outside model':continue
        ev=o.evaluated_get(deps)
        for v in ev.bound_box:
            p=ev.matrix_world@Vector(v)
            maximum=[max(maximum[0],abs(p.x)),max(maximum[1],abs(p.y))]
            assert max(abs(p.x),abs(p.y))<=12.01,(o.name,fr,list(p))
assert s.render.filepath=='//elevated_lookout.png'
b=(root/'output/elevated_lookout.glb').read_bytes();j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]])
assert not any('uri' in v for v in j.get('buffers',[]))
assert len(j.get('animations',[]))==6
report={'result':'passed','occupied_open_levels':2,'lower_square_columns':6,'upper_square_columns':6,'outdoor_stair_treads':26,'ground_elevation':GROUND,'lower_floor_elevation':LOWER_FLOOR,'upper_deck_and_bridge_elevation':DECK,'bridge_independent_piers':3,'stair_bridge_noncollinear':True,'continuous_treads':True,'planted_roots_checked':len(roots),'low_foliage_vertices_checked':count,'foliage_clear_of_paving':True,'animated_architecture':False,'animated_tree_canopies':6,'square_base':[24,24],'maximum_xy':maximum,'self_contained_glb':True,'reference_limit':'Photo-based dimensions and unseen bridge endpoint are estimates.'}
(root/'output/validation.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
