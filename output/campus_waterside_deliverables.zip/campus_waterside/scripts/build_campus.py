"""Photo-based campus waterside pavilion, single eave, editable Blender scene.
Run with Blender 4.3.2. All proportions are visual estimates from six views.
"""
import os,sys,math,random,json
import bpy
from mathutils import Vector
ROOT=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT=os.path.join(ROOT,'output'); os.makedirs(OUT,exist_ok=True)
sys.path.insert(0,os.path.dirname(__file__))
from geometry import *
R=random.Random(43822)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
    if c.name!='Collection': bpy.data.collections.remove(c)
CBASE=collection('00_Square_Landscape_Base')
CPOND=collection('01_Pond_and_Floating_Leaves')
CWALK=collection('02_Raised_Zigzag_Walkways')
CRAIL=collection('03_Stone_and_Metal_Railings')
CPAV=collection('04_Single_Storey_Hexagonal_Pavilion')
CROOF=collection('05_Single_Tier_Tiled_Roof')
CGREEN=collection('06_Campus_Trees_and_Bamboo')
CBUILD=collection('07_Subordinate_Campus_Background')
CSTAGE=collection('08_Daylight_Presentation')

STONE=material('Warm pale grey concrete',(.56,.57,.51),.76)
EDGE=material('Darker foundation stone',(.30,.33,.31),.81)
WHITE=material('Ivory painted beams and soffit',(.83,.81,.69),.7)
YELLOW=material('Original pale ochre round columns',(.72,.56,.27),.62)
PINK=material('Subdued rose grey post caps',(.49,.36,.31),.72)
WOOD=material('Red brown carved wood',(.24,.085,.042),.67)
INSET=material('Dark red ornamental frieze',(.16,.058,.035),.8)
SILVER=material('Brushed silver safety railing',(.56,.62,.62),.28,.8,False)
SEAT=material('Grey stone tables and seats',(.28,.32,.31),.49)
PLANTER=material('Pale yellow tiled planters',(.64,.68,.43),.8)
EARTH=material('Moist planter earth',(.10,.105,.055),.95)
MORTAR=material('Deep joints below terracotta tiles',(.20,.08,.038),.92)
TILES=[material('Muted orange red ceramic %d'%i,(.50+i*.030,.16+i*.015,.062+i*.007),.58) for i in range(6)]
PAVING=[material('Pale courtyard tile %d'%i,(.64+i*.018,.65+i*.015,.60+i*.013),.64) for i in range(4)]
BLUETILE=material('Subtle blue grey paving bands',(.44,.54,.57),.66)

cube('Complete square stone presentation base',(0,0,-.08),(24,24,.56),STONE,CBASE,.14)
cube('Narrow dark plinth reveal',(0,0,-.29),(23.94,23.94,.09),EDGE,CBASE,.045)
cube('Pond basin dark floor',(0,0,.21),(23.55,23.55,.09),EDGE,CBASE,.045)

# Visible connection graph: a foreground zigzag, its left bank branch, and the
# right-hand turn toward the bamboo bank. The terrace is one continuous surface.
main_path=[(-2.6,-10.5),(-2.6,-8.0),(-6.5,-8.0),(-6.5,-4.3),(-2.3,-4.3),(-2.3,.9)]
branches=[[(-6.5,-4.3),(-10.45,-4.3)],[(4.0,1.9),(9.2,1.9),(9.2,6.5)]]
rects=[]
for route in [main_path]+branches:
    for a,b in zip(route,route[1:]):
        w=.8
        rects.append((min(a[0],b[0])-w,max(a[0],b[0])+w,min(a[1],b[1])-w,max(a[1],b[1])+w))
def onwalk(x,y): return any(x0-1e-5<=x<=x1+1e-5 and y0-1e-5<=y<=y1+1e-5 for x0,x1,y0,y1 in rects)
platform=[(-3.45,.25),(4.35,.25),(5.15,1.40),(5.15,4.60),(3.55,6.55),(-2.4,6.55),(-3.45,4.85)]
poly_slab('Main supported waterside terrace',platform,1.91,.31,STONE,CWALK)
xs=sorted(set(round(v,4) for q in rects for v in q[:2]))
ys=sorted(set(round(v,4) for q in rects for v in q[2:]))
occupied={(i,j) for i in range(len(xs)-1) for j in range(len(ys)-1) if onwalk((xs[i]+xs[i+1])/2,(ys[j]+ys[j+1])/2)}
slab=Batch(); edges=[]
for i,j in occupied:
    x0,x1,y0,y1=xs[i],xs[i+1],ys[j],ys[j+1]
    slab.box(((x0+x1)/2,(y0+y1)/2,1.97),(x1-x0,y1-y0,.30))
    for di,dj,a,b in [(-1,0,(x0,y0),(x0,y1)),(1,0,(x1,y0),(x1,y1)),(0,-1,(x0,y0),(x1,y0)),(0,1,(x0,y1),(x1,y1))]:
        if (i+di,j+dj) not in occupied: edges.append((a,b))
slab.finish('Continuous branching walkway structural slabs',[STONE],CWALK)

# Merge collinear boundary spans; railing follows the real turns and never crosses a junction.
groups={}
for a,b in edges:
    if abs(a[0]-b[0])<1e-5: key=('v',a[0]); segment=sorted([a[1],b[1]])
    else: key=('h',a[1]); segment=sorted([a[0],b[0]])
    groups.setdefault(key,[]).append(segment)
merged=[]
for (axis,value),segments in groups.items():
    spans=[]
    for lo,hi in sorted(segments):
        if spans and lo<=spans[-1][1]+.001: spans[-1][1]=max(hi,spans[-1][1])
        else: spans.append([lo,hi])
    for lo,hi in spans:
        merged.append(((value,lo),(value,hi)) if axis=='v' else ((lo,value),(hi,value)))

# Fine square paving modules, including the faint blue bands of the terrace photos.
pave=Batch(); pmat=PAVING+[BLUETILE]
for is_plaza in [False,True]:
    xlo,xhi,ylo,yhi=(-3.45,5.15,.25,6.55) if is_plaza else (-11.25,10.0,-11.3,7.3)
    xx=sorted(set([xlo,xhi]+[xlo+i*.4 for i in range(1,int((xhi-xlo)/.4)+1)]+([p[0] for p in platform] if is_plaza else [v for r in rects for v in r[:2]])))
    yy=sorted(set([ylo,yhi]+[ylo+i*.4 for i in range(1,int((yhi-ylo)/.4)+1)]+([p[1] for p in platform] if is_plaza else [v for r in rects for v in r[2:]])))
    for i in range(len(xx)-1):
        for j in range(len(yy)-1):
            x0,x1,y0,y1=xx[i],xx[i+1],yy[j],yy[j+1]; cx,cy=(x0+x1)/2,(y0+y1)/2
            allowed=inside(cx,cy,platform) if is_plaza else onwalk(cx,cy) and not inside(cx,cy,platform)
            if not allowed or min(x1-x0,y1-y0)<.025: continue
            if is_plaza and not all(inside(x,y,platform) for x,y in [(x0+.01,y0+.01),(x1-.01,y0+.01),(x1-.01,y1-.01),(x0+.01,y1-.01)]): continue
            mi=4 if is_plaza and (i%8==1 or j%8==1) else R.randrange(4)
            pave.box((cx,cy,2.235 if is_plaza else 2.137),(x1-x0-.008,y1-y0-.008,.035),mi)
pave.finish('Individually jointed square paving',[*pmat],CWALK)

piers=Batch(); seen_piers=set()
def pier(x,y):
    key=(round(x,2),round(y,2))
    if key in seen_piers: return
    seen_piers.add(key)
    piers.box((x,y,1.025),(.28,.28,1.78),0)
    piers.box((x,y,.54),(.291,.291,.16),1)
for a,b in merged:
    a,b=Vector((*a,0)),Vector((*b,0)); L=(b-a).length
    for j in range(max(1,math.ceil(L/2.3))+1):
        p=a.lerp(b,j/max(1,math.ceil(L/2.3))); pier(p.x,p.y)
for x in [-3,-.6,1.8,4.5]:
    for y in [.65,3.1,5.8]:
        if inside(x,y,platform): pier(x,y)
piers.finish('Visible concrete supporting piers and waterline staining',[STONE,EDGE],CWALK)

rail=Batch(); posts=set()
def railpost(p):
    p=Vector(p); key=(round(p.x,3),round(p.y,3))
    if key in posts: return
    posts.add(key)
    rail.box((p.x,p.y,2.70),(.17,.17,1.07),0)
    for z in [2.30,2.57,2.83]: rail.box((p.x,p.y,z),(.177,.177,.014),3)
    rail.box((p.x,p.y,3.28),(.245,.245,.25),1)
    rail.box((p.x,p.y,3.12),(.20,.20,.055),0)
def stone_rail(a,b):
    aa,bb=Vector((*a,0)),Vector((*b,0)); L=(bb-aa).length
    n=max(1,math.ceil(L/1.55)); pts=[aa.lerp(bb,j/n) for j in range(n+1)]
    for p in pts: railpost(p)
    for p,q in zip(pts,pts[1:]):
        for z in [2.46,3.04]: rail.beam(p+Vector((0,0,z)),q+Vector((0,0,z)),.135,.14,0)
        for t in [.30,.70]:
            r=p.lerp(q,t)
            rail.lathe((r.x,r.y,2.54),[(0,.055),(.045,.075),(.09,.053),(.23,.072),(.38,.045),(.43,.050)],2,12)
for a,b in merged:
    # Split by small lengths to omit spans covered by the continuous main terrace.
    av,bv=Vector(a),Vector(b); n=max(1,math.ceil((bv-av).length/.30)); runs=[]; active=None
    for k in range(n):
        p=av.lerp(bv,(k+.5)/n)
        omit=inside(p.x,p.y,platform) or p.y< -11.2 or p.x< -11.15 or p.y>6.35
        if not omit and active is None: active=k/n
        if omit and active is not None: runs.append((active,k/n)); active=None
    if active is not None: runs.append((active,1))
    for lo,hi in runs:
        if hi-lo>.01: stone_rail(tuple(av.lerp(bv,lo)),tuple(av.lerp(bv,hi)))
bevel(rail.finish('Photographed square posts, thick rails and red brown balusters',[STONE,PINK,WOOD,EDGE],CRAIL),.010,1)

# The terrace planters belong to the campus scene, not an invented garden bridge.
for idx,(x,y,sx,sy) in enumerate([(.9,.68,4.8,.72),(-2.95,3.3,.65,4.2)]):
    cube('Raised pale tiled planter %d'%idx,(x,y,2.47),(sx,sy,.47),PLANTER,CWALK,.025)
    cube('Planter rim %d'%idx,(x,y,2.71),(sx+.06,sy+.06,.075),STONE,CWALK,.012)
    cube('Planter soil %d'%idx,(x,y,2.755),(sx-.10,sy-.10,.05),EARTH,CWALK,.0)
    joints=Batch()
    if sx>sy:
        for j in range(int(sx/.12)):
            xx=x-sx/2+j*.12; joints.box((xx,y-sy/2-.003,2.49),(.008,.008,.39))
    else:
        for j in range(int(sy/.12)):
            yy=y-sy/2+j*.12; joints.box((x-sx/2-.003,yy,2.49),(.008,.008,.39))
    joints.finish('Planter tile joints %d'%idx,[EDGE],CWALK)

P=Vector((1.3,3.3,0)); ANG=[math.radians(-120+i*60) for i in range(6)]
def ring(r,i,z): return P+Vector((r*math.cos(ANG[i%6]),r*math.sin(ANG[i%6]),z))
hexagon=[tuple(ring(2.55,i,0)[:2]) for i in range(6)]
poly_slab('Slightly raised hexagonal pavilion floor',hexagon,2.24,.18,PINK,CPAV)
poly_slab('Polished polygonal paving',[(P.x+2.52*math.cos(a),P.y+2.52*math.sin(a)) for a in ANG],2.42,.025,PAVING[2],CPAV)
floor=Batch()
for i in range(-5,6):
    for j in range(-5,6):
        x,y=P.x+i*.43,P.y+j*.43
        if all(inside(xx,yy,hexagon) for xx,yy in [(x-.21,y-.21),(x+.21,y-.21),(x+.21,y+.21),(x-.21,y+.21)]):
            floor.box((x,y,2.455),(.423,.423,.022),R.randrange(4))
floor.finish('Pavilion floor tile grid',PAVING,CPAV)
cube('Low front pavilion step',(P.x,P.y-2.42,2.32),(1.65,.43,.14),STONE,CPAV,.018)
cube('Terrace entry level transition',(-2.3,.20,2.19),(1.60,.36,.11),PAVING[1],CWALK,.012)

for i in range(6):
    b=Batch(); p=ring(1.95,i,0)
    b.cylinder((p.x,p.y,4.19),.14,3.47,0,32)
    b.cylinder((p.x,p.y,2.49),.161,.065,1,24)
    b.cylinder((p.x,p.y,5.92),.155,.075,0,24)
    b.finish('Pale yellow pavilion column %d'%(i+1),[YELLOW,STONE],CPAV,True)
woodwork=Batch(); fret=Batch()
for i in range(6):
    a,b=ring(1.95,i,5.46),ring(1.95,i+1,5.46)
    woodwork.beam(a,b,.17,.27,0)
    topa,topb=ring(1.95,i,5.99),ring(1.95,i+1,5.99)
    woodwork.beam(topa,topb,.12,.105,0)
    # Carved floral/scroll grille panels sit directly below the single roof.
    for zz in [5.65,5.94]: fret.beam(ring(1.95,i,zz),ring(1.95,i+1,zz),.035,.035)
    for t in [.17,.39,.61,.83]:
        center=a.lerp(b,t); center.z=5.795
        tangent=(b-a).normalized(); normal=Vector((0,0,1))
        pts=[center+tangent*(.095*math.cos(k*math.tau/28))+normal*(.116*math.sin(k*math.tau/28)) for k in range(29)]
        fret.tube(pts,.013,0,6)
        for phi in [0,math.pi/2,math.pi,3*math.pi/2]:
            q=center+tangent*(.055*math.cos(phi))+normal*(.065*math.sin(phi))
            fret.tube([center,q],.011,0,6)
    # Shallow curved brackets under the beam; the pavilion stays open.
    for t,sign in [(0,1),(1,-1)]:
        q=a.lerp(b,t); tangent=(b-a).normalized()*sign
        pts=[q+Vector((0,0,-.10)),q+tangent*.12+Vector((0,0,-.27)),q+tangent*.36+Vector((0,0,-.22)),q+tangent*.46+Vector((0,0,-.10))]
        fret.tube(pts,[.037,.031,.022,.017],0,8)
woodwork.finish('Single ring of ivory structural beams',[WHITE],CPAV)
fret.finish('Red brown floral friezes and curved brackets',[INSET],CPAV,True)

# Central stone table and four low drum stools, with restrained stone furniture.
furniture=Batch()
furniture.lathe((P.x,P.y,2.46),[(0,.23),(.08,.26),(.17,.16),(.58,.16),(.63,.30),(.69,.58),(.77,.58)],0,40)
for a in [0,math.pi/2,math.pi,3*math.pi/2]:
    x,y=P.x+.98*math.cos(a),P.y+.98*math.sin(a)
    furniture.lathe((x,y,2.46),[(0,.20),(.05,.23),(.18,.22),(.32,.25),(.40,.23),(.44,.24)],0,24)
furniture.finish('Stone table and four drum stools',[SEAT],CPAV,True)

# Distinct silver curved railing around the pavilion terrace; open at the approach.
metal=Batch(); bench=Batch()
angles=[math.radians(-27+i*(234/64)) for i in range(65)]
for zz,rad in [(3.28,2.98),(2.76,2.98)]:
    metal.tube([(P.x+rad*math.cos(a),P.y+rad*math.sin(a),zz) for a in angles],.033 if zz>3 else .022,0,10)
for j in range(25):
    a=angles[0]+(angles[-1]-angles[0])*j/24; x,y=P.x+2.98*math.cos(a),P.y+2.98*math.sin(a)
    metal.cylinder((x,y,2.75),.026,1.07,0,10)
    if j%2==0:
        metal.lathe((x,y,3.27),[(0,.03),(.025,.05),(.065,.045),(.09,.0)],0,10)
for i in [1,2,3,4]:
    a,b=ring(2.61,i,2.83),ring(2.61,i+1,2.83)
    bench.beam(a,b,.36,.09,0)
    for t in [.15,.85]:
        p=a.lerp(b,t); bench.box((p.x,p.y,2.55),(.14,.18,.46),1)
metal.finish('Arc-shaped brushed stainless steel guardrail',[SILVER],CRAIL,True)
bench.finish('Simple perimeter stone resting benches',[SEAT,STONE],CPAV)

# ONE six-sided, pointed roof. No second tier and no upper storey.
def rp(side,u,s):
    a,b=Vector((math.cos(ANG[side]),math.sin(ANG[side]),0)),Vector((math.cos(ANG[(side+1)%6]),math.sin(ANG[(side+1)%6]),0))
    q=a.lerp(b,u)*(.055+3.195*s)
    return P+q+Vector((0,0,5.99+2.12*(1-s)**2.22+.43*abs(2*u-1)**3.5*s**4))
for side in range(6):
    vs=[]; fs=[]; nu,nv=40,32
    for j in range(nv+1):
        for k in range(nu+1): vs.append(rp(side,k/nu,j/nv)-Vector((0,0,.055)))
    for j in range(nv):
        for k in range(nu):
            a=j*(nu+1)+k; fs.append((a,a+nu+1,a+nu+2,a+1))
    o=object_mesh('Single roof ivory soffit %d'%(side+1),vs,fs,[WHITE],CROOF,smooth=True)
    sol=o.modifiers.new('Thin real roof thickness','SOLIDIFY'); sol.thickness=.095; sol.offset=-1
    object_mesh('Single roof dark tile bedding %d'%(side+1),[Vector(v)+Vector((0,0,.057)) for v in vs],fs,[MORTAR],CROOF,smooth=True)
    tiles=Batch(); ends=Batch(); cols,rows=24,21
    for c in range(cols):
        u=(c+.5)/cols
        for row in range(rows):
            s0=row/rows; s1=min(1,(row+1.05)/rows); v=[]; f=[]; mi=R.randrange(6)
            for j in range(3):
                s=s0+(s1-s0)*j/2; rad=(.055+3.195*s)/cols*.46
                for k in range(9):
                    th=k*math.pi/8; q=rp(side,u+math.cos(th)*.44/cols,s)
                    q.z+=.022+math.sin(th)*rad+.01*(1-j/2); v.append(q)
            for j in range(2):
                for k in range(8):
                    a=j*9+k; f.append((a,a+1,a+10,a+9))
            f.append(tuple(18+k for k in range(9))); tiles.add(v,f,mi)
            if c<cols-1:
                pan=[rp(side,uu,ss)+Vector((0,0,.012)) for ss,uu in [(s0,u+.44/cols),(s0,u+.56/cols),(s1,u+.56/cols),(s1,u+.44/cols)]]
                tiles.add(pan,[(3,2,1,0)],mi)
        q=rp(side,u,1)+Vector((0,0,.025)); direction=(q-rp(side,u,.985)).normalized()
        ends.tube([q-direction*.015,q+direction*.018],3.25/cols*.46,3,16)
        ends.tube([q+direction*.019,q+direction*.026],3.25/cols*.20,4,12)
    tiles.finish('Orange red overlapping barrel tiles roof face %d'%(side+1),TILES,CROOF,True)
    ends.finish('Circular eave tile ends face %d'%(side+1),TILES,CROOF,True)
    lip=Batch()
    lip.tube([rp(side,k/70,1)-Vector((0,0,.065)) for k in range(71)],.028,0,8)
    # Dark fine fascia joints reflect the pale patterned eave strip in the photos.
    for k in range(cols+1):
        p=rp(side,k/cols,1)
        lip.tube([p-Vector((0,0,.05)),p-Vector((0,0,.13))],.006,1,5)
    lip.finish('Ivory eave fascia and restrained dark joints %d'%side,[WHITE,EDGE],CROOF)
    hip=Batch(); pts=[rp(side,0,j/55)+Vector((0,0,.075)) for j in range(56)]
    hip.tube(pts,.064,0,10)
    for j in range(3,26):
        s=j/27; p=rp(side,0,s)+Vector((0,0,.10)); d=(rp(side,0,min(1,s+.01))-rp(side,0,max(0,s-.01))).normalized()
        hip.tube([p-d*.014,p+d*.014],.076,1,10)
    tip=rp(side,0,1); out=Vector((math.cos(ANG[side]),math.sin(ANG[side]),0))
    hip.tube([tip+Vector((0,0,.07)),tip+out*.10+Vector((0,0,.15)),tip+out*.13+Vector((0,0,.30)),tip+out*.10+Vector((0,0,.42))],[.07,.06,.04,.006],0,10)
    hip.finish('Swept corner ridge and slender upturned tip %d'%(side+1),[TILES[2],TILES[4]],CROOF,True)
fin=Batch()
fin.lathe((P.x,P.y,8.08),[(0,.13),(.10,.12),(.23,.085),(.52,.11),(.64,.065),(.68,.015)],0,18)
fin.finish('Tall tapered ceramic roof finial',[TILES[1]],CROOF,True)

from landscape import build_landscape
build_landscape(CBASE,CPOND,CGREEN,CBUILD,platform,rects,PLANTER,EARTH)

# Clean daylight studio presentation with warm upper-left sunlight.
BG=material('Clean warm grey photographic backdrop',(.78,.81,.80),.94,cel=False)
cube('Studio floor outside the collectible base',(0,0,-.44),(200,200,.12),BG,CSTAGE,0)
def light(name,typ,loc,energy,color,size=5,target=(0,0,2)):
    d=bpy.data.lights.new(name,typ); d.energy=energy; d.color=color
    if typ=='AREA': d.shape='DISK'; d.size=size
    if typ=='SUN': d.angle=math.radians(9)
    o=bpy.data.objects.new(name,d); CSTAGE.objects.link(o); o.location=loc
    o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler()
light('Afternoon sun from upper left','SUN',(-9,-12,22),2.25,(1,.91,.76))
light('Large soft sky fill','AREA',(5,-1,20),1900,(.71,.84,1),18)
camd=bpy.data.cameras.new('Campus_Isometric_Camera'); cam=bpy.data.objects.new('Campus_Isometric_Camera',camd); CSTAGE.objects.link(cam)
cam.location=(30,-30,44.5); target=Vector((0,0,2.1)); cam.rotation_euler=(target-cam.location).to_track_quat('-Z','Y').to_euler()
camd.type='ORTHO'; camd.ortho_scale=38.5
s=bpy.context.scene; s.camera=cam; s.render.engine='BLENDER_EEVEE_NEXT'
s.render.resolution_x=s.render.resolution_y=1800; s.render.resolution_percentage=int(os.environ.get('CAMPUS_RENDER_PERCENT','100'))
s.render.image_settings.file_format='PNG'; s.render.fps=24; s.frame_start=1; s.frame_end=120; s.frame_set(1)
s.world.use_nodes=True; bg=s.world.node_tree.nodes.get('Background'); bg.inputs[0].default_value=(.65,.78,.92,1); bg.inputs[1].default_value=.45
s.view_settings.view_transform='AgX'; s.view_settings.look='AgX - Medium High Contrast'; s.view_settings.exposure=.32
if hasattr(s.eevee,'use_raytracing'): s.eevee.use_raytracing=True
if hasattr(s.eevee,'taa_render_samples'): s.eevee.taa_render_samples=64
s.render.use_freestyle=True; s.render.line_thickness=.65
ls=bpy.context.view_layer.freestyle_settings.linesets[0]
ls.linestyle.color=(.12,.15,.12); ls.linestyle.thickness=.55
ls.select_crease=False; ls.select_silhouette=True; ls.select_external_contour=True; ls.select_border=False
# Only the architecture receives outlines; leaf edges remain light and natural.
outline=collection('09_Architectural_Outline_Set')
for c in [CWALK,CRAIL,CPAV,CROOF]:
    for o in c.objects:
        if o.name not in outline.objects: outline.objects.link(o)
ls.select_by_collection=True; ls.collection=outline; ls.collection_negation='INCLUSIVE'
s['Project']='中式校园水榭 · 单层六角亭'
s['Reference']='Six current user-provided campus photos; earlier red-column double-eave pavilion is a separate project.'
s['Structural_constraints']='ONE roof tier, SIX pale yellow columns, open sides, stone table/stools, orange barrel tiles, raised polygonal platform, silver arc rails, concrete piers, grey zigzag walks with red-brown balusters.'
s['Layout_note']='Photo-based reconstruction of visible turns and connections. Distances and occluded details are inferred from perspective, not measured survey data.'
s['Animation_note']='Subtle water surface, floating leaf clusters and foliage wind; architecture remains static. Frames 1–120, 24 fps.'
for screen in bpy.data.screens:
    for area in screen.areas:
        if area.type=='VIEW_3D': area.spaces.active.region_3d.view_perspective='CAMERA'; area.spaces.active.shading.type='MATERIAL'
s.render.filepath='//campus_waterside.png'
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT,'campus_waterside.blend'))
print('CAMPUS_SCENE_SAVED',len(s.objects),flush=True)
assert len([o for o in CPAV.objects if o.name.startswith('Pale yellow pavilion column')])==6
assert len([o for o in CROOF.objects if o.name.startswith('Single roof ivory soffit')])==6
# Portable PBR export. Blender-only cel palettes are retained in the saved .blend.
for m in bpy.data.materials:
    if not m.use_nodes: continue
    p=m.node_tree.nodes.get('Principled BSDF')
    if p:
        for link in list(p.inputs['Base Color'].links): m.node_tree.links.remove(link)
        p.inputs['Base Color'].default_value=m.diffuse_color
bpy.ops.object.select_all(action='DESELECT')
for o in s.objects:
    if o.type in {'MESH','CURVE'} and o.name!='Studio floor outside the collectible base': o.select_set(True)
bpy.ops.export_scene.gltf(filepath=os.path.join(OUT,'campus_waterside.glb'),export_format='GLB',use_selection=True,export_apply=True,export_animations=True,export_materials='EXPORT',export_lights=False)
bpy.ops.wm.open_mainfile(filepath=os.path.join(OUT,'campus_waterside.blend'))
bpy.ops.render.render(write_still=True)
print('CAMPUS_RENDER_COMPLETE',flush=True)
