"""Campus pond, dense but legible foliage, and subdued academic backdrop."""
import bpy,math,random
from mathutils import Vector
from geometry import *

def build_landscape(CBASE,CPOND,CGREEN,CBUILD,platform,rects,PLANTER,EARTH):
    r=random.Random(71022)
    grass=material('Campus bank low ground cover',(.20,.31,.10),.94)
    bank=material('Earth bank section',(.24,.22,.12),.96)
    stone=material('Small muted shore stones',(.40,.43,.31),.9)
    bark=material('Natural evergreen bark',(.18,.14,.085),.88)
    greens=[material('Broadleaf green %d'%i,c,.9) for i,c in enumerate([
        (.065,.18,.065),(.11,.26,.075),(.17,.34,.11),(.24,.40,.14),(.30,.45,.19)])]
    bamboo=material('Bamboo pale green culms',(.37,.44,.15),.7)
    joints=material('Bamboo raised nodes',(.52,.55,.28),.74)
    bamboo_greens=[material('Fine bamboo leaves %d'%i,c,.83) for i,c in enumerate([
        (.18,.33,.075),(.27,.43,.11),(.36,.49,.15),(.43,.54,.20)])]
    water=material('Pond water deep natural green',(.024,.075,.043),.09,.26,False)
    p=water.node_tree.nodes.get('Principled BSDF'); p.inputs['IOR'].default_value=1.333
    p.inputs['Transmission Weight'].default_value=.06
    n=water.node_tree.nodes.new('ShaderNodeTexNoise'); n.inputs['Scale'].default_value=4.6; n.inputs['Detail'].default_value=2
    bump=water.node_tree.nodes.new('ShaderNodeBump'); bump.inputs['Strength'].default_value=.065; bump.inputs['Distance'].default_value=.018
    water.node_tree.links.new(n.outputs['Fac'],bump.inputs['Height']); water.node_tree.links.new(bump.outputs['Normal'],p.inputs['Normal'])
    vs=[]; fs=[]; N=44
    for j in range(N+1):
        for i in range(N+1):
            x=-11.65+23.3*i/N; y=-11.65+23.3*j/N
            vs.append((x,y,.48+.009*math.sin(x*.7+y*.6)))
    for j in range(N):
        for i in range(N):
            a=j*(N+1)+i; fs.append((a,a+1,a+N+2,a+N+1))
    w=object_mesh('Quiet pond water surface',vs,fs,[water],CPOND,smooth=True)
    w.shape_key_add(name='Basis')
    k=w.shape_key_add(name='Slow shallow ripples')
    for point,original in zip(k.data,vs): point.co.z=original[2]+.018*math.sin(original[0]*.8-original[1]*.6)
    for frame,value in [(1,0),(61,1),(121,0)]: k.value=value; k.keyframe_insert(data_path='value',frame=frame)
    for f in w.data.shape_keys.animation_data.action.fcurves: f.modifiers.new('CYCLES')
    # A real planar reflection probe supplements screen-space reflections.
    probe=bpy.data.lightprobes.new('Planar pond reflections','PLANE')
    po=bpy.data.objects.new('Pond reflection probe',probe); CPOND.objects.link(po); po.location=(0,0,.50); po.scale=(11.6,11.6,1)

    shores=[
        [(-11.65,-5.7),(-9.8,-5.7),(-9.1,-.7),(-8.65,2.3),(-7.6,5.2),(-7.6,8.6),(-11.65,8.6)],
        [(-11.65,7.8),(-7.5,7.8),(-5.8,8.0),(-2,7.7),(2,7.8),(5.2,7.2),(8.1,6.0),(11.65,6.0),(11.65,11.65),(-11.65,11.65)],
        [(8.1,5.8),(10.2,4.7),(11.65,4.7),(11.65,9.0),(8.1,9.0)]]
    for j,poly in enumerate(shores):
        poly_slab('Campus planted bank %d'%j,poly,.32,1.74,bank,CBASE)
        poly_slab('Green bank surface %d'%j,poly,2.06,.055,grass,CBASE)
    # Pebbles and low plants interrupt the edge without adding new landscape features.
    low=Batch()
    for poly in shores:
        for (ax,ay),(bx,by) in zip(poly,poly[1:]+poly[:1]):
            if max(abs(ax),abs(ay),abs(bx),abs(by))>11.5: continue
            dist=math.hypot(bx-ax,by-ay)
            for j in range(max(1,int(dist/.35))):
                t=(j+.5)/max(1,int(dist/.35)); x=ax+(bx-ax)*t; y=ay+(by-ay)*t
                low.lathe((x,y,1.95),[(0,.12),(.12,.19),(.24,.11),(.27,.015)],0,7)
    low.finish('Small irregular shoreline stones',[stone],CGREEN)

    # Many small floating leaves, concentrated at the front and left as photographed.
    leafm=[material('Floating leaf %d'%i,c,.68) for i,c in enumerate([
        (.22,.39,.15),(.33,.46,.22),(.40,.52,.27),(.26,.43,.18),(.48,.57,.30)])]
    zones=[(-6.0,-8.0,2.8,1.9),(-1.0,-9.1,2.8,1.3),(3.6,-8.8,1.7,1.5),(-8.6,-2.4,1.2,2.5),(-.6,-1.8,2.2,1.9)]
    for z,(cx,cy,sx,sy) in enumerate(zones):
        pads=Batch(); count=[1000,1050,700,450,420][z]
        for i in range(count):
            x=r.gauss(cx,sx*.65); y=r.gauss(cy,sy*.65)
            if not(-11.3<x<11.3 and -11.3<y<7.2): continue
            if any(inside(x,y,p) for p in shores): continue
            rad=r.uniform(.045,.115) if i%13 else r.uniform(.14,.22)
            a=r.uniform(0,math.tau); n=10 if rad>.12 else 8
            # A small notch is visible on the larger water-lily leaves.
            span=math.tau-.32 if rad>.12 else math.tau
            v=[(x,y,.512)]+[(x+rad*math.cos(a+span*k/n),y+rad*.80*math.sin(a+span*k/n),.508+r.uniform(-.002,.002)) for k in range(n+1)]
            pads.add(v,[(0,k+1,k+2) for k in range(n)],r.randrange(5))
            if rad>.12:
                pads.tube([(x,y,.519),(x+rad*.66*math.cos(a+math.pi),y+rad*.5*math.sin(a+math.pi),.519)],.004,r.randrange(5),4)
        o=pads.finish('Floating leaf cluster %d'%(z+1),leafm,CPOND)
        wave_animation(o,amplitude=.009,phase=z*.8)

    # Evergreen crowns use thousands of real leaf-shaped polygons, not coarse blocks.
    tree_specs=[(-9.9,-.3,6.3,1.65),(-9.5,3.2,6.8,1.85),(-9.2,7.2,6.3,1.85),
                (-6.6,8.7,5.6,1.55),(-3.9,8.65,5.2,1.35),(3.4,8.1,5.5,1.30),(6.4,8.5,5.7,1.35)]
    for idx,(tx,ty,height,spread) in enumerate(tree_specs):
        basez=2.10; trunk=Batch(); foliage=Batch()
        lean=Vector((r.uniform(-.25,.25),r.uniform(-.18,.18),0))
        trunk.tube([(tx,ty,basez),(tx+lean.x*.3,ty+lean.y*.3,basez+height*.38),(tx+lean.x,ty+lean.y,basez+height*.85)],[.19,.12,.035],0,12)
        clusters=[]
        for j in range(11):
            a=j*2.4+r.uniform(-.3,.3); level=r.uniform(.34,.85)
            reach=spread*r.uniform(.35,.80)
            start=Vector((tx+lean.x*level,ty+lean.y*level,basez+height*level-.6))
            end=Vector((tx+math.cos(a)*reach,ty+math.sin(a)*reach,basez+height*level+.4))
            trunk.tube([start,start.lerp(end,.55)+Vector((0,0,.15)),end],[.063,.032,.012],0,8)
            clusters.append((end,spread*.62,spread*.50,.62))
        clusters.append((Vector((tx+lean.x,ty+lean.y,basez+height-.30)),spread*.75,spread*.66,.63))
        for center,rx,ry,rz in clusters:
            for k in range(135):
                # Slightly clustered leaf layers form an airy, detailed natural silhouette.
                theta=r.uniform(0,math.tau); zz=r.uniform(-1,1); rr=math.sqrt(max(0,1-zz*zz))*r.uniform(.40,1)
                p=center+Vector((rx*rr*math.cos(theta),ry*rr*math.sin(theta),rz*zz))
                if max(abs(p.x),abs(p.y))>11.55: continue
                length=r.uniform(.22,.40)
                foliage.leaf(p,length,length*r.uniform(.42,.64),r.uniform(0,math.tau),r.uniform(-.55,.55),r.randrange(5))
        trunk.finish('Evergreen trunk and branching %d'%(idx+1),[bark],CGREEN,True)
        crown=foliage.finish('Detailed evergreen leaf crown %d'%(idx+1),greens,CGREEN,origin=(tx,ty,basez))
        wave_animation(crown,'rotation_euler',1,.0025,idx*.6)

    # Lower evergreen foliage fills the shaded bank, retaining the dense woodland
    # character in the reference photographs rather than a row of isolated trees.
    understorey=Batch()
    for cx,cy in [(-10.3,-3.8),(-9.9,-2.1),(-10.2,.8),(-9.8,2.6),(-9.5,4.3),(-8.8,6),(-7.6,8.7),(-5.5,8.7),(-2.4,8.5),(2.8,8.4),(5.1,8.4),(7.2,8.2)]:
        h=r.uniform(.65,1.6); spread=r.uniform(.60,.95)
        for k in range(240):
            a=r.uniform(0,math.tau); zz=r.uniform(-1,1); radius=math.sqrt(1-zz*zz)*r.uniform(.4,1)
            p=Vector((cx+math.cos(a)*spread*radius,cy+math.sin(a)*spread*radius,2.65+h*.60+zz*h*.60))
            if max(abs(p.x),abs(p.y))>11.45: continue
            length=r.uniform(.21,.36)
            understorey.leaf(p,length,length*.56,r.uniform(0,math.tau),r.uniform(-.4,.4),r.randrange(4))
    understorey.finish('Layered evergreen understorey along the photographed banks',greens,CGREEN)

    # Dense right-hand bamboo grove, with visible nodes, fine branches and lanceolate leaves.
    for group,(cx,cy) in enumerate([(9.2,6.6),(10.0,8.9),(8.1,9.7)]):
        stems=Batch(); leaves=Batch()
        for j in range(17):
            x=cx+r.uniform(-.65,.65); y=cy+r.uniform(-.65,.65); h=r.uniform(4.4,6.3); angle=r.uniform(0,math.tau)
            sway=Vector((.24*math.cos(angle),.24*math.sin(angle),0)); base=Vector((x,y,2.1))
            points=[base+Vector((0,0,h*t))+sway*t*t for t in [0,.25,.5,.75,1]]
            stems.tube(points,[.046,.043,.039,.033,.023],0,8)
            for k in range(1,int(h/.50)):
                t=k*.50/h; p=base+Vector((0,0,k*.5))+sway*t*t
                stems.cylinder(p,.052,.022,1,8)
                if t<.4: continue
                for side in [0,math.pi]:
                    aa=angle+k*1.1+side; reach=r.uniform(.45,.90)
                    end=p+Vector((math.cos(aa)*reach,math.sin(aa)*reach,r.uniform(.12,.32)))
                    stems.tube([p,end], [.012,.003],0,6)
                    for leafid in range(7):
                        f=(leafid+1)/8; q=p.lerp(end,f)
                        for sign in [-1,1]:
                            phi=aa+sign*.7
                            qq=q+Vector((math.cos(phi)*.14,math.sin(phi)*.14,0))
                            if max(abs(qq.x),abs(qq.y))>11.55: continue
                            leaves.leaf(qq,r.uniform(.26,.42),r.uniform(.045,.075),phi,r.uniform(-.25,.35),r.randrange(4))
        stems.finish('Bamboo culms and raised nodes %d'%(group+1),[bamboo,joints],CGREEN,True)
        leaf=leaves.finish('Fine bamboo leaf sprays %d'%(group+1),bamboo_greens,CGREEN,origin=(cx,cy,2.1))
        wave_animation(leaf,'rotation_euler',0,.003,group)

    # Small bankside shrubs and the reddish rosettes in the original tiled planters.
    purple=material('Planter burgundy tropical foliage',(.22,.14,.09),.79)
    ornamental=[greens[2],greens[3],purple]
    shrubs=Batch()
    locations=[(-2.95,1.7,2.78),(-2.95,2.6,2.78),(-2.95,3.8,2.78),(-2.95,4.8,2.78)]
    locations += [(x,.68,2.78) for x in [-1.2,-.4,.45,1.3,2.15,3.0]]
    locations += [(r.uniform(-8,7),r.uniform(7.75,8.1),2.1) for i in range(24)]
    for x,y,z in locations:
        for j in range(20):
            a=j*2.4; L=r.uniform(.35,.68)
            p=(x+math.cos(a)*L*.23,y+math.sin(a)*L*.23,z+L*.38)
            shrubs.leaf(p,L,L*.22,a,r.uniform(.45,1.1),r.randrange(3))
    shrubs.finish('Low bankside shrubs and planter rosettes',ornamental,CGREEN)
    ornament=Batch(); pole=(-2.85,2.0,2.78)
    ornament.tube([pole,(-2.85,2,5.1)],.035,0,8)
    pts=[(-2.85+.23*math.sin(t*math.pi*2),2,5.1+t*.75) for t in [i/30 for i in range(31)]]
    ornament.tube(pts,.032,0,8)
    ornament.finish('Small photographed scroll-shaped terrace ornament',[purple],CGREEN,True)

    # Simplified modern academic building retains the campus identity, behind foliage.
    wall=material('Background campus pale stone',(.67,.70,.64),.84)
    glass=material('Background muted blue window glass',(.26,.39,.45),.35,.1,False)
    mullion=material('Fine pale campus window mullions',(.62,.65,.61),.77)
    roof=material('Muted green campus cornice',(.31,.37,.19),.7)
    building=Batch(); glazing=Batch(); trim=Batch()
    for idx,(cx,cy,width,depth,height,stories) in enumerate([(0,10.25,8.3,2.2,4.8,4),(4.8,10.25,2.1,2.2,6.5,6)]):
        building.box((cx,cy,2.10+height/2),(width,depth,height))
        facade_y=cy-depth/2-.012
        for story in range(stories):
            z=2.1+.42+(story+.5)*(height-.7)/stories
            h=(height-.7)/stories-.16
            cols=max(2,int(width/.63))
            for j in range(cols):
                x=cx-width/2+.28+(j+.5)*(width-.56)/cols
                glazing.box((x,facade_y-.012,z),((width-.56)/cols-.045,.026,h))
            trim.box((cx,facade_y-.025,z+h/2+.04),(width,.055,.065),0)
        trim.box((cx,cy,2.1+height+.10),(width+.25,depth+.27,.18),0)
        for j in range(int(width/.14)):
            trim.box((cx-width/2+j*.14,cy-depth/2-.13,2.1+height+.23),(.07,.25,.13),1)
    building.finish('Subdued campus building masses',[wall],CBUILD)
    glazing.finish('Simplified blue glazed campus windows',[glass],CBUILD)
    trim.finish('Pale window bands and green cornice',[mullion,roof],CBUILD)
