"""Small deterministic mesh-building helpers; Blender 4.3, no external packages."""
import bpy
import math
from mathutils import Vector

def collection(name):
    c=bpy.data.collections.get(name) or bpy.data.collections.new(name)
    if c.name not in bpy.context.scene.collection.children:
        bpy.context.scene.collection.children.link(c)
    return c

def material(name,color,rough=.62,metal=0,cel=True):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.use_nodes=True
    p=m.node_tree.nodes.get('Principled BSDF')
    p.inputs['Base Color'].default_value=(*color,1)
    p.inputs['Roughness'].default_value=rough; p.inputs['Metallic'].default_value=metal
    if cel:
        ns,links=m.node_tree.nodes,m.node_tree.links
        g=ns.new('ShaderNodeNewGeometry'); d=ns.new('ShaderNodeVectorMath'); d.operation='DOT_PRODUCT'
        d.inputs[1].default_value=(-.45,-.38,.81)
        links.new(g.outputs['Normal'],d.inputs[0])
        r=ns.new('ShaderNodeValToRGB'); r.name='Restrained three-tone cel colors'
        r.color_ramp.interpolation='CONSTANT'
        r.color_ramp.elements.remove(r.color_ramp.elements[1])
        for i,(pos,k) in enumerate([(0,.70),(.18,.87),(.60,1)]):
            e=r.color_ramp.elements[0] if i==0 else r.color_ramp.elements.new(pos)
            e.position=pos; e.color=(*(c*k for c in color),1)
        links.new(d.outputs['Value'],r.inputs[0]); links.new(r.outputs[0],p.inputs['Base Color'])
    return m

def object_mesh(name,verts,faces,materials,coll,ids=None,smooth=False,origin=(0,0,0)):
    origin=Vector(origin)
    me=bpy.data.meshes.new(name)
    me.from_pydata([Vector(v)-origin for v in verts],[],faces); me.update()
    for m in materials: me.materials.append(m)
    for i,f in enumerate(me.polygons):
        f.use_smooth=smooth
        if ids: f.material_index=ids[i]
    o=bpy.data.objects.new(name,me); coll.objects.link(o); o.location=origin
    return o

def bevel(o,w=.02,segments=2):
    b=o.modifiers.new('Small crafted edge bevel','BEVEL'); b.width=w; b.segments=segments
    return o

class Batch:
    def __init__(self): self.v=[]; self.f=[]; self.ids=[]
    def add(self,v,f,mat=0):
        off=len(self.v); self.v.extend(Vector(p) for p in v)
        self.f.extend(tuple(off+i for i in face) for face in f)
        self.ids.extend([mat]*len(f))
    def box(self,center,size,mat=0,axes=None):
        c=Vector(center); x,y,z=[s/2 for s in size]
        v=[(-x,-y,-z),(x,-y,-z),(x,y,-z),(-x,y,-z),(-x,-y,z),(x,-y,z),(x,y,z),(-x,y,z)]
        if axes:
            ax=[Vector(a) for a in axes]; v=[c+ax[0]*p[0]+ax[1]*p[1]+ax[2]*p[2] for p in v]
        else: v=[c+Vector(p) for p in v]
        self.add(v,[(3,2,1,0),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)],mat)
    def beam(self,a,b,w,h,mat=0):
        a,b=Vector(a),Vector(b); z=(b-a).normalized()
        ref=Vector((0,0,1)) if abs(z.z)<.98 else Vector((0,1,0))
        x=z.cross(ref).normalized(); y=z.cross(x).normalized()
        self.box((a+b)/2,(w,h,(b-a).length),mat,(x,y,z))
    def tube(self,points,radii,mat=0,n=10,caps=True):
        pts=[Vector(p) for p in points]
        if isinstance(radii,(int,float)): radii=[radii]*len(pts)
        vs=[]; fs=[]
        for j,(p,r) in enumerate(zip(pts,radii)):
            tangent=(pts[min(j+1,len(pts)-1)]-pts[max(j-1,0)]).normalized()
            ref=Vector((0,0,1)) if abs(tangent.z)<.95 else Vector((0,1,0))
            u=tangent.cross(ref).normalized(); v=tangent.cross(u).normalized()
            for k in range(n):
                a=math.tau*k/n; vs.append(p+r*(u*math.cos(a)+v*math.sin(a)))
        for j in range(len(pts)-1):
            for k in range(n): fs.append((j*n+k,j*n+(k+1)%n,(j+1)*n+(k+1)%n,(j+1)*n+k))
        if caps: fs.extend([tuple(range(n-1,-1,-1)),tuple((len(pts)-1)*n+k for k in range(n))])
        self.add(vs,fs,mat)
    def cylinder(self,center,radius,depth,mat=0,n=20):
        p=Vector(center); self.tube([p+Vector((0,0,-depth/2)),p+Vector((0,0,depth/2))],radius,mat,n)
    def lathe(self,center,profile,mat=0,n=18):
        c=Vector(center); v=[]; f=[]
        for z,r in profile:
            for i in range(n):
                a=math.tau*i/n; v.append(c+Vector((r*math.cos(a),r*math.sin(a),z)))
        for j in range(len(profile)-1):
            for i in range(n): f.append((j*n+i,j*n+(i+1)%n,(j+1)*n+(i+1)%n,(j+1)*n+i))
        f.extend([tuple(range(n-1,-1,-1)),tuple((len(profile)-1)*n+i for i in range(n))])
        self.add(v,f,mat)
    def leaf(self,center,length,width,angle,tilt=0,mat=0):
        c=Vector(center); u=Vector((math.cos(angle),math.sin(angle),tilt)).normalized()
        v=Vector((-math.sin(angle),math.cos(angle),0)); n=u.cross(v).normalized()
        pts=[c-u*length/2,c-u*length*.23+v*width*.47,c+u*length*.2+v*width*.42,
             c+u*length/2,c+u*length*.2-v*width*.42,c-u*length*.23-v*width*.47,c+n*width*.17]
        self.add(pts,[(i,(i+1)%6,6) for i in range(6)],mat)
    def finish(self,name,mats,coll,smooth=False,origin=(0,0,0)):
        return object_mesh(name,self.v,self.f,mats,coll,self.ids,smooth,origin)

def cube(name,loc,size,mat,coll,bev=.02):
    b=Batch(); b.box(loc,size); o=b.finish(name,[mat],coll)
    return bevel(o,bev) if bev else o

def poly_slab(name,polygon,z,h,mat,coll):
    n=len(polygon)
    v=[(x,y,zz) for zz in (z,z+h) for x,y in polygon]
    fs=[tuple(range(n-1,-1,-1)),tuple(range(n,n*2))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    return bevel(object_mesh(name,v,fs,[mat],coll),.018)

def inside(x,y,poly):
    odd=False; j=len(poly)-1
    for i,(xi,yi) in enumerate(poly):
        xj,yj=poly[j]
        if (yi>y)!=(yj>y) and x<(xj-xi)*(y-yi)/(yj-yi)+xi: odd=not odd
        j=i
    return odd

def wave_animation(o,axis='location',index=2,amplitude=.012,phase=0):
    base=getattr(o,axis)[index]
    for fr in [1,31,61,91,121]:
        getattr(o,axis)[index]=base+amplitude*math.sin((fr-1)/120*math.tau+phase)
        o.keyframe_insert(data_path=axis,index=index,frame=fr)
    getattr(o,axis)[index]=base
    for f in o.animation_data.action.fcurves:
        f.modifiers.new('CYCLES')
