"""Verify the delivered scene's structural requirements with Blender."""
import bpy
import json
from mathutils import Vector

scene = bpy.context.scene
meshes = [o for o in scene.objects if o.type == 'MESH' and not o.name.startswith('Studio floor')]
columns = [o for o in meshes if o.name.startswith('Pale yellow pavilion column')]
roof_faces = [o for o in meshes if o.name.startswith('Single roof ivory soffit')]
assert len(columns) == 6, 'The pavilion must have exactly six columns.'
assert len(roof_faces) == 6, 'The single roof must have six faces.'
escaped = []
for frame in (1, 31, 61, 91, 120):
    scene.frame_set(frame)
    for obj in meshes:
        # Check actual vertices; an axis-aligned bounding-box corner can lie
        # outside the footprint even when a rotated polygon remains inside it.
        if any(max(abs(p.x), abs(p.y)) > 12.005
               for p in (obj.matrix_world @ vertex.co for vertex in obj.data.vertices)):
            escaped.append((frame, obj.name))
assert not escaped, f'Geometry outside the square base: {escaped}'
animated = [o.name for o in meshes if o.animation_data]
assert all('leaf' in name.lower() or 'crown' in name.lower() for name in animated), animated
assert bpy.data.objects['Quiet pond water surface'].data.shape_keys
assert scene.camera.data.type == 'ORTHO'
assert scene.render.resolution_x == scene.render.resolution_y == 1800
assert scene.render.resolution_percentage == 100
scene.frame_set(1)
print('CAMPUS_VALIDATION ' + json.dumps({
    'columns': len(columns), 'single_roof_faces': len(roof_faces),
    'mesh_objects': len(meshes), 'all_geometry_inside_24m_square': True,
    'animated_foliage_objects': len(animated), 'water_morph_animation': True,
    'architecture_static': True, 'render_resolution': [1800, 1800],
}, ensure_ascii=False), flush=True)
